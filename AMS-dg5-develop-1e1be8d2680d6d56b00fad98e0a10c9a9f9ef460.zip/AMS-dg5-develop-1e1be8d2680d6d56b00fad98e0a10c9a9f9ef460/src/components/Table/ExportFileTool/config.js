export const DATE = 'date';
export const TIME = 'time';
export const DATETIME = 'datetime';
export const BOM = '\ufeff';
export const EXT_CSV = 'csv';
export const EXT_XML = 'xml';
export const EXT_JSON = 'json';
export const EXT_XLSX = 'xlsx';
