export const SETCOUNT = 'setCount';
export const DISPOSE = 'dispose';
