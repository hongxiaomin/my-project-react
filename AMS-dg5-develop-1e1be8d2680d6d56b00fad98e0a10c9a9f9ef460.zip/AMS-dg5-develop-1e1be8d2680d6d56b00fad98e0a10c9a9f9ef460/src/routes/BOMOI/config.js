export const sideData = [
  { id: 'A', name: 'A面制程' },
  { id: 'B', name: 'B面制程' },
  { id: 'AB', name: '双面制程' },
];
export const sideGroupData = [
  { id: 'A', name: 'A面制程' },
  { id: 'B', name: 'B面制程' },
];

export const moduleData = [
  { id: 2, name: 2 },
  { id: 4, name: 4 },
  { id: 6, name: 6 },
  { id: 8, name: 8 },
  { id: 10, name: 10 },
  { id: 12, name: 12 },
  { id: 16, name: 16 },
];
export const NXTData = [
  { id: 'NXT-1', name: 'NXT-1' },
  { id: 'NXT-2', name: 'NXT-2' },
  { id: 'NXT-3', name: 'NXT-3' },
];
