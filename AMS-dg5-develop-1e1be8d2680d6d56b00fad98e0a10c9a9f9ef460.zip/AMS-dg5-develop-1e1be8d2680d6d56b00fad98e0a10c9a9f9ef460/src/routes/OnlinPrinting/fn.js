import fetchData from '@delta/common-utils/utils/fetchData';

export const onCloseSnack = _this => () => _this.setState({ snackSwitch: false });

