Ver: 1.0.0
Maintainer: Chuck Wu, Chao.BJ.Wang, Andy Li
Organization: Delta Electronics DRC department

### Imporvements
* Change covention rule from standard to airbnb

=========================================== Original ===========================================

Changelog
=========

3.0.0-alpha.0
-------------

### Improvements
* Migrated to Fractal Project Structure, huge thanks to [justingreenberg](https://github.com/justingreenberg). See https://github.com/davezuko/react-redux-starter-kit/pull/684 for details and discussion.
