import autoprefixer from 'autoprefixer';

module.exports = {

  plugins: [
    autoprefixer,
  ],
};
