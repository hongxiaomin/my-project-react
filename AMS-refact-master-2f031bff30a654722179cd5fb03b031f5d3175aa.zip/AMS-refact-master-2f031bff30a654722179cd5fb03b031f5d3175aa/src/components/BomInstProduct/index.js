export { default } from './BomInstProduct';
