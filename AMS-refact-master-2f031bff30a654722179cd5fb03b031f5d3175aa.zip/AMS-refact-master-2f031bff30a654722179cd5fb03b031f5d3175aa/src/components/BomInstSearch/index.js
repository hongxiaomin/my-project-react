export { default } from './BomInstSearch';
