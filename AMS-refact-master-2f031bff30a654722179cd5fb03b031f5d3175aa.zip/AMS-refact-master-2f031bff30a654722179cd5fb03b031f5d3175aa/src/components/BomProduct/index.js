export { default } from './BomProduct';
