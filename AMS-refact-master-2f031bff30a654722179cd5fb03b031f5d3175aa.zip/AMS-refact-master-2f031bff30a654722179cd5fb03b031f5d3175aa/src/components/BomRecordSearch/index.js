export { default } from './BomRecordSearch';
