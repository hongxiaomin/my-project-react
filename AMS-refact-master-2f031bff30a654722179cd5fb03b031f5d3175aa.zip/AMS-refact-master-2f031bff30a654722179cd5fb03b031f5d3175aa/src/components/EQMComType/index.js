export { default } from './EQMComType';
