export { default } from './EQMEqReg';
