export { default } from './EQMEqScrap';
