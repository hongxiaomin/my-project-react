export { default } from './EQMFaultStat';
