export { default } from './EQMFctTypeSet';
