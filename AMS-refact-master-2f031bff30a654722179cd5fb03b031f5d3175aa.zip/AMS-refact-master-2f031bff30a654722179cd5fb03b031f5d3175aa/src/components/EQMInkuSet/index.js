export { default } from './EQMInkuSet';
