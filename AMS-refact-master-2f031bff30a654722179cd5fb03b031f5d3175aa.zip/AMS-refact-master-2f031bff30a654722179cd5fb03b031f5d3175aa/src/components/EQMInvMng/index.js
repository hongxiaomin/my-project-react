export { default } from './EQMInvMng';
