export { default } from './EQMKeyParts';
