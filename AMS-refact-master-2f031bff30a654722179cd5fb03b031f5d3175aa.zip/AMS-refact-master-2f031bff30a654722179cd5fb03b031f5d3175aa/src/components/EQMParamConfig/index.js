export { default } from './EQMParamConfig';
