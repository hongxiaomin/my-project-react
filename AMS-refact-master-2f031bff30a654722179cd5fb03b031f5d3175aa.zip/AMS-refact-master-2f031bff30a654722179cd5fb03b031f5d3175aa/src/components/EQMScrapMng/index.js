export { default } from './EQMScrapMng';
