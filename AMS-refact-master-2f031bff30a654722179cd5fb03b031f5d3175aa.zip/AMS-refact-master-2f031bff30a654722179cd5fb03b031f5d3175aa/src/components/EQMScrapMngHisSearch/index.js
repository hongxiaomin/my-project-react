export { default } from './EQMScrapMngHisSearch';
