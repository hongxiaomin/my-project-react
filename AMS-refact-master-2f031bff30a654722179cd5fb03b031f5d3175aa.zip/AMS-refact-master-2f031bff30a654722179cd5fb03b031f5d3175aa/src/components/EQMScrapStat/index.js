export { default } from './EQMScrapStat';
