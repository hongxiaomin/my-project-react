export { default } from './EQMSegTypeSet';
