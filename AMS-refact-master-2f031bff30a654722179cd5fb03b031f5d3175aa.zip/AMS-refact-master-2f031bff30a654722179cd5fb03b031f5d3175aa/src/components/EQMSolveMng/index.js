export { default } from './EQMSolveMng';
