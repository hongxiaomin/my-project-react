export { default } from './EQMStatTypeSet';
