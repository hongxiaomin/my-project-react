export { default } from './EQMSupplierConfig';
