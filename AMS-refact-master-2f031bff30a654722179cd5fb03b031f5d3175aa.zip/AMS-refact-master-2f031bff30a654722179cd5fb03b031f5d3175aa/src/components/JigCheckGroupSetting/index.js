export { default } from './JigCheckGroupSetting';
