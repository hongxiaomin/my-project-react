export { default } from './JigGroupSetting';
