export { default } from './JigScrapReasonSetting';
