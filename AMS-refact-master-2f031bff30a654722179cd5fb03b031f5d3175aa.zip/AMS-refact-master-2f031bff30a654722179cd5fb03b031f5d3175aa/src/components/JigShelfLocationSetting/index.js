export { default } from './JigShelfLocationSetting';
