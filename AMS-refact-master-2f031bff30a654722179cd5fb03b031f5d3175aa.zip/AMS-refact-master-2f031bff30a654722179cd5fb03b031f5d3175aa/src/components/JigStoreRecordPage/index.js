export { default } from './JigStoreRecordPage';
