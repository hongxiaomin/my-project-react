export { default } from './JigTypeSetting';
