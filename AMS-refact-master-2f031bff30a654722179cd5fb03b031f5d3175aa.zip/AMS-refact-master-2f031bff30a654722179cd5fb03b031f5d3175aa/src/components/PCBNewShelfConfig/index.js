export { default } from './PCBNewShelfConfig';
