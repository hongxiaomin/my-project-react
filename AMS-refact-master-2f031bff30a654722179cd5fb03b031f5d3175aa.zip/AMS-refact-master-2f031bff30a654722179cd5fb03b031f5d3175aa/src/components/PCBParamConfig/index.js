export { default } from './PCBParamConfig';
// import React,{Component} from 'react';
// import Bread from '../Bread';
// import Iframe from "../Iframe";
//
//
// const breadMap = [{
//   path: '',
//   name: '首页',
// }, {
//   path: '',
//   name: 'PCB',
// }, {
//   path: '',
//   name: '系统配置',
// }, {
//   path: '',
//   name: '参数配置',
// }];
//
// export default class PCBShelfMonitor extends Component{
// 	state={
// 		url:"related/pcb/html/PCBParam.html"
// 	}
//       render(){
//           return (
// 	 <div>
//           <Bread breadMap={breadMap} />
// 		   <Iframe  url={this.state.url} />
// 	</div>
//       )}
// };
