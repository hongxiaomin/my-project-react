export { default } from './PCBShelfConfig';
