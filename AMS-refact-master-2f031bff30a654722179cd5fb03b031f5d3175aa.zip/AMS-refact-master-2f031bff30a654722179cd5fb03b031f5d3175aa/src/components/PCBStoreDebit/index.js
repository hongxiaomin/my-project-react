export { default } from './PCBStoreDebit';
