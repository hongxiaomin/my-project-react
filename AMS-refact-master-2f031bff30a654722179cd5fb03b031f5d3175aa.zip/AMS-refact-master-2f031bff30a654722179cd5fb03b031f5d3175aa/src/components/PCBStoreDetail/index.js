export { default } from './PCBStoreDetail';
