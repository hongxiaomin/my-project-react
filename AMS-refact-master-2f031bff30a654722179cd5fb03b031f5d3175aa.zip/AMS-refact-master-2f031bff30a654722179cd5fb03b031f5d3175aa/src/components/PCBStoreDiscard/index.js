export { default } from './PCBStoreDiscard';
// import React,{Component} from 'react';
// import Bread from '../Bread';
// import Iframe from "../Iframe"; 

// const breadMap = [{
//   path: '',
//   name: '首页',
// }, {
//   path: '',
//   name: 'PCB',
// }, {
//   path: '',
//   name: '仓库管理',
// }, {
//   path: '',
//   name: '库存报废',
// }];

// export default class PCBStoreDiscard extends Component{
// 	state={
// 		url:"related/pcb/html/PCBDiscard.html"
// 	}
//       render(){
//           return ( 
// 	 <div>  
//           <Bread breadMap={breadMap} />
// 		   <Iframe  url={this.state.url} />
// 	</div>
//       )}
// };