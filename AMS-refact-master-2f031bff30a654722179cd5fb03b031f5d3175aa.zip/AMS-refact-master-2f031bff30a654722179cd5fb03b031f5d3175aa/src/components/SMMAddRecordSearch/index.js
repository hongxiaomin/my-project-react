export { default } from './SMMAddRecordSearch';
