export { default } from './SMMAutoUpFeeder';

// import React, { Component } from 'react';
// import Bread from '../Bread';
// import Iframe from '../Iframe';

// const breadMap = [{
//   path: '',
//   name: '首页',
// }, {
//   path: '',
//   name: '原材料管理',
// }, {
//   path: '',
//   name: '备料区管理',
// }, {
//   path: '',
//   name: '接料与料车合并',
// }];

// export default class SMMMaterialCarMerge extends Component {
//   state={
//     url: 'related/smm/html/stockPreparation/getMaterialAndCar.html',
//   }
//   render() {
//     return (
//       <div>
//         <Bread breadMap={breadMap} />
//         <Iframe url={this.state.url} />
//       </div>
//     );
//   }
// }
