export { default } from './SMMBinSetting';
