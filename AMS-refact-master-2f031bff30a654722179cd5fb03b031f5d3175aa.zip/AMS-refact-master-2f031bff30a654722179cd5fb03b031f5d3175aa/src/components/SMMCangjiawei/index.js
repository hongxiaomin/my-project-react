export { default } from './SMMCangjiawei';
