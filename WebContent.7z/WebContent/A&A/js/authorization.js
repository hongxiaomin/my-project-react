var config=getConfig();
var serverIp=config.serverIp;
var permissionConfig={
    nodesData:[],
    savePermission:{},
    parentId:null,
    userId:null,
    clickNodeId:null,
    hasPermission:false
};
$(function(){
    getAllUser();

    $('.input-box').click(function(){
       $(this).children('#userlist').slideToggle(300);
        $(this).children('span').toggleClass('glyphicon-triangle-top');
    });

    $('#userlist').on('click','li',function(){
        $('#opertionContent').html('');
        $('#opertionDiv').hide();
        var text=$(this).text();
        permissionConfig.nodesData=[];
        permissionConfig.savePermission={};
        $(this).parent().siblings('input').val(text);
        $(this).parents('.input-box').siblings('p').addClass('hide');
        permissionConfig.userId=parseInt($(this).attr('data_id'));
        var setting={
            data:{
                simpleData:{
                    enable:true
                }
            },
            callback:{
                onExpand:zTreeExpand,
                onClick:zTreeClick,
                onCollapse:zTreeOnCollapse
            }
        };
        getUserResource(setting);
    });

    $("#opertionContent").on('click','.checkboxType',function(e){
        var nodeId=permissionConfig.clickNodeId;
        var currentPermissions=permissionConfig.savePermission[nodeId];
        var currentId=$(e.target).attr('value');
        if(currentPermissions&&currentPermissions.length>0){
            currentPermissions.forEach(function(permission){
                if(currentId===permission.id){
                    permission.selected=!permission.selected;
                }
            })
        }
    });

    $('#permissionSure').click(function () {
        if(!permissionConfig.hasPermission){
            swal("Error~", "No resources available !", "error");
            return false;
        }
        var name=$('.input-box input[name=username]').val();
        if(!name){
            $('.userInfo').removeClass('hide');
            return false;
        }
        $('#loadingbg').show();
        var requestBody={
            "userId":permissionConfig.userId,
            "mapping":[]
        };
        var currentSave=permissionConfig.savePermission;
        for(var key in currentSave){
            currentSave[key].forEach(function(permission){
                if(permission.selected){
                    var itemObj={};
                    itemObj.resourceId=Number(key);
                    itemObj.operationId=permission.id;
                    requestBody.mapping.push(itemObj);
                }
            })
        }
        requestBody=JSON.stringify(requestBody);
        postPermissionsAjax(requestBody);
    });

    $('#treeNav').on('click','li',function(e){
        e.preventDefault();
        e.stopPropagation();
        var h=$(this).offset().top;
        var w=$('#treeNav').width()+200;
        $('.permission-box-right').css({
            "left":w,
            "top":h/2-190
        })
    })
});

function getAllUser(){
    $('#userlist').empty();
    $('.userIcon').hide();
    var url='users?filterSelf=true';
    getAjax(url,function(data){
        if(data.code===0){
            var datas=data.rows;
            if(datas.length>0){
                $('.userIcon').show();
                datas.forEach(function(user){
                    var li=$('<li data_id="'+user["id"]+'">'+user["name"]+'</li>');
                    li.appendTo($('#userlist'));
                })
            }
        }else{
            swal("Error~", data.message+" !", "error");
        }
    },function(res){
        swal("Error~", res.message+" !", "error");
    })
}

function getUserResource(setting){
    var url='resources?assignUserId='+permissionConfig.userId;
    getAjax(url,function(data){
        if(data.code===0){
            permissionConfig.hasPermission=true;
            var datas=data.rows;
            if(datas.length>0){
                datas.forEach(function(node){
                    var nodeData={};
                    nodeData["id"]=node.id;
                    if(!node.instanceName){
                        nodeData["name"]=node.resourceType;
                    }else{
                        nodeData["name"]=node.resourceType+'-'+node.instanceName;
                    }
                    nodeData.children=[
                        {"name":"first node"}
                    ];
                    nodeData.operations=node.operations;
                    nodeData.flag=false;
                    permissionConfig.nodesData.push(nodeData);
                    permissionConfig.savePermission[node.id]=node.operations;
                });
                $.fn.zTree.init($("#treeNav"), setting, permissionConfig.nodesData);
                $('#treeNav').show();
            }
        }else{
            permissionConfig.hasPermission=false;
            $('.permission-content>p').remove();
            $('.permission-content').append($('<p class="text-danger">'+data.message+'</p>'));
            return;
        }
    },function(res){
        permissionConfig.hasPermission=false;
        $('.permission-content>p').remove();
        $('.permission-content').append($('<p class="text-danger">'+res.message+'</p>'));
        return;
    })
}

function zTreeExpand(event,treeId,treeNode){
    var treeObj=$.fn.zTree.getZTreeObj('treeNav');
    permissionConfig.parentId=treeNode.id;
    $('#opertionContent').html('');
    $('#opertionDiv').hide();
    if(treeNode.flag){
        return;
    }
    getResourceChildren(treeObj,treeNode);
}

function getResourceChildren(treeObj,treeNode){
    var url='resources?assignUserId='+permissionConfig.userId+'&parentId='+permissionConfig.parentId;
    getAjax(url,function(data){
        treeObj.removeChildNodes(treeNode);
        if(data.code===0){
            var datas=data.rows;
            var childrenNodes=[];
            if(datas.length>0){
                datas.forEach(function(node){
                    var childNode={};
                    childNode.id=node.id;
                    if(node.instanceName){
                        childNode.name=node.resourceType+'-'+node.instanceName;
                    }else{
                        childNode.name=node.resourceType;
                    }
                    childNode.children=[{
                        "name":"first node"
                    }];
                    childNode.operations=node.operations;
                    childrenNodes.push(childNode);
                    permissionConfig.savePermission[node.id]=node.operations;
                });
            }
            if(childrenNodes.length>0){
                treeObj.addNodes(treeNode,childrenNodes);
            }
            treeNode.flag=true;
        }
    },function(res){
        console.log(res);
    })
}

function zTreeClick(event,treeId,treeNode){
    var id=treeNode.id;
    permissionConfig.clickNodeId=id;
    var currentOperations=[];
    currentOperations=permissionConfig.savePermission[id];
    var operationStr='';
    currentOperations.forEach(function(oper){
        var operationId=oper.id;
        var checked=oper.selected;
        if(checked){
            operationStr+='<p><input type="checkbox" class="checkboxType" value="'+operationId+'" name="checkPermission" checked/>'+oper.name+'</p>';
        }else{
            operationStr+='<p><input type="checkbox" class="checkboxType" value="'+operationId+'" name="checkPermission" />'+oper.name+'</p>';
        }
    });
    $("#opertionContent").html(operationStr);
    $("#opertionDiv").show();
}

function zTreeOnCollapse(event,treeId,treeNode){
    $('#opertionContent').html('');
    $('#opertionDiv').hide();
}

function postPermissionsAjax(postData){
    var url='authorization';
    postAjax(url,postData,function(data){
        if(data.code===0){
            permissionConfig.userId=null;
            permissionConfig.parentId=null;
            permissionConfig.savePermission={};
            permissionConfig.nodesData=[];
            permissionConfig.clickNodeId=null;
            $('.input-box input').val('');
            $('#opertionContent').html('');
            $('#opertionDiv').hide();
            $('#loadingbg').hide();
            $('#treeNav').hide();
            swal("Good~", data.message + " !", "success");
        }else{
            $('#loadingbg').hide();
            swal("Error~", data.message + " !", "error");
        }
    },function(res){
        console.log(res);
        $('#loadingbg').hide();
        swal("Error~", res.message + " !", "error");
    })
}
