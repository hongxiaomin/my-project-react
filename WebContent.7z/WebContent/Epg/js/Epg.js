var config =getConfig();
var serverIp=config.serverIp;
var epgAllMeu={};
$(function(){
    var appEpgId=getStorage('epgDetailId');
    if(appEpgId){
        var appEpgUrl='epg?epgId='+appEpgId;
        getAjax(appEpgUrl,function(data){
            var currentEpgData=data.rows[0];
            var EpgName=currentEpgData.name;
            $('.ng-EpgDetail .panel-heading').html(EpgName);
            if(currentEpgData){
                var epgDefinition=currentEpgData.epgDefinition;
                $('.epgDetailCode').text(epgDefinition);
                parseXml(appEpgId,epgDefinition);
                $('.ng-Epg').hide();
                $('.ng-EpgDetail').show();
                removeStorage("epgDetailId");
            }
        },function(res){
            console.log(res);
        })
    }

    var epgConfig=getEpgConfig();
    var epgTable=TableInit();
    epgTable(epgConfig.columns,epgConfig.url,epgConfig.qp);

    $('#btn_query').click(function(){
        $("#tb_table").bootstrapTable('refresh', {url: epgConfig.url});
    });

    $('.meuDetail .code').click(function(){
        $(this).removeClass('buttonActive').siblings().addClass('buttonActive');
        $('.epgDetailCode').show();
        $('#sample').hide();
    });
    $('.meuDetail .figure').click(function(){
        $(this).removeClass('buttonActive').siblings().addClass('buttonActive');
        $('.epgDetailCode').hide();
        $('#sample').show();
    });

    $('.EPGLIST').click(function(){
        $('.ng-Epg').show();
        $('.ng-EpgDetail').hide();
    });

    $('.epgTable').off('mouseenter','.epg_name').on('mouseenter','.epg_name',function(){
       var index=$(this).parents('tr').index();
       var tableData=$('.epgTable').bootstrapTable('getData');
       var currentData=tableData[index];
        var EpgID = currentData.id;
        var EpgName= currentData.name;
        $('.popover').remove();
        $(this).popover({
            placement:'right',
            html: true,
            title: title(EpgName+'('+EpgID+')'),
            content: function() {
                return content(EpgID);
            }
        }).on('shown.bs.popover', function(event) {
            var that = this;
            $(this).parent().find('div.popover').on('mouseenter', function() {
                $(that).attr('in', true);
            }).on('mouseleave', function() {
                $(that).removeAttr('in');
                $(that).popover('hide');

            });
        }).on('hide.bs.popover', function(event) {
            if($(this).attr('in')) {
                event.preventDefault();
            }
        }).popover('show');
    });

    $('.epgTable').off("mouseleave",'tbody tr').on("mouseleave",'tbody tr',function(event){
        event.preventDefault();
        $('div.popover').removeAttr('in');
        $('div.popover').popover('hide');
    });

    $('.epgTable').off('click','tbody tr').on('click','tbody tr',function(){
        var currentEpgData=$('.epgTable').bootstrapTable('getSelections')[0];
        var EpgName=currentEpgData.name,
            EpgID=currentEpgData.id;
        $('.ng-EpgDetail .panel-heading').html(EpgName);
        var epgListsUrl='epg?epgId='+EpgID;
        getAjax(epgListsUrl,function(data){
            var currentEpgData=data.rows[0];
            var epgDefinition=currentEpgData.epgDefinition;
            if(currentEpgData){
                $('.epgDetailCode').text(epgDefinition);
                parseXml(EpgID,epgDefinition);
                $('.ng-Epg').hide();
                $('.ng-EpgDetail').show();
                $('.operation button.code ').addClass('buttonActive');
                $('.operation button.figure ').removeClass('buttonActive');
                $('.epgDetailCode').hide();
                $('#sample').show();
            }
        },function(res){
            console.log(res);
        })
    });

    $('.epgTable').off('click','.showDetail').on('click','.showDetail',function(){
        var epgValue=$(this).html().split('(')[1].split(')')[0];
        putStorage('epgDetailId',epgValue);
        showRight('EpgLists');
        menuActive($('.menuEPG'));
    });

    $('.epgTable').on('mouseenter','.epg_meu',function(){
        var meuId = $(this).attr('data_id');
        var title=$(this).attr('data_title');
        var index=$(this).parents('tr').attr('data-index');
        var currentData=$('.epgTable').bootstrapTable('getData')[index];
        var epgId=currentData.id;
        var currentMeu=epgAllMeu[epgId][meuId];
        $('.popover').remove();
        $(this).popover({
            html: true,
            title: $('<span>' + title + '</span>'),
            placement:'left',
            content:meuContent(currentMeu)
        }).on('shown.bs.popover', function(event) {
            var that = this;
            $(this).parent().find('div.popover').on('mouseenter', function() {
                $(that).attr('in', true);
            }).on('mouseleave', function(event) {
                event.preventDefault();
                $(that).removeAttr('in');
                $(that).popover('hide');
            });
        }).on('hide.bs.popover', function(event) {
            if($(this).attr('in')) {
                event.preventDefault();
            }
        }).popover('show');
    });

    $('#tb_table').on("mouseleave",'.epg_meu',function(){
        $('div.popover').removeAttr('in');
        $('div.popover').popover('hide');
    });

});
function getEpgConfig(){
    var columns=[{
        radio: true
    }, {
        field: 'id',
        title: 'ID',
        formatter:function(value,row,index){
            return simpleId(value);
        }
    }, {
        field: 'name',
        title: 'Name',
        formatter:function(value,row,index){
            return '<span class="epg_name">'+value+'</span>';
        }
    },{
        field: 'meu',
        title: 'MEU',
        formatter:function(value,row,index){
            if(value){
                epgAllMeu[row["id"]]={};
                var meuStr='';
                value.forEach(function(meu){
                    epgAllMeu[row["id"]][meu.id+meu.containerId]=meu;
                    meuStr+='<span class="epg_meu" data_id="'+meu.id+meu.containerId+'" data_title="'+meu.id+'">'+meu.name+'</span>';
                });
                return meuStr;
            }else{
                return null;
            }

        }
    }];
    var url=serverIp+'epg';
    var queryParams=function(params){
        var num=(params.offset/params.limit)+1;
        var temp = {
            pageSize: params.limit,
            pageNumber: num,
            epgId: $(".id").val().trim(),
            name: $(".name").val().trim()
        };
        deleteObjKey(temp);
        return temp;
    };
    return {
        columns:columns,
        url:url,
        qp:queryParams
    }
}

function content(id){
    var epgUrl='epg?epgId='+id;
    getAjax(epgUrl,function(data){
        var currentEpgData=data.rows[0];
        if(currentEpgData){
            var epgDefinition=currentEpgData.epgDefinition;
            parseXml(id,epgDefinition,'table_myDiagram');
        }
    },function(res){
        console.log(res);
    });
    var data=$('#diagramPopover').html();
    return data;
}

function title(id){
    var titleStr = $('<a href="javascript:;" class="showDetail">' + id + '</a>')
    return titleStr;
}

function meuContent(currentMeu){
    var meuContentBox=$('<div class="MeuContent"></div>');
    var status=currentMeu.status?initMeuStatus(currentMeu.status):'';
    var addMeuData = $('<div><label>MEU ID:</label><span>' + currentMeu.id + '</span></div><div><label>MEU Name:</label><span>' + currentMeu.name + '</span></div><div><label>Type:</label><span>' + currentMeu.type + '</span></div><div><label>Status:</label><span>' + status + '</span></div><div><label>Container ID:</label><span>' + currentMeu.containerId + '</span></div><div><label>Description:</label><span>'+ currentMeu.description+'</span></div>');
    meuContentBox.html(addMeuData);
    return meuContentBox;
}