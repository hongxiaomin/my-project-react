var config = getConfig();
var serverIp=config.serverIp;
var filterFlag=false;
$(function(){
    // Tailor platform’s functionalities on UI and deliver more light-weight product and services.  71097 start
    // var deploymentId=getStorage('deploymentId');
    // if(deploymentId){
    //     $('.keyword').val(deploymentId);
    //     removeStorage('deploymentId');
    // }
    var logConfig=getLogConfig();
    var logTable=TableInit();
    logTable(logConfig.columns,logConfig.url,logConfig.qp);
    // Tailor platform’s functionalities on UI and deliver more light-weight product and services.  71097 start
    // if(deploymentId){
    //     $(".logTable").bootstrapTable('showColumn', 'dmClientId');
    //     $(".logTable").bootstrapTable('showColumn', 'deploymentId');
    // }

    $("#btn_query").click(function(){
        filterFlag=false;
        $(".logTable").bootstrapTable('hideColumn', 'stacktrace');
        // Tailor platform’s functionalities on UI and deliver more light-weight product and services.  71097 start
        // $(".logTable").bootstrapTable('hideColumn', 'dmClientId');
        // $(".logTable").bootstrapTable('hideColumn', 'deploymentId');
        $(".logTable").bootstrapTable('refresh', {url: logConfig.url});
    });

    $('.have-search').multiselect({
        numberDisplayed:3,
        buttonWidth:'100%',
        maxHeight:200,
        includeSelectAllOption:true,
        enableFiltering:true,
        selectedClass: 'active-select',
        dropRight: true
    });

    $('.no-search').multiselect({
        numberDisplayed:3,
        buttonWidth:'100%',
        maxHeight:200,
        includeSelectAllOption:false,
        enableFiltering:false,
        selectedClass: 'active-select',
        dropRight: true
    });

    $('.filter_note').click(function(){
        filterFlag=true;
        $(".logTable").bootstrapTable('showColumn', 'stacktrace');
        $(".logTable").bootstrapTable('refresh', {url: logConfig.url});
    });

    $('.logTable').off('mouseenter','.log_class').on('mouseenter','.log_class',function(event){
        if($(this).html()==='-'){
            return;
        }
        showPopover.call(this,event,'Class','left');
    });

    $('.logTable').off("mouseleave",'.log_class').on("mouseleave",'.log_class',function(event){
        hidePopover(event);
    });

    $('.logTable').off('mouseenter','.log_thread').on('mouseenter', '.log_thread', function(event) {
        if($(this).html()==='-'){
            return;
        }
        showPopover.call(this,event,'Thread','left');
    });

    $('.logTable').off("mouseleave",'.log_thread').on("mouseleave",'.log_thread',function(event){
        hidePopover(event);
    });

    $('.logTable').off('mouseenter','.log_message').on('mouseenter', '.log_message',function(event){
        if($(this).html()==='-'){
            return;
        }
        showPopover.call(this,event,'Message','top');
    });

    $('.logTable').off("mouseleave",'.log_message').on("mouseleave",'.log_message',function(event){
        hidePopover(event);
    });

    $('.logTable').off('mouseenter','.log_stacktrace').on('mouseenter', '.log_stacktrace',function(event){
        if($(this).html()==='-'){
            return;
        }
        showPopover.call(this,event,'Stacktrace','top');
    });

    $('.logTable').off("mouseleave",'.log_stacktrace').on("mouseleave",'.log_stacktrace',function(event){
        hidePopover(event);
    });

    getAjax('meu',function(data){
        if(data.code===0){
            var str='';
            data.rows.forEach(function(item){
                if(item.name){
                    str+='<option value="'+item.id+'">'+item.name+'</option>';
                }
            });
            $('#txt_search_meuId').html(str).multiselect('rebuild');
        }
    },function(res){
        console.log(res);
    });

    getAjax('app',function(data){
        if(data.code===0){
            var str='';
            data.rows.forEach(function(item){
                if(item.name){
                    str+='<option value="'+item.id+'">'+item.name+'</option>';
                }
            });
            $('#txt_search_appId').html(str).multiselect('rebuild');
        }
    },function(res){
        console.log(res);
    });

    getAjax('epg',function(data){
        if(data.code===0){
            var str='';
            data.rows.forEach(function(item){
                if(item.name){
                    str+='<option value="'+item.id+'">'+item.name+'</option>';
                }
            });
            $('#txt_search_epgId').html(str).multiselect('rebuild');
        }
    },function(res){
        console.log(res);
    });

    getAjax('container',function(data){
        if(data.code===0){
            var str='';
            data.rows.forEach(function(item){
                if(item.webUrl){
                    str+='<option value="'+item.id+'">'+item.name+'('+item.webUrl+')</option>';
                }else{
                    str+='<option value="'+item.id+'">'+item.name+'</option>';
                }
            });
            $('#txt_search_containerId').html(str).multiselect('rebuild');
        }
    },function(res){
        console.log(res);
    });

});

function getLogConfig(){
    var columns=[{
        radio: true
    },{
        field: 'timestamp',
        title: 'TimeStamp'
    },{
        field: 'message',
        title: 'Message',
        formatter:function(logMessage,row,index){
            logMessage=resetValue(logMessage);
            return tableContent('log_message',logMessage);
        }
    },{
        field: 'stacktrace',
        title: 'Stacktrace',
        formatter:function(logStacktrace,row,index){
            logStacktrace=resetValue(logStacktrace);
            return tableContent('log_stacktrace',logStacktrace);
        },
        visible:false
    },{
        field: 'level',
        title: 'Level'
    },
    // Tailor platform’s functionalities on UI and deliver more light-weight product and services.  71097 start
    // {
    //     field: 'dmClientId',
    //     title: 'DM Client ID',
    //     visible:false
    // },
    // {
    //     field: 'deploymentId',
    //     title: 'Deployment ID',
    //     visible:false
    // },
    {
        field: 'class',
        title: 'Class',
        formatter:function(logClass,row,index){
            logClass=resetValue(logClass);
            return tableContent('log_class',logClass);
        }
    },{
        field: 'thread',
        title: 'Thread',
        visible:false,
        formatter:function(logThread,row,index){
            logThread=resetValue(logThread);
            return tableContent('log_thread',logThread);
        }
    },{
        field: 'logName',
        title: 'LogName',
        visible:false
    },{
        field: 'appId',
        title: 'App ID',
        visible:false
    },{
        field: 'epgId',
        title: 'EPG ID',
        visible:false
    },{
        field: 'meuId',
        title: 'MEU ID',
        visible:false
    },{
        field: 'containerId',
        title: 'Container ID',
        visible:false
    },{
        field: 'executionId',
        title: 'Execution ID',
        visible:false
    }];
    var url=serverIp+'log';
    var queryParams=function(params){
        var num=(params.offset/params.limit)+1;
        var meuId=[],appId=[],epgId=[],containerId=[],
            executionId=[],level=[],type=[],startTime='',endTime='',keyword='';
        if($('#txt_search_meuId').val()){
            meuId=$('#txt_search_meuId').val();
        }
        if($('#txt_search_epgId').val()){
            epgId=$('#txt_search_epgId').val();
        }
        if($('#txt_search_appId').val()){
            appId=$('#txt_search_appId').val();
        }
        if($('#txt_search_containerId').val()){
            containerId=$('#txt_search_containerId').val();
        }
        if($('#txt_search_executionId').val()){
            executionId=[$('#txt_search_executionId').val().trim()]
        }
        if($('#txt_search_level').val()){
            levelArr=$('#txt_search_level').val();
            levelArr.forEach(function(item){
                level.push(parseInt(item));
            })
        }
        if($('#txt_search_type').val()){
            typeArr=$('#txt_search_type').val();
            typeArr.forEach(function(item){
                type.push(parseInt(item));
            })
        }
        if($('#txt_search_meuId').val()){
            meuId=$('#txt_search_meuId').val();
        }
        startTime=$('.startTime').val()?$('.startTime').val():'';
        endTime=$('.endTime').val()?$('.endTime').val():'';
        keyword=$('.keyword').val()?$('.keyword').val():'';
        if(filterFlag){
            meuId=[];
            appId=[];
            epgId=[];
            containerId=[];
            executionId=[];
            keyword='error exception';
            level=[4];
            type=[];
            startTime=timeFormat(Date.now()-1000*300);//5分钟内的数据
            endTime='';
        }
        var temp = {
            pageSize: params.limit,
            pageNumber: num,
            query:JSON.stringify({
                meuId:meuId,
                appId:appId,
                epgId:epgId,
                containerId:containerId,
                executionId:executionId,
                level:level,
                type:type,
                startTime:startTime,
                endTime:endTime,
                queryString:keyword
            })
        };
        return temp;
    };
    return {
      columns:columns,
        url:url,
        qp:queryParams
    }
}

function tableContent(className,content){
    return '<p class="'+className+'">'+content+'</p>'
}

function timeFormat(time){
    time=new Date(time);
    var year=time.getFullYear();
    var month=time.getMonth()+1;
    var day=time.getDate();
    var hour=time.getHours();
    var mins=time.getMinutes();
    var secs=time.getSeconds();
    return year+'-'+month+'-'+day+' '+hour+':'+mins+':'+secs;
}