var config=getConfig();
var serverIp = config.serverIp;
var deployConfig={
    fileObj:{},
    fileArr:[],
    putFlag:false,
    appId:'',
    deploymentId:'',
    allMeu:{},
    allContainer:{},
    selectContainerName:null,
    editName:null,
    hasContainerName:false,
    relContainerMeu:null,
    deploySuc:false,
    timer:{
        interval:null,
        timeout:null
    },
    configurationAjax:null,
    deployAjax:null,
    progressAjax:null,
    isDeployCompleted:false
};

$(function () {
    var deployObj=getStorage('deployObj');
    if(deployObj) {
        deployObj = JSON.parse(deployObj);
        deployConfig.appId = deployObj.appId;
    }
    $('#wizard').steps({
        headerTag: "h3",
        bodyTag: "section",
        transitionEffect: "slideLeft",
        onStepChanging:function(event,currentIndex,newIndex){
            if(currentIndex===0&&newIndex===1){
                var flag1=false;
                if(deployConfig.fileObj.name){
                    $('#loadingbg').show();
                    $("#uploadForm1 .appId").val(deployConfig.appId);

                    if(deployObj&&!deployConfig.putFlag){
                        putForm(function(){
                            $("#wizard").steps("next", true);
                        });
                    }else if(deployObj&&deployConfig.putFlag){
                        flag1=true;
                    }else{
                        if(deployConfig.fileArr.length===0){
                           postForm(function(){
                               $("#wizard").steps("next", true);
                           });
                        }else{
                            if(deployConfig.fileArr[0]["name"]!==deployConfig.fileObj["name"]||deployConfig.fileArr[0]["date"]!==deployConfig.fileObj["date"]){
                                // postForm(function(){
                                //     $("#wizard").steps("next", true);
                                // });
                                putForm(function(){
                                    $("#wizard").steps("next", true);
                                });
                            }else{
                                flag1=true;
                            }
                        }
                    }
                }else{
                    $(".msg").show();
                    flag1=false;
                }
                return flag1;
            }else if(currentIndex===1&&newIndex===0){
                if(deployConfig.isDeployCompleted){
                    return false;
                }else{
                    return true;
                }
            }else if(currentIndex===1&&newIndex===2){
                var flag2=true;
                for(var key in deployConfig.allMeu){
                    flag2=false;
                    break;
                }
                return flag2;
            }else if(currentIndex===2&&newIndex===1){
                deployConfig.deploySuc=false;
                if(deployConfig.isDeployCompleted){
                    return false;
                }else{
                    return true;
                }
            }
        },
        onStepChanged:function(event,currentIndex,priorIndex){
            if(priorIndex===0&&currentIndex===1){
                deployConfig.putFlag=false;
                getConfiguration(function(){
                    showMeu();
                    showContainer();
                });
            }else if(priorIndex===1&&currentIndex===2){
                showCMTree();
            }
        },
        onFinishing:function(event,currentIndex){
            var finishFlag=false;
            if(currentIndex===2){
                if(deployConfig.isDeployCompleted){
                    finishFlag=false;
                }else{
                    var deployData={
                        appId:deployConfig.appId,
                        containers:deployConfig.relContainerMeu
                    };
                    deployData=JSON.stringify(deployData);
                    if(!deployConfig.deploySuc){
                        postContainerData(deployData,function(){
                            $("#wizard").steps("finish");
                        });
                    }else{
                        finishFlag=true;
                    }
                }
            }
            return finishFlag;
        },
        onFinished:function(event,currentIndex){
            if(!deployConfig.deploySuc){
                return;
            }
            deployConfig.isDeployCompleted=true;
            var deployUrl='deployment/app?appId=' + deployConfig.appId;
            deployConfig.deployAjax=postTextAjax(deployUrl,function(data){
                if(data.code===0){
                    deployConfig.deploymentId=data.rows.deploymentId;
                    $('.deploypageContent').hide();
                    $('.actions a').css({
                        'cursor':'text',
                        'background':'#eee',
                        'color':'#aaa'
                    });
                    $('.actions a').css('cursor', 'text');
                    $('#tips').css('right',0);
                    setTimeout(function(){
                        $('#tips').css('right',-500);
                    },5000);
                    $('.totalpage').show(showProgress);
                }else{
                    swal("Error~", data.message+" !", "error");
                }
            },function(res){
                console.log(res);
                swal("Error~", res.message+" !", "error");
            })
        }
    });



    $('#uploadForm').change(function(){
        var file=this.files[0];
        if(file){
            var name=file.name;
            var lastDate=file.lastModified;
            deployConfig.fileObj["name"]=hex_md5(name);
            deployConfig.fileObj["date"]=lastDate;
            if(name){
                $('.msg').hide();
                $('#browseText').val(name);
            }
        }else{
            deployConfig.fileObj["name"]='';
            deployConfig.fileObj["date"]=0;
            $('#browseText').val('');
        }
    });

    $('#meuListAll').on('click','li',function(){
        if(
            $(this).find('input').get(0).checked
        ){
            $('.transfer-operation .right').addClass('active');
        }
        var allMeu=$('#meuListAll input');
        var checkAllLeft=true;
        var transferRight=true;
        for(var i=0;i<allMeu.length;i++){
            if(allMeu.eq(i).get(0).checked){
                transferRight=false;
            }else{
                checkAllLeft=false;
            }
        }
        if(checkAllLeft){
            $('#allcheck1').prop('checked',true);
        }else{
            $('#allcheck1').prop('checked',false);
        }

        if(transferRight){
            $('.transfer-operation .right').removeClass('active');
        }
    });
    $('#MeuDetail').on('click','li',function(){
        if($(this).find('input').get(0).checked){
            $('.transfer-operation .left').addClass('active');
        }
        var allMeu=$('#MeuDetail input');
        var checkAllRight=true;
        var transferLeft=true;
        for(var i=0;i<allMeu.length;i++){
            if(allMeu.eq(i).get(0).checked){
                transferLeft=false;
            }else{
                checkAllRight=false;
            }
        }
        if(checkAllRight){
            $('#allcheck2').prop('checked',true);
        }else{
            $('#allcheck2').prop('checked',false);
        }

        if(transferLeft){
            $('.transfer-operation .left').removeClass('active');
        }
    });

    $('.allcheck1').click(function(){
        checkAll.call(this,$('#meuListAll input'),$('.transfer-operation .right'));
    });

    $('.allcheck2').click(function(){
        checkAll.call(this,$('#MeuDetail input'),$('.transfer-operation .left'));
    });

    $('.transfer-operation .right').click(function(){
        var checkedLis=[];
        var currentContainer=deployConfig.allContainer[deployConfig.selectContainerName];
        for(var i=0;i<$('#meuListAll li').length;i++){
            var checked=$('#meuListAll li').eq(i).find('input').get(0).checked;
            if(checked){
                checkedLis.unshift($('#meuListAll li').eq(i))
            }
        }

        if(checkedLis.length>0){
            if(!currentContainer.meu){
                currentContainer.meu=[];
            }
            checkedLis.forEach(function(li){
                li.find('input').prop('checked',false);
                li.prependTo($('#MeuDetail'));
                var meuId=li.attr('data-id');
                currentContainer.meu.push(deployConfig.allMeu[meuId]);
                delete deployConfig.allMeu[meuId];
            });
            $(this).removeClass('active');
            $('.transfer-operation .left').removeClass('active');
            $('#allcheck1').prop('checked',false);
            $('#allcheck2').prop('checked',false);
        }
    });

    $('.transfer-operation .left').on('click',function(){
        var checkedLis=[];
        var currentContainer=deployConfig.allContainer[deployConfig.selectContainerName];
        var currentMeu=currentContainer.meu;
        for(var i=0;i<$('#MeuDetail li').length;i++){
            var checked=$('#MeuDetail li').eq(i).find('input').get(0).checked;
            if(checked){
                checkedLis.unshift($('#MeuDetail li').eq(i));
            }
        }
        if(checkedLis.length>0){
            checkedLis.forEach(function(li){
                li.find('input').prop('checked',false);
                li.prependTo($('#meuListAll'));
                var dataId=li.attr('data-id');
                currentMeu=currentMeu.filter(function(meu,i){
                    if(meu.meuId===dataId){
                        deployConfig.allMeu[dataId]=meu;
                    }
                    return meu.meuId!==dataId;
                });
            });
            deployConfig.allContainer[deployConfig.selectContainerName].meu=currentMeu;
            $(this).removeClass('active');
            $('.transfer-operation .right').removeClass('active');
            $('#allcheck1').prop('checked',false);
            $('#allcheck2').prop('checked',false);
        }
    });

    $('#editContainer').click(function(){
        var currentContainer=deployConfig.allContainer[deployConfig.selectContainerName];
        var containerName=currentContainer.containerName;
        var configuration=currentContainer.configuration;
        var maxTryCount='';
        var maxTryTiming='';
        if(configuration){
            if(configuration.maxTryCount){
                maxTryCount=configuration.maxTryCount;
            }
            if(configuration.maxTryTiming){
                maxTryTiming=configuration.maxTryTiming;
            }
        }
        $('#creatContainer input[name=containerName]').val(containerName);
        $('#creatContainer input[name=retryCount]').val(maxTryCount);
        $('#creatContainer input[name=waitTime]').val(maxTryTiming);
        deployConfig.editName=deployConfig.selectContainerName;
    });

    $('#saveContainer').click(function(){
        var name=$('#creatContainer input[name=containerName]').val().trim();
        var maxTryCount=$('#creatContainer input[name=retryCount]').val();
        var maxTryTiming=$('#creatContainer input[name=waitTime]').val();
        if(!name){
            $('#nameInfo').removeClass('hide').html('The name parameter must exist');
            return false;
        }

        if(deployConfig.hasContainerName){
            if(!deployConfig.editName){
                return false;
            }
        }

        if(!deployConfig.editName){
            var containerObj={};
            containerObj.canEdit=true;
            containerObj.meu=[];
            containerObj.canAssign=true;
            containerObj.configuration={};
            containerObj.containerName=name;
            if(maxTryCount){
                containerObj.configuration.maxTryCount=maxTryCount;
            }
            if(maxTryTiming){
                containerObj.configuration.maxTryTiming=maxTryTiming;
            }
            deployConfig.allContainer[name]=containerObj;
        }else{
            var editContainer=deployConfig.allContainer[deployConfig.editName];
            editContainer.containerName=name;
            if(!editContainer.configuration){
                editContainer.configuration={};
            }
            if(maxTryCount){
                editContainer.configuration.maxTryCount=maxTryCount;
            }
            if(maxTryTiming){
                editContainer.configuration.maxTryTiming=maxTryTiming;
            }
            if(name===deployConfig.editName){
                deployConfig.allContainer[deployConfig.editName]=editContainer;
            }else{
                deployConfig.allContainer[name]=editContainer;
                delete deployConfig.allContainer[deployConfig.editName];
            }
        }

        $('#creatContainer input').val('');
        $('#creatContainer input[name=retryCount]').val(5);
        $('#creatContainer input[name=waitTime]').val(30);
        $('#creatContainer').modal('hide');
        $('.transfer-operation').hide();
        deployConfig.selectContainerName=null;
        deployConfig.editName=null;
        $('#editContainer').hide();
        showContainer();
        showMeu();
    });

    $('#cancelContainer').click(function(){
        initContainerConfig();
    });

    $('.close').click(function(){
        initContainerConfig();
    });

    $('.transfer-select').on('click',function(){
        $('.transfer-select span').toggleClass('glyphicon-triangle-top');
        $('.container_list').slideToggle();
    });

    $('.container_list ').on('click','li',function(){
        var name=$(this).html();
        $('#container').val(name);
        deployConfig.selectContainerName=name;
        var canEdit=deployConfig.allContainer[name].canEdit;
        if(canEdit){
            $('#editContainer').show();
        }else{
            $('#editContainer').hide();
        }
        showMeu(name);
    });

    $('#creatContainer input[name=containerName]').blur(function(){
        var containerName=$(this).val().trim();
        if(containerName){
            var url='container/validation?name='+containerName;
            getAjax(url,function(data){
                if(data.code===0){
                    if(!data.rows.result){
                        $('#nameInfo').removeClass('hide').html(data.message);
                        deployConfig.hasContainerName=true;
                        return;
                    }
                }
                var lis=$('.container_list li');
                for(var i=0;i<lis.length;i++){
                    var text=lis.eq(i).text();
                    if(text===containerName){
                        $('#nameInfo').removeClass('hide').html('The name '+containerName+' is already exists');
                        deployConfig.hasContainerName=true;
                        return;
                    }
                }

                $('#nameInfo').addClass('hide');
                deployConfig.hasContainerName=false;
            })
        }
    });
    
//    Tailor platform’s functionalities on UI and deliver more light-weight product and services.  71097 start
    // $('.totaltable').off('click','.deployInfo').on('click','.deployInfo',function(){
    //     var value=$(this).val();
    //     var reg=/Deployment\s*ID\s*=\s*\[([a-z0-9-]+)\]/g;
    //     if(reg.test(value)){
    //         var deploymentId=/Deployment\s*ID\s*=\s*\[([a-z0-9-]+)\]/g.exec(value)[1];
    //         if(deploymentId){
    //             putStorage('deploymentId',deploymentId);
    //             showRight('logList');
    //             menuActive($('.menuLogList'));
    //         }
    //     }
    // });


    $('#apps-lists').click(function(){
        initDeploy();
        showRight('apps');
        menuActive('.menuList');
    });

    $('.nav-parent').click(function(){
        initDeploy();
        clearTimer();
        abortAjax();
    });

    $('.children li').on('click',function(){
        initDeploy();
        clearTimer();
        abortAjax();
    });
});

function initContainerConfig(){
    deployConfig.editName=null;
    $('#creatContainer input').val('');
    $('#creatContainer input[name=retryCount]').val(5);
    $('#creatContainer input[name=waitTime]').val(30)
}

function putForm(callback){
    $('#uploadForm1').ajaxSubmit({
        type:"put",
        dataType:"json",
        url:serverIp+'app/package',
        success:function(data){
            if(data.code===0){
                deployConfig.putFlag=true;
                callback();
            }else if(data.code===-1){
                $('#loadingbg').hide();
                swal("Error~", data.message + " !", "error");
            }
        },
        error:function(data){
            data=JSON.parse(data.responseText);
            $('#loadingbg').hide();
            swal("Error~", data.message + " !", "error");
        }
    });
}

function postForm(callback){
    $('#uploadForm1').ajaxSubmit({
        type:"post",
        dataType:"json",
        url:serverIp+'app/package',
        success:function(data){
            if(data.code===0){
                deployConfig.appId=data.rows.id;
                deployConfig.fileArr[0]=deepClone(deployConfig.fileObj);
                callback();
            }else{
                $('#loadingbg').hide();
                swal("Error~", data.message + " !", "error");
            }
        },
        error:function(data){
            data=JSON.parse(data.responseText);
            $('#loadingbg').hide();
            swal("Error~", data.message + " !", "error");
        }
    });
}

function getConfiguration(callback){
    var url='app/configuration?appId='+deployConfig.appId;
    getAjax(url,function(data){
        deployConfig.allMeu={};
        deployConfig.allContainer={};
        if(data.code===0){
            var meus=data.rows.meus;
            var containers=data.rows.containers;
            meus.forEach(function(meu){
                deployConfig.allMeu[meu.meuId]=meu;
            });

            containers.forEach(function(container){
                deployConfig.allContainer[container.containerName]=container;
            });
            $('#loadingbg').hide();
            callback();
        }

    },function(res){
        console.log(res);
    })
}

function showMeu(name){
    $('#meuListAll').empty();
    $('#MeuDetail').empty();
    if(!name){
        $('.transfer-operation').hide();
    }else{
        var canAssign=deployConfig.allContainer[name].canAssign;
        if(canAssign){
            $('.transfer-operation').show();
        }else{
            $('.transfer-operation').hide();
        }
    }

    for(var key in deployConfig.allMeu){
        var currentMeu=deployConfig.allMeu[key];
        var meuName=currentMeu.meuName?currentMeu.meuName:'-';
        var li=$('<li data-id="'+key+'"><div><input type="checkbox"  id="'+key+'" value="'+key+'" /><label for="'+key+'">'+meuName+'</label></div></li>');
        li.appendTo($('#meuListAll'));
    }

    if(name){
        var innerMeu=deployConfig.allContainer[name];
        if('meu' in innerMeu){
            innerMeu["meu"].forEach(function(meu){
                var li=$('<li data-id="'+(meu.meuId)+'"><div><input type="checkbox"  id="'+(meu.meuId)+'" value="'+(meu.meuId)+'" /><label for="'+(meu.meuId)+'">'+(meu.meuName)+'</label></div></li>');
                li.appendTo($('#MeuDetail'));
            });
        }
    }
    $('#allcheck1').prop('checked',false);
    $('#allcheck2').prop('checked',false);
}

function showContainer(){
    $('#container').val('');
    $('.container_list').empty();
    var data=[];
    for(var key in deployConfig.allContainer){
        data.push(deployConfig.allContainer[key]);
    }
    data.forEach(function(item){
        var li=$('<li data-edit="'+item.canEdit+'">'+item.containerName+'</li>');
        li.appendTo($('.container_list'));
    })
}

function checkAll(ele,opera){
    var check=$(this).children('input').get(0).checked;
    for(var i=0;i<ele.length;i++){
        ele.eq(i).prop("checked",check);
    }
    if(check){
        opera.addClass('active');
    }else{
        opera.removeClass('active');
    }
}

function showCMTree(){
    var setting={};
    var containerNodes=[];
    var postContainerData=[];
    for(var key in deployConfig.allContainer){
        var currentContainer=deployConfig.allContainer[key];
        var containerNode={};
        var postData={};
        containerNode.name=currentContainer.containerName;
        containerNode.open=true;
        containerNode.children=[];

        postData.containerName=currentContainer.containerName;
        if(currentContainer.configuration){
            postData.configuration=currentContainer.configuration;
        }
        postData.meus=[];
        if(!currentContainer.meu){
            currentContainer.meu=[];
        }
        if(currentContainer.meu.length===0){
            containerNode.isParent=true;
        }
        for(var m=0;m<currentContainer.meu.length;m++){
            var currentMeu=currentContainer.meu[m];
            var childNode={};
            childNode.name=currentMeu.meuName;
            containerNode.children.push(childNode);
            postData.meus.push(currentMeu);
        }
        containerNodes.push(containerNode);

        for(var key in postData){
            if(key==='meus'){
                if(postData.meus.length>0){
                    postContainerData.push(postData);
                }
            }
        }

    }
    deployConfig.relContainerMeu=postContainerData;
    var treeObj=$.fn.zTree.getZTreeObj('treeContainer');
    $(document).ready(function(){
        $.fn.zTree.init($("#treeContainer"), setting,containerNodes);
    });
}

function postContainerData(deployData,callback){
    deployConfig.deploySuc=true;
    var configurationUrl='app/configuration';
    deployConfig.configurationAjax=postAjax(configurationUrl,deployData,function(data){
        if(data){
            if(data.code===0){
                callback();
            }
        }
    },function(res){
        console.log(res);
        swal("Error~", res.message+"!", "error");
        deployConfig.deploySuc=false;
    })
}

function showProgress(){
    timekeeper(deployConfig.timer,function(){
        swal("Error~", "Deploy Failed!", "error");
    },function(){
        var url='deployment/progress?deploymentId=' + deployConfig.deploymentId;
        getProgress(url,deployConfig.progressAjax,deployConfig.appId,deployConfig.timer,function(){
            swal("Good~", "Deploy Success" + " !", "success");
            initDeploy();
        },function(){
            swal("Error~", "Deploy Failed !", "error");
            initDeploy();
        });
    });
}

function clearTimer(){
    clearInterTimer(deployConfig.timer.interval);
    clearOutTimer(deployConfig.timer.timeout);
}

function initDeploy(){
    removeStorage('deployObj');
}

function abortAjax(){
    if(deployConfig.configurationAjax){
        deployConfig.configurationAjax.abort();
        if(deployConfig.deployAjax){
            deployConfig.deployAjax.abort();
            if(deployConfig.progressAjax){
                deployConfig.progressAjax.abort();
            }
        }
    }
}