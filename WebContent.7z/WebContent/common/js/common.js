//common config
function getConfig(){
    var l=window.location;
    var p=l.protocol;
    var h=l.hostname;
    var port=l.port?':'+l.port:'';
    var serverUrl=p+'//'+h+port;
    var serverIp=serverUrl+'/api/';
    // var serverIp='http://172.22.34.40:8090/api/';
    return {serverUrl:serverUrl,serverIp:serverIp};
}
//common function
function isLetterAndNum(str){ //num and letter
    var reg=/^[A-Za-z0-9]*$/;
    return reg.test(str);
}

function checkFormNull(className) { //Validation is not empty
    pass = true;
    $(className).find("label:contains('*')").next('input[type=password]').each(function(){
        if($(this).val() ==='') {
            text = $(this).prev().text()+"is Required~";
            this.focus();
            $(className).find('.warnMsg').show().html(text);
            pass = false;
            return false;//jump each
        }
    });
    return pass;
}

//存储cookies
//存储cookies
function putStorage(key,value){
    window.localStorage.setItem(key, value);
}
function getStorage(key){
    return window.localStorage.getItem(key);
}
function removeStorage(key){
    window.localStorage.removeItem(key);
}

//setCookie
function setCookie(name,value){
    const Days=30;
    const exp=new Date();
    exp.setTime(exp.getTime()+Days*24*60*60*1000);
    document.cookie=name+'='+escape(value)+';expires='+exp.toGMTString();
}

//getCookie
function getCookie(name){
    var arr,reg=new RegExp("(^| )"+name+"=([^;]*)(;|$)");
    if(arr=document.cookie.match(reg)){
        return unescape(arr[2]);
    }else{
        return null;
    }
}

//delete cookie
function delCookie(name){
    var exp=new Date();
    exp.setTime(exp.getTime()-1);
    var cval=getCookie(name);
    if(cval!==null){
        document.cookie=name + "="+cval+";expires="+exp.toGMTString();
    }
}

function isClass(obj){
    if(obj === null) {
        return 'Null';
    } else if(obj === 'undefined') {
        return 'Undefined';
    }
    return Object.prototype.toString.call(obj).slice(8, -1);
}

function deepClone(obj){
    if(typeof(obj) !== 'object' || obj === null) {
        return obj;
    }
    var newObj = {};
    if(isClass(obj) === 'Object') {
        newObj = {};
    } else if(isClass(obj) === 'Array') {
        newObj = [];
    }
    for(var key in obj) {
        newObj[key] = deepClone(obj[key]);
    }
    return newObj;
}

function clearInterTimer(timer){
    clearInterval(timer);
    timer=null;
}
function clearOutTimer(timer){
    clearTimeout(timer);
    timer=null;
}
function loadPage(text,url){
    $('.children li').removeClass('homeActive');
    for(var i = 0; i < $('.nav-parent').length; i++) {
        if($('.nav-parent').eq(i).children('a').text() === text) {
            $('.nav-parent').eq(i).next().children('li').eq(0).addClass('homeActive');
            break;
        }
    }
    $('#rightPanel').load(url);
}
function menuActive(ele){
    $('.nav li').removeClass('homeActive');
    $(ele).addClass('homeActive');
    if($(ele).hasClass('second-nav')){
        $(ele).next().slideDown(500);
        $(ele).children().children().eq(1).attr('class','pull-right glyphicon glyphicon-minus');
    }
    $(ele).parent('ul').slideDown(500);
}

function GenNonDuplicateID(){
    var idStr=Date.now().toString(16);
    idStr+=Math.random().toString(16).substr(2);
    return 'Epg-'+idStr;
}

function getNonDuplicateID(){
    var idStr=Date.now().toString(16);
    idStr+=Math.random().toString(16).substr(2);
    return 'Event-'+idStr;
}

//json转化为xml
function json2xml(o, tab){
    const toXml = function(v, name, ind){
        var xml = "";
        if(v instanceof Array){
            for(var i=0, n=v.length; i<n; i++){
                xml += ind + toXml(v[i], name, ind+"\t");
            }
        }else if(typeof(v) === "object"){
            var hasChild = false;
            xml += ind + "<" + name;
            for(var m in v){
                if(m.charAt(0) === "@"){
                    xml += " " + m.substr(1) + "=\"" + v[m].toString() + "\"";
                }else{
                    hasChild = true;
                }
            }
            xml += hasChild ? ">\n" : "/>\n";
            if(hasChild){
                for(var m in v){
                    if(m ==="#text"){
                        xml += v[m];
                    }else if(m === "#cdata"){
                        xml += "<![CDATA[" + v[m] + "]]>";
                    }else if(m.charAt(0) !== "@"){
                        xml += toXml(v[m], m, ind+"\t");
                    }
                }
                xml += (xml.charAt(xml.length-1)==="\n"?ind:"") + "</" + name + ">\n";
            }
        }else{
            xml += ind + "<" + name + ">\n" + v.toString() +  "</" + name + ">\n";
        }
        return xml;
    };
    var xml="";
    for(var m in o){
        xml += toXml(o[m], m, "");
    }
    return tab ? xml.replace(/\t/g, tab) : xml.replace(/\t/g, "");
};

//xml String 转化为 xml 对象
function parseXMLObj(data){
    var xml, tmp;
    if (window.DOMParser) { // Standard
        tmp = new DOMParser();
        xml = tmp.parseFromString(data, "text/xml");
    } else { // IE
        xml = new ActiveXObject("Microsoft.XMLDOM");
        xml.async = "false";
        xml.loadXML(data);
    }
    tmp = xml.documentElement;
    if (!tmp || !tmp.nodeName || tmp.nodeName === "parsererror") {
        return null;
    }
    return xml;
}

//xml对象转化为 JSON
function xml2json(xml, tab){
    var X = {
        toObj: function(xml){
            var o = {};
            if (xml.nodeType===1) {   // element node ..
                if (xml.attributes.length)   // element with attributes  ..
                    for (var i=0; i<xml.attributes.length; i++){
                        o["@"+xml.attributes[i].nodeName] = (xml.attributes[i].nodeValue||"").toString();
                    }
                if (xml.firstChild) { // element has child nodes ..
                    var textChild=0, cdataChild=0, hasElementChild=false;
                    for (var n=xml.firstChild; n; n=n.nextSibling) {
                        if (n.nodeType===1) hasElementChild = true;
                        else if (n.nodeType===3 && n.nodeValue.match(/[^ \f\n\r\t\v]/)) textChild++; // non-whitespace text
                        else if (n.nodeType===4) cdataChild++; // cdata section node
                    }
                    if (hasElementChild) {
                        if (textChild < 2 && cdataChild < 2) { // structured element with evtl. a single text or/and cdata node ..
                            X.removeWhite(xml);
                            for (var n=xml.firstChild; n; n=n.nextSibling) {
                                if (n.nodeType === 3)  // text node
                                    o["#text"] = X.escape(n.nodeValue);
                                else if (n.nodeType === 4)  // cdata node
                                    o["#cdata"] = X.escape(n.nodeValue);
                                else if (o[n.nodeName]) {  // multiple occurence of element ..
                                    if (o[n.nodeName] instanceof Array)
                                        o[n.nodeName][o[n.nodeName].length] = X.toObj(n);
                                    else
                                        o[n.nodeName] = [o[n.nodeName], X.toObj(n)];
                                }
                                else  // first occurence of element..
                                    o[n.nodeName] = X.toObj(n);
                            }
                        }
                        else { // mixed content
                            if (!xml.attributes.length)
                                o = X.escape(X.innerXml(xml));
                            else
                                o["#text"] = X.escape(X.innerXml(xml));
                        }
                    }
                    else if (textChild) { // pure text
                        if (!xml.attributes.length)
                            o = X.escape(X.innerXml(xml));
                        else
                            o["#text"] = X.escape(X.innerXml(xml));
                    }
                    else if (cdataChild) { // cdata
                        if (cdataChild > 1)
                            o = X.escape(X.innerXml(xml));
                        else
                            for (var n=xml.firstChild; n; n=n.nextSibling)
                                o["#cdata"] = X.escape(n.nodeValue);
                    }
                }
                if (!xml.attributes.length && !xml.firstChild) o = null;
            }
            else if (xml.nodeType===9) { // document.node
                o = X.toObj(xml.documentElement);
            }
            else
//      	alert("unhandled node type: " + xml.nodeType);
                console.log(xml.nodeType);
            return o;
        },
        toJson: function(o, name, ind) {
            var json = name ? ("\""+name+"\"") : "";
            if (o instanceof Array) {
                for (var i=0,n=o.length; i<n; i++)
                    o[i] = X.toJson(o[i], "", ind+"\t");
                json += (name?":[":"[") + (o.length > 1 ? ("\n"+ind+"\t"+o.join(",\n"+ind+"\t")+"\n"+ind) : o.join("")) + "]";
            }
            else if (o === null)
                json += (name&&":") + "null";
            else if (typeof(o) === "object") {
                var arr = [];
                for (var m in o)
                    arr[arr.length] = X.toJson(o[m], m, ind+"\t");
                json += (name?":{":"{") + (arr.length > 1 ? ("\n"+ind+"\t"+arr.join(",\n"+ind+"\t")+"\n"+ind) : arr.join("")) + "}";
            }
            else if (typeof(o) === "string")
                json += (name&&":") + "\"" + o.toString() + "\"";
            else
                json += (name&&":") + o.toString();
            return json;
        },
        innerXml: function(node) {
            var s = "";
            if ("innerHTML" in node)
                s = node.innerHTML;
            else {
                var asXml = function(n) {
                    var s = "";
                    if (n.nodeType === 1) {
                        s += "<" + n.nodeName;
                        for (var i=0; i<n.attributes.length;i++)
                            s += " " + n.attributes[i].nodeName + "=\"" + (n.attributes[i].nodeValue||"").toString() + "\"";
                        if (n.firstChild) {
                            s += ">";
                            for (var c=n.firstChild; c; c=c.nextSibling)
                                s += asXml(c);
                            s += "</"+n.nodeName+">";
                        }
                        else
                            s += "/>";
                    }
                    else if (n.nodeType === 3)
                        s += n.nodeValue;
                    else if (n.nodeType === 4)
                        s += "<![CDATA[" + n.nodeValue + "]]>";
                    return s;
                };
                for (var c=node.firstChild; c; c=c.nextSibling)
                    s += asXml(c);
            }
            return s;
        },
        escape: function(txt) {
            return txt.replace(/[\\]/g, "\\\\")
                .replace(/[\"]/g, '\\"')
                .replace(/[\n]/g, '\\n')
                .replace(/[\r]/g, '\\r');
        },
        removeWhite: function(e) {
            e.normalize();
            for (var n = e.firstChild; n; ) {
                if (n.nodeType === 3) {  // text node
                    if (!n.nodeValue.match(/[^ \f\n\r\t\v]/)) { // pure whitespace text node
                        var nxt = n.nextSibling;
                        e.removeChild(n);
                        n = nxt;
                    }
                    else
                        n = n.nextSibling;
                }
                else if (n.nodeType === 1) {  // element node
                    X.removeWhite(n);
                    n = n.nextSibling;
                }
                else                      // any other node
                    n = n.nextSibling;
            }
            return e;
        }
    };
    if (xml.nodeType === 9) // document node
        xml = xml.documentElement;
    var json = X.toJson(X.toObj(X.removeWhite(xml)), xml.nodeName, "\t");
    return "{\n" + tab + (tab ? json.replace(/\t/g, tab) : json.replace(/\t|\n/g, "")) + "\n}";
}

//去除对象里面的空值
function deleteObjKey(obj){
    for(var key in obj){
        if(!obj[key]){
            delete(obj[key]);
        }
    }
}

function timekeeper(timer,callback,progressCallback){
    var startTime=Date.now();
    var duration=2*60*1000;
    timer.interval=setInterval(function(){
        var lastTime=Date.now();
        if(lastTime-startTime>=duration){
            clearInterTimer(timer.interval);
            clearOutTimer(timer.timeout);
            if(callback&&typeof callback==='function'){
                callback();
            }
            return;
        }
    },1000);
    if(progressCallback&&typeof progressCallback==='function'){
        progressCallback();
    }
}

function getProgress(url,ajaxObj,id,timer,sucCall,errorCall,callback){
    ajaxObj=getAjax(url,function(data){
        if(data.code===0){
            if(callback&&typeof callback==='function'){
                callback();
            }
            var record=data.rows;
            var pro=record.progress;
            if(pro===100){
                clearInterTimer(timer.interval);
                clearOutTimer(timer.timeout);
                if(sucCall&&typeof sucCall==='function'){
                    sucCall();
                }
            }else if(pro===-1){
                clearInterTimer(timer.interval);
                clearOutTimer(timer.timeout);
                if(errorCall&&typeof errorCall==='function'){
                    errorCall();
                }
            }else{
                clearOutTimer(timer.timeout);
                timer.timeout=setTimeout(function(){
                    getProgress(url,ajaxObj,id,timer,sucCall,errorCall,callback);
                },1000);
            }
            var tableTd='';
            if(record===''){
                tableTd += '<tr><td colspan="2">No matching records found</td></tr>';
            }else{
                var progressMessage=record.message;
                if(!progressMessage){
                    progressMessage='';
                }
                tableTd += '<tr><td>' + id + '</td><td><div class="progress progress-striped"><div class="progress-bar progress-bar-success" style="width: ' + pro + '%"><span>' + pro + '%</span></div></div></td></tr>'+
                    '<tr><td colspan="2"><textarea class="deployInfo"  style="background:#fff;">'+progressMessage+'</textarea></td></tr>';
            }
            $(".totaltable tbody").html(tableTd);
            $(".deployInfo").scrollTop($(".deployInfo").get(0).scrollHeight);
        }else{
            clearInterTimer(timer.interval);
            clearOutTimer(timer.timeout);
            swal("Error~", data.message+" !", "error");
        }
    },function(res){
        clearInterTimer(timer.interval);
        clearOutTimer(timer.timeout);
        swal("Error~", res.message+" !", "error");
    })
}

function simpleId(id){
    if(id){
        var newId=id.length>6?'*'+id.substr(-6,6):id;
        var idStr='<a href="javascript:;" class="sample_id js-copy" data_id="'+id+'" data-toggle="tooltip" data-placement="right" data-clipboard-text="'+id+'" title="'+id+'">' +
            newId+
            // '<button class="btn btn-primary btn-sm">copy</button>'+
            '</a>';
        return idStr;
    }else{
        return '<div class="row_detail_td">-</div>'
    }
}

function rowDetail(data){
    var dataStr='';
    for(var key in data){
        if(data[key]){
            dataStr+='<div><label>'+key+':</label><span>'+data[key]+'</span></div>'
        }
    }
    var contentDiv=$('<div class="row_detail"></div>');
    contentDiv.html(dataStr);
    return contentDiv;
}


function showPopover(event,title,pos){
    event.preventDefault();
    var logMessage = $(this).html();
    $('.popover').remove();
    $(this).popover({
        html: true,
        title: title,
        placement:pos,
        content: function() {
            return '<div class="log_popover">'+logMessage+'</div>';
        }
    }).on('shown.bs.popover', function(event) {
        var that = this;

        $(this).parent().find('div.popover').on('mouseenter', function() {
            $(that).attr('in', true);
        }).on('mouseleave', function() {
            $(that).removeAttr('in');
            $(that).popover('hide');

        });
    }).on('hide.bs.popover', function(event) {
        if($(this).attr('in')) {
            event.preventDefault();
        }
    }).popover('show');
}

function hidePopover(event){
    event.preventDefault();
    $('div.popover').removeAttr('in');
    $('div.popover').popover('hide');
}

function initMeuStatus(value){
    var statusStr=null;
    switch (true){
        case value===0:statusStr='UNINITIALIZE';
            break;
        case value===1:statusStr='INITIALIZING';
            break;
        case value===2:statusStr='INITIALIZE_ERROR';
            break;
        case value===3:statusStr='DEFINE_OK';
            break;
        case value===4:statusStr='SIGNATURE_ERROR';
            break;
        case value===5:statusStr='REGISTERING';
            break;
        case value===6:statusStr='REGISTRATION_ERROR';
            break;
        case value===7:statusStr='DI_PENDING';
            break;
        case value===8:statusStr='DI_ERROR';
            break;
        case value===9:statusStr='LOADING';
            break;
        case value===10:statusStr='LOAD_ERROR';
            break;
        case value===11:statusStr='LOADED';
            break;
        case value===12:statusStr='LICENSE_EXPIRED';
            break;
        case value===13:statusStr='NORMAL';
            break;
        case value===14:statusStr='ABNORMAL';
            break;
        case value===15:statusStr='UPDATING';
            break;
        case value===16:statusStr='REMOVING';
            break;
        default:statusStr=null;
        break;
    }
    return statusStr;
}

$(function(){
    $('[data-toggle="tooltip"]').tooltip();
    var clipboard=new Clipboard('.js-copy');
    clipboard.on('success',function(e){
        // console.log('success',e);
    });
    clipboard.on('error',function(e){
        // console.log('error',e);
    })
});


