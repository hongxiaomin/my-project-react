var JSESSIONID='JSESSIONID';
function jumpToHome(){
  var sessionId=getCookie(JSESSIONID);
  var oldSessionId=getStorage(JSESSIONID);
  if(sessionId&&sessionId===oldSessionId){
      window.location.href="/main/html/home.html";
  }

}

jumpToHome();

var rememberName=getStorage('rememberName');
if(rememberName){
    $('.user').val(rememberName);
    $('#remeberName').prop('checked',true);
}

$('.logining').click(function(){
    var username = $('.user').val();
    var password = $('.password').val();
    var url='user/login';
    var loginParam = {username:username,password:password};
    loginParam=JSON.stringify(loginParam);
    if(username&&password){
        if($('#remeberName').prop('checked')){
            putStorage('rememberName',username);
        }else{
            removeStorage('rememberName');
        }
        postAjax(url,loginParam,function(data){
            if(data.code===0){
                var sessionId=getCookie(JSESSIONID);
                putStorage(JSESSIONID,sessionId);
                putStorage('href','../../Container/html/Container.html');
                putStorage('menu','menuContainer');
                putStorage('username',username);

                window.location.href="/main/html/home.html";
            }else{
                $('.message').html(data.message).show();
            }
        },function(res){
            $('.message').html('User not existed Or The user name and password do not match').show();
        })
    }
});

$(document).keyup(function (e){
    if(e.keyCode===13){
        $('.logining').trigger('click');
    }
});