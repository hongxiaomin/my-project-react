var config = getConfig();
var serverIp=config.serverIp;
var serverUrl=config.serverUrl;
function errorMsg(){
    window.location=serverUrl+'/login.html';
}
function errorFunc(res,errCall){
    const data = JSON.parse(res.responseText);
    if(res.status===401){
        if(data.code===4003||data.code===4001){
            errorMsg();
        }else{
            errCall(data);
        }
    }else if(res.status===403){
        if(data.code===-1){
            errCall(data);
        }
    }else{
        errCall(data);
    }
}
function getAjax(url,sucCall,errCall){
    var ajaxObj = null;
    ajaxObj=$.ajax({
        type:'get',
        url:serverIp+url,
        async:true,
        dataType:'json',
        success:function(data){
            sucCall(data);
        },
        error:function(res){
            errorFunc(res,errCall);
        }
    });
    return ajaxObj;
}

function postAjax(url,info,sucCall,errCall){
    var ajaxObj=null;
    ajaxObj=$.ajax({
        type:'post',
        url:serverIp+url,
        data:info,
        contentType:'raw',
        dataType:'json',
        async:true,
        success:function(data){
            sucCall(data);
        },
        error:function(res){
            errorFunc(res,errCall);
        }
    })
}

function postTextAjax(url,sucCall,errCall){
    var ajaxObj = null;
    ajaxObj=$.ajax({
        type:"post",
        url:serverIp+url,
        async:true,
        dataType:'json',
        success:function(data){
            sucCall(data);
        },
        error:function(res){
            errorFunc(res,errCall);
        }
    });
    return ajaxObj;
}

function putAjax(url,info,sucCall,errCall){
    var ajaxObj = null;
    ajaxObj=$.ajax({
        type:"put",
        url:serverIp+url,
        data:info,
        contentType:'raw',
        dataType:'json',
        async:true,
        success:function(data){
            sucCall(data);
        },
        error:function(res){
            errorFunc(res,errCall);
        }
    });
    return ajaxObj;
}


function deleteAjax(url,sucCall,errCall){
    var ajaxObj=null;
    ajaxObj=$.ajax({
        type:'delete',
        url:serverIp+url,
        async:true,
        dataType:'json',
        success:function(data){
            sucCall(data);
        },
        error:function(res){
            errorFunc(res,errCall);
        }
    })
}
