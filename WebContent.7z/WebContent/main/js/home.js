var config = getConfig();
serverUrl=config.serverUrl;
if(checkNotLogin()){
    window.location.href=window.serverUrl+'/login.html';
}

//动态计算屏幕当前高度
window.onload=function(){
    function initPage(){
        var view_height=$(window).height()-62;
        var _html=document.getElementsByClassName('contentWrap')[0];
        _html.style.height=view_height+'px';
    }
    initPage();
    window.onresize=function(){
        initPage();
    }
};

$(function(){
    var flag=true;
    $('.children').hide();

    (function(){
        var username=getStorage('username');
        var href = getStorage('href');
        var menu=getStorage('menu');
        $('#user').text(username);
        if(!href){ 
            href='../../Container/html/Container.html';
            menu='menuContainer';
            putStorage('href',href);
            putStorage("menu",menu);
        }

        $('#rightPanel').load(href);
        menuActive('.'+menu);
    })();

    $('.currentUserInfo').hover(function(){
        $('.userInfo').show();
    },function(){
        $('.userInfo').hide();
    });


    $('.second-nav').click(function(){
        $(this).addClass('Active-nav').siblings().removeClass('Active-nav');
    });

    $('.leftPanel').on('click','.Active-nav',function(){
        var className=$(this).find('.pull-right').attr('class');
        if(className==="pull-right glyphicon glyphicon-plus"){
            $(this).next().slideDown(500);
            $(this).find('.pull-right').attr('class','pull-right glyphicon glyphicon-minus');
        }else{
            $(this).next().slideUp(500);
            $(this).find('.pull-right').attr('class','pull-right glyphicon glyphicon-plus');

        }
    });


    $(document).on('click','.show-label',function(){
        var title = $(this).children('label').text();
        if(title === "hide-option"){
            $(this).parents('.show-option').siblings('.selecter').slideUp("slow");
            $(this).children('label').text("show-option");
            $(this).children('span').attr('class','glyphicon glyphicon-chevron-down');
        }else if(title === "show-option"){
            $(this).parents('.show-option').siblings('.selecter').slideDown("slow");
            $(this).children('label').text("hide-option");
            $(this).children('span').attr('class','glyphicon glyphicon-chevron-up');
        }
    });

    $('#navParent li').click(function(){
        var self=this;
        if(flag){
            showContent.call(self);
        }
    });

    $('#loginout').click(function(){
        var url="user/logout";
        postTextAjax(url,function(data){
            if(data.code===0){
                removeStorage('JSESSIONID');
                window.location.href=window.serverUrl+'/login.html';
            }else{
                swal("Error~", data.message + " !", "error");
            }
        },function(res){
            swal("Error~", res.message + " !", "error");
        })
    })

});

function setMenuAndHref(href,menu){
    putStorage('href',href);
    putStorage("menu",menu);
}
function showRight(id){
    switch(id){
        case 'container':
            setMenuAndHref('../../Container/html/Container.html','menuContainer');
            break;
        case 'EpgLists':
            setMenuAndHref('../../Epg/html/Epg.html','menuEPG');
            break;
        case 'EpgRecord':
            setMenuAndHref('../../Epg/html/ExecutionRecord.html','menuER');
            break;
        case 'meu':
            setMenuAndHref('../../MEU/html/MEU.html','menuMEU');
            break;
        case 'event':
            setMenuAndHref('../../Event/html/Event.html','menuEvent');
            break;
        case 'logList':
            setMenuAndHref('../../Log/html/list.html','menuLogList');
            break;
        case 'logSetting':
            setMenuAndHref('../../Log/html/setting.html','menuLogSetting');
            break;
        //    Tailor platform’s functionalities on UI and deliver more light-weight product and services.  71097 start
        // case 'user':
        //     setMenuAndHref('../../A&A/html/user.html','menuUser');
        //     break;
        case 'nodes':
            setMenuAndHref('../../Remote/html/nodes.html','menuNodes');
            break;
        case 'deploy':
            setMenuAndHref('../../Remote/html/Deploy.html','menuDeploy');
            break;
        case "apps":
            setMenuAndHref('../../Remote/html/lists.html','menuList');
            break;
        //    Tailor platform’s functionalities on UI and deliver more light-weight product and services.  71097 start
        // case 'permission':
        //     setMenuAndHref('../../A&A/html/authorization.html','menuPermisssion');
        //     break;

    }
    $('#rightPanel').load(getStorage('href'));
}


function showContent(){
    if($(this).hasClass('menuContainer')){
        showRight('container');
    }else if($(this).hasClass('menuEPG')){
        showRight('EpgLists');
    }else if($(this).hasClass('menuER')){
        showRight('EpgRecord');
    }else if($(this).hasClass('menuMEU')){
        showRight('meu');
    }else if($(this).hasClass('menuEvent')){
        showRight('event');
    }else if($(this).hasClass('menuLogList')){
        showRight('logList');
    }else if($(this).hasClass('menuLogSetting')){
        showRight('logSetting');
    }
    //    Tailor platform’s functionalities on UI and deliver more light-weight product and services.  71097 start
    // else if($(this).hasClass('menuUser')){
    //     showRight('user');
    // }
    else if($(this).hasClass('menuNodes')){
        showRight('nodes');
    }else if($(this).hasClass('menuList')){
        showRight('apps');
    }else if($(this).hasClass('menuDeploy')){
        showRight('deploy');
    }
    //    Tailor platform’s functionalities on UI and deliver more light-weight product and services.  71097 start
    // else if($(this).hasClass('menuPermisssion')){
    //     showRight('permission');
    // }

    if($(this).hasClass('nav-parent')){
        $(this).addClass('homeActive').siblings().removeClass('homeActive');
        $(this).siblings('ul').children().removeClass('homeActive');
        $(this).next('ul').children().eq(0).addClass('homeActive');
    }else{
        $(this).addClass('homeActive').siblings().removeClass('homeActive').parent().prev().addClass('homeActive');
        $(this).parent().siblings('ul').children().removeClass('homeActive');
        $(this).parent().prev().siblings().removeClass('homeActive');
        $(this).parent().prev().addClass('homeActive');
    }

}
