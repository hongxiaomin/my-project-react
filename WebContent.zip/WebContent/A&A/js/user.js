var config=getConfig();
var serverIp=config.serverIp;
var userListConfig={
    testExistAjax:null,
    saveUserAjax:null,
    updateUserAjax:null
};
$(function(){
    var userConfig=getUserConfig();
    var userTable = TableInit();
    userTable(userConfig.columns,userConfig.url,userConfig.qp);

    $("#btn_query").click(function() {
        $("#tb_table").bootstrapTable('refresh', {
            url: userConfig.url
        });
    });

    $('#btn_add').click(function(){
        getUserRoles();
        $('#creatUser input').val('');
        $('#creatUser p').addClass('hide');
    });

    (function(){
        var saveFlag={
            flag:false
        };
        $('#saveUser').click(function(){
            if(saveFlag.flag){
                return;
            }
            var name=$('#creatUser input[name=username]').val().trim();
            var password=$('#creatUser input[name=userpassword]').val();
            var reviewPassword=$('#creatUser input[name=reviewpassword]').val();
            var role=$('#creatUser input[name=userrole]').val();
            if(!name){
                $('#creatUser .name-info').removeClass('hide');
            }
            if(!password){
                $('#creatUser .password-info').removeClass('hide');
            }
            if(!reviewPassword||reviewPassword!==password){
                $('#creatUser .review-password').removeClass('hide');
            }
            if(!role){
                $('#creatUser .roleInfo').removeClass('hide');
            }
            if(!name||!password||!reviewPassword||reviewPassword!==password||!role){
                return false;
            }
            testUserExist(name,password,role,createUser,saveFlag);
        })
    })();

    $('#cancelCreate').on('click',function(){
        if(userListConfig.testExistAjax){
            userListConfig.testExistAjax.abort();
            if(userListConfig.saveUserAjax){
                userListConfig.saveUserAjax.abort();
            }
        }
    });

    $('#btn_delete').click(function(){
        var currentData=$('#tb_table').bootstrapTable('getSelections')[0];
        if(!currentData){
            $(this).css("z-index",0);
            swal("Wait !", "Please select a row to delete !", "info");
            return;
        }
        var userId=currentData.id;
        deleteUser(userId);
    });

    $('#btn_update').click(function(){
        $('#updateUser input').val('');
        $('#updateUser p').addClass('hide');
        var currentData=$('#tb_table').bootstrapTable('getSelections')[0];
        if(!currentData){
            $(this).removeAttr('data-target');
            swal("Wait !", "Please select a row to delete !", "info");
            return;
        }
        $(this).attr('data-target','#updateUser');
        $('#updateUser input[name=username]').val(currentData['name']).attr('dataId',currentData['id']);
        $('#updateUser input[name=userrole]').val(currentData['role']);
    });

    (function(){

        var updateFlag={
            flag:false
        };
        $('#saveUpdateUser').click(function () {
            if(updateFlag.flag){
                return;
            }
            var oldPassword=$('#updateUser input[name=oldpassword]').val();
            var updatePassword=$('#updateUser input[name=userpassword]').val();
            var updateReviewPassword=$('#updateUser input[name=reviewpassword]').val();
            var role=$('#updateUser input[name=userrole]').val();
            if(!oldPassword){
                $('#updateUser .oldpassword').removeClass('hide');
            }
            if(!updatePassword){
                $('#updateUser .password-info').removeClass('hide');
            }
            if(!updateReviewPassword||updateReviewPassword!==updatePassword){
                $('#updateUser .review-password').removeClass('hide');
            }
        if(!role){
                $('#updateUser .roleInfo').removeClass('hide');
            }
            if(!oldPassword||!updatePassword||!updateReviewPassword||updateReviewPassword!==updatePassword||!role){
                return false;
            }
            var name=$('#updateUser input[name=username]').val();
            var userId=$('#updateUser input[name=username]').attr('dataId');
            var updateData={
                "userId":userId,
                "oldPassword":oldPassword,
                "newPassword":updatePassword,
                "role":role
            };
            updateData=JSON.stringify(updateData);
            updateFlag.flag=true;
            updateUser(updateData,updateFlag);
        })
    })();

    $('#cancelUpdate').click(function(){
        if(userListConfig.updateUserAjax){
            userListConfig.updateUserAjax.abort();
        }
    });

    $('.close span').click(function(){
        if(userListConfig.updateUserAjax){
            userListConfig.updateUserAjax.abort();
        }
        if(userListConfig.testExistAjax){
            userListConfig.testExistAjax.abort();
            if(userListConfig.saveUserAjax){
                userListConfig.saveUserAjax.abort();
            }
        }
    });

    $('#creatUser input[name=username]').on('keyup',function(){
        var reg=/^[\w_]+$/;
        var name=$(this).val().trim();
        if(name){
            if(reg.test(name)){
                $('#creatUser .name-info').addClass('hide');
            }else{
                $('#creatUser .name-info').html('app name is made up of numbers or letters or _ !').removeClass('hide');
            }
        }
    });

    $('#creatUser input[name=username]').on('blur',function(){
        var name=$(this).val().trim();
        if(!name){
            $('#creatUser .name-info').html('Please enter a valid Username').removeClass('hide');
        }
    });
    $('#creatUser input[name=userpassword]').on('blur',function(){
        if($(this).val()){
            $('#creatUser .password-info').addClass('hide');
        }else{
            $('#creatUser .password-info').removeClass('hide');
        }
    });

    $('#creatUser input[name=reviewpassword]').on('blur',function(){
        if($(this).val()===$('#creatUser input[name=userpassword]').val()){
            $('#creatUser .review-password').addClass('hide');
        }else{
            $('#creatUser .review-password').removeClass('hide');
        }
    });

    $('#updateUser input[name=userpassword]').on('blur',function(){
        if($(this).val()){
            $('#updateUser .password-info').addClass('hide');
        }else{
            $('#updateUser .password-info').removeClass('hide');
        }
    });

    $('#updateUser input[name=oldpassword]').on('blur',function(){
        if($(this).val()){
            $('#updateUser .oldpassword').addClass('hide');
        }else{
            $('#updateUser .oldpassword').removeClass('hide');
        }
    });

    $('#updateUser input[name=reviewpassword]').on('blur',function(){
        if($(this).val()===$('#updateUser input[name=userpassword]').val()){
            $('#updateUser .review-password').addClass('hide');
        }else{
            $('#updateUser .review-password').removeClass('hide');
        }
    });

    $('.input-box').on('click',function(){
        $(this).children('.input-list').slideToggle(300);
        $(this).children('span').toggleClass('glyphicon-triangle-top');
    });

    $(document).on('click','.role-list li',function(){
        var text=$(this).html();
        $(this).parent().siblings('input').val(text);
        $(this).parents('.input-box').siblings('p').addClass('hide');
    });

    $('.nav-parent').on('click',function(){
        if(userListConfig.updateUserAjax){
            userListConfig.updateUserAjax.abort();
        }
        if(userListConfig.testExistAjax){
            userListConfig.testExistAjax.abort();
            if(userListConfig.saveUserAjax){
                userListConfig.saveUserAjax.abort();
            }
        }
    });

    $('.children li').on('click',function(){
        if(userListConfig.updateUserAjax){
            userListConfig.updateUserAjax.abort();
        }
        if(userListConfig.testExistAjax){
            userListConfig.testExistAjax.abort();
            if(userListConfig.saveUserAjax){
                userListConfig.saveUserAjax.abort();
            }
        }
    });






});

function getUserConfig(){
    var columns = [{
        radio: true
    },{
        field: 'id',
        title: 'ID',
        visible:false
    },{
        field: 'name',
        title: 'Name'
    },{
        field: 'role',
        title: 'Role'
    }];
    var url = serverIp + 'users';
    var queryParams=function(params) {
        var offset=params.offset;
        var numbers=(offset/params.limit)+1;
        var temp = {
            pageSize: params.limit,
            pageNumber: numbers,
            userName:$('#txt_search_username').val().trim(),
            role:$('#txt_search_role').val().trim()
        };
        deleteObjKey(temp);
        return temp;
    };
    return {
        columns:columns,
        url:url,
        qp:queryParams
    }
}
//get user role
function getUserRoles(){
    var url='roles';
    getAjax(url,function(data){
        var roles=data.rows;
        $('.role-list').empty();
        var liStr='';
        if(roles.length>0){
            $('.userIcon').show();
            roles.forEach(function(role){
                liStr+='<li>'+role+'</li>';
            });
            $('.role-list').html(liStr);
        }else{
            $('.userIcon').hide();
        }

    },function(res){
        console.log(res);
    })
}

function testUserExist(name,password,role,callback,flag){
    var url='user/isexisting?username='+name;
    userListConfig.testExistAjax=getAjax(url,function(data){
        userListConfig.testExistAjax=null;
        if(data.code===0){
            if(data.rows.result==='true'){
                $('.name-info').html(data.message).removeClass('hide');
                flag=false;
                return;
            }else{
                if(callback&&typeof callback==='function'){
                    var userData=JSON.stringify({
                        "username":name,
                        "password":password,
                        "role":role
                    });
                    callback(userData,flag);
                }

            }
        }else{
            swal("Error~", data.rows.result + " !", "error");
            flag=false;
        }

    },function(res){
        userListConfig.testExistAjax=null;
        console.log(res);
        swal("Error~", res.message + " !", "error");
        flag=false;
    })
}

function createUser(userData,saveFlag){
    var url='user';
    userListConfig.saveUserAjax=postAjax(url,userData,function(data){
        userListConfig.saveUserAjax=null;
        saveFlag.flag=false;
        if(data.code===0){
            $('#creatUser').modal('hide');
            swal("Good~", data.message + " !", "success");
            $('#tb_table').bootstrapTable('refresh');
        }else{
            swal("Error~", data.message + " !", "error");
        }
    },function(res){
        userListConfig.saveUserAjax=null;
        saveFlag.flag=false;
        console.log(res);
        swal("Error~", res.message + " !", "error");
    })
}

function deleteUser(userId){
    var url='user?userId='+userId;
    deleteAjax(url,function(data){
        if(data.code===0){
            swal("Good~", data.message + " !", "success");
            $('#tb_table').bootstrapTable('refresh');
        }else{
            swal("Error~", data.message + " !", "error");
        }
    },function(res){
        console.log(res);
        swal("Error~", res.message + " !", "error");
    })
}

function updateUser(updateData,updateFlag){
    var url='user';
    userListConfig.updateUserAjax=putAjax(url,updateData,function(data){
        updateFlag.flag=false;
        userListConfig.updateUserAjax=null;
        if(data.code===0){
            $('#updateUser').modal('hide');
            swal("Good~", data.message + " !", "success");
            $('#tb_table').bootstrapTable('refresh');
        }else{
            swal("Error~", data.message + " !", "error");
        }
    },function(res){
        updateFlag.flag=false;
        userListConfig.updateUserAjax=null;
        console.log(res);
        swal("Error~", res.message + " !", "error");
    })
}