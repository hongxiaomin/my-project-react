var config = getConfig();
var serverIP=config.serverIp;
var currentContainerId='';

$(function(){
    var containerConfig=getContainerTableConfig();
    var meuContainerConfig=getMeuContainerConfig();
    var eventContainerConfig=getEventContainerConfig();
    var executionContainerConfig=getExceptionContainerConfig();
    var containerTable=TableInit('#container_tb_table');
    containerTable(containerConfig.columns,containerConfig.url,containerConfig.qp,'id');//container表格初始化

    $('#btn_query_container').click(function(){
        $("#container_tb_table").bootstrapTable('refresh', {url: containerConfig.url});
    });

    $('#container_tb_table').off('click','tbody tr').on('click','tbody tr',function(){
        var currentData=$('#container_tb_table').bootstrapTable('getSelections')[0];
        $('.container_status').text(getStatus(currentData["status"]));
        $('.container_id').text(currentData["id"]);
        $('.container_name').text(currentData["name"]);
        $('.container_node').text(currentData["node"]);
        currentContainerId=currentData["id"];
        if(!meuContainerConfig.init){
            meuContainerConfig.init=true;
            var meuTable=TableInit('#meuTable');
            meuTable(meuContainerConfig.columns,meuContainerConfig.url,meuContainerConfig.qp,'id');
        }
        $('#container_list').addClass('hide');
        $('#detail').removeClass('hide');

    });

    $('#myTabs a[href="#event"]').on('shown.bs.tab',function(e){
        if(!eventContainerConfig.init){
            eventContainerConfig.init=true;
            var eventTable = TableInit('#eventTable');
            eventTable(eventContainerConfig.columns,eventContainerConfig.url,eventContainerConfig.qp,'date','desc');
        }
    });

    $('#myTabs a[href="#exception"]').on('shown.bs.tab',function(e){
        if(!executionContainerConfig.init){
            executionContainerConfig.init=true;
            var exceptionTable = TableInit('#exceptionTable');
            exceptionTable(executionContainerConfig.columns,executionContainerConfig.url,executionContainerConfig.qp,'occurredTime','desc');
        }
    });

    $('.container_list').on('click',function(){
        $('#meuTable').bootstrapTable('destroy');
        $('#eventTable').bootstrapTable('destroy');
        $('#exceptionTable').bootstrapTable('destroy');
        meuContainerConfig.init=false;
        eventContainerConfig.init=false;
        executionContainerConfig.init=false;
        $('#container_list').removeClass('hide');
        $('#detail').addClass('hide');
    });

    $('#eventTable').off('mouseenter','tbody tr .executionDetail').on('mouseenter','tbody tr .executionDetail',function(ev){
        var index=Number($(this).parents('tr').attr('data-index'));
        var tableData=$('#eventTable').bootstrapTable('getData');
        var currentData=tableData[index];
        if(!currentData.containerId||!currentData.executionId||!currentData.serilNo){
            return false;
        }
        var self=this;
        var eventDetailUrl='container/detail/eventList/invokeDetail?containerId='+currentData.containerId+'&executionId='+currentData.executionId+'&instanceId='+currentData.serilNo;
        getAjax(eventDetailUrl,function(res){
            $('.EventContent').empty();
            var data = res.rows;
           var keys = Object.keys(data);
           if(keys.length>0){
               $('.popover').remove();
               $(self).popover({
                   html: true,
                   title: 'Execution Detail',
                   placement:'bottom',
                   delay:{
                       show:200,
                       hide:800
                   },
                   content:function(){
                       return setEventPopver(data);
                   }
               }).on('shown.bs.popover', function(event) {
                   $(self).parent().find('div.popover').on('mouseenter', function() {
                       $(self).attr('in', true);
                   }).on('mouseleave', function(event) {
                       event.preventDefault();
                       $(self).removeAttr('in');
                       $(self).popover('hide');

                   });
               }).on('hide.bs.popover', function(event) {
                   if($(self).attr('in')) {
                       event.preventDefault();
                   }
               }).popover('show');
           }
        },function(res){
            console.log(res);
        })
    });

    $('#eventTable').off("mouseleave",'tbody tr').on("mouseleave",'tbody tr',function(){
        $('div.popover').removeAttr('in');
        $('div.popover').popover('hide');
    });

    $('#exceptionTable').off('mouseenter','tbody tr .msg').on('mouseenter', 'tbody tr .msg', function(ev) {
        var currentData=$('#exceptionTable').bootstrapTable('getSelections')[0];
        $('.popover').remove();
        $(this).popover({
            html: true,
            title: 'Exception Msg',
            placement:'left',
            delay:{
                show:200,
                hide:500
            },
            content:function(){
                return '<div class="EventContent"><div><label>Msg :</label><span>'+currentData.msg+'<span></div></div>';
            }
        }).on('shown.bs.popover', function(event) {
            var that = this;
            $(this).parent().find('div.popover').on('mouseenter', function() {
                $(that).attr('in', true);
            }).on('mouseleave', function(event) {
                event.preventDefault();
                $(that).removeAttr('in');
                $(that).popover('hide');

            });
        }).on('hide.bs.popover', function(event) {
            if($(this).attr('in')) {
                event.preventDefault();
            }
        }).popover('show');
    });
});
$('#exceptionTable').off("mouseleave",'tbody tr .msg').on("mouseleave",'tbody tr .msg',function(){
    $('div.popover').removeAttr('in');
    $('div.popover').popover('hide');
});

$('#txt_search_status').multiselect({
    buttonWidth:'100%',
    maxHeight:200,
    includeSelectAllOption:false,
    enableFiltering:false,
    selectedClass: 'active-select',
    dropRight: true
});

function getContainerTableConfig(){
    var columns =[{
        radio: true
    },{
        field: 'id',
        title: 'ID',
        sortable:true,
        formatter:function(value,row,index){
            return simpleId(value);
    }
    },{
        field: 'name',
        title: 'Name',
        sortable:true,
        formatter:function(value,row,index){
            var name=value;
            if(row.webUrl){
                name=value+'('+row.webUrl+')';
            }
            return name;
        }
    },{
        field: 'status',
        title: 'Status',
        formatter:function(value,row,index){
            var temp=getStatus(value);
            return temp;
        },
        sortable:true
    },{
        field: 'node',
        title: 'Node',
        sortable:true
    }];
    var containerListUrl=serverIP+'container';
    var containerQueryParams=function(params){
        var num=(params.offset/params.limit)+1;
        var temp={
            pageSize:params.limit,
            pageNumber:num,
            containerId: $(".id").val().trim(),
            name: $(".name").val().trim(),
            status:Number($('#txt_search_status').val()),
            node:$('.node').val().trim(),
            sortName:params.sort,
            sortOrder:params.order
        };
        for(var key in temp){
            if(key==='status'){
                if(temp[key]===-2){
                    delete(temp[key]);
                }
            }else{
                if(!temp[key]){
                    delete(temp[key]);
                }
            }
        }
        return temp;
    };
    return {
        columns:columns,
        url:containerListUrl,
        qp:containerQueryParams
    }
}

function getMeuContainerConfig(){
    var columnsMeu=[
        {
            radio: true
        },{
            field: 'id',
            title: 'ID',
            sortable:true,
            formatter:function(value,row,index){
                return simpleId(value);
            }
        },{
            field: 'name',
            title: 'Name',
            sortable:true
        },{
            field: 'type',
            title: 'Type',
            sortable:true
        },{
            field: 'status',
            title: 'Status',
            formatter:function(value,row,index){
                return initMeuStatus(value);
            }
        },{
            field: 'language',
            title: 'Language',
            sortable:true
        }];
    var meuUrl=serverIP+'container/detail/meuList';
    var meuInit=false;
    var meuQueryParams = function (params) {
        var num=(params.offset/params.limit)+1;
        var temp = {
            pageSize: params.limit,
            pageNumber: num,containerId:currentContainerId,
            sortName:params.sort,
            sortOrder:params.order
        };
        deleteObjKey(temp);
        return temp;
    };
    return {
        columns:columnsMeu,
        url:meuUrl,
        init:meuInit,
        qp:meuQueryParams
    }
}


function getEventContainerConfig(){
    var columnsEvent=[{
            radio: true
        },{
            field: 'date',
            title: 'Time',
            sortable:true,
            formatter:function(value,row,index){
                value=resetValue(value);
                return getExecutionDetail(value);
            }
        },{
            field: 'epgId',
            title: 'EPG ID',
            formatter:function(value,row,index){
                value=resetValue(value);
                return getExecutionDetail(simpleId(value));
            }
        },{
            field: 'executionId',
            title: 'Execution ID',
            formatter:function(value,row,index){
                value=resetValue(value);
                return getExecutionDetail(simpleId(value));
            }
        },
        {
            field: 'destinationTopic',
            title: 'Destination Topic',
            formatter:function(value,row,index){
                value=resetValue(value);
                return getExecutionDetail(value);
            }
        },
        {
            field: 'destinationId',
            title: 'Destination ID',
            formatter:function(value,row,index){
                value=resetValue(value);
                return getExecutionDetail(simpleId(value));
            }
        },
        {
            field: 'operationId',
            title: 'Operation ID',
            formatter:function(value,row,index){
                value=resetValue(value);
                return getExecutionDetail(simpleId(value));
            }
        },{
            field: 'sourceId',
            title: 'Source ID',
            formatter:function(value,row,index){
                value=resetValue(value);
                return getExecutionDetail(simpleId(value));
            }
        }];

    var eventUrl=serverIP+'container/detail/eventList';
    var eventInit=false;
    var eventQueryParams = function (params) {
        var num=(params.offset/params.limit)+1;
        var temp = {
            pageSize: params.limit,
            pageNumber: num,containerId:currentContainerId,
            sortName:params.sort,
            sortOrder:params.order
        };
        deleteObjKey(temp);
        return temp;
    };
    return {
        columns:columnsEvent,
        url:eventUrl,
        init:eventInit,
        qp:eventQueryParams
    }
}

function getExceptionContainerConfig(){
    var columnsException=[{
            radio: true
        },{
            field: 'occurredTime',
            title: 'Occurred Time',
            sortable:true
        },{
            field: 'id',
            title: 'ID',
            sortable:true,
            formatter:function(value,row,index){
                return simpleId(value);
            }
        },{
            field: 'meuId',
            title: 'Meu ID',
            sortable:true,
        formatter:function(value,row,index){
            return simpleId(value);
        }
        },{
            field: 'executeId',
            title: 'Execute ID',
            sortable:true
        },{
            field: 'shortMsg',
            title: 'Short Msg',
            sortable:true,
            formatter:function(value,row,index){
                value=resetValue(value);
                return '<p class="msg">'+value+'</p>'
            }
        }];
    var exceptionListUrl=serverIP+'container/detail/exceptionList';
    var exceptionInit=false;
    var exceptionQueryParams = function (params) {
        var num=(params.offset/params.limit)+1;
        var temp = {
            pageSize: params.limit,
            pageNumber: num,containerId:currentContainerId,
            sortName:params.sort,
            sortOrder:params.order
        };
        deleteObjKey(temp);
        return temp;
    };
    return {
        columns:columnsException,
        url:exceptionListUrl,
        init:exceptionInit,
        qp:exceptionQueryParams
    }
}



function getStatus(value){
    switch(value){
        case 1:return 'REGISTERING';
            break;
        case 2:return 'STARTING';
            break;
        case 3:return 'HA_PENDING';
            break;
        case 4:return 'NORMAL';
            break;
        case -1:return 'ERROR';
            break;
        default:return 'ABNORMAL';
    }
}

function setEventPopver(data){
    return '<div class="EventContent"><div><label>ID:</label><span>' + data.id + '</span></div><div><label>MEU ID:</label><span>' + data.meuId + '</span></div><div><label>Operation ID:</label><span>' + data.operationId + '</span></div><div><label>Execution Time:</label><span>' + data.executionTime + ' (MS)</span></div><div><label>Invoke Time Stamp:</label><span>' + data.invokeTimestamp + '</span></div><div><label>Input:</label><span>' + data.input + '</span></div><div><label>Output:</label><span>' + data.output + '</span></div></div>';
}

function getExecutionDetail(value){
    if(value){
        return '<div class="executionDetail">'+value+'</div>'
    }else{
        return null
    }
}