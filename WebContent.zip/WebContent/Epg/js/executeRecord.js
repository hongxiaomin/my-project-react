var config=getConfig();
var serverIp=config.serverIp;
$(function(){
    var executionConfig = getExecutionConfig();
    var executionTable = TableInit();
    executionTable(executionConfig.columns,executionConfig.url,executionConfig.qp);

    $("#btn_query").click(function() {
        $("#tb_table").bootstrapTable('refresh', {
            url: executionConfig.url
        });
    });

    $('.executionTable').off('click','tbody tr').on('click','tbody tr',function(){
        var currentData=$('.executionTable').bootstrapTable('getSelections')[0];
        var epgId = currentData.epgId,
            executionID = currentData.executionId;
        $('.ng-EpgExeRecordDetail .panel-heading').html("Executed ID：" + executionID);

        var epgListsUrl='epg?epgId='+epgId;
        getAjax(epgListsUrl,function(data){
            var currentEpgData=data.rows[0];
            var epgDefinition=currentEpgData.epgDefinition;
            if(epgDefinition){
                putStorage('epgId',epgId);
                putStorage('executionId',executionID);
                putStorage('epgDefinition',epgDefinition);
                parseMoniteXml(epgId,executionID,epgDefinition);
                $('.ng-EpgExexution').hide();
                $('.ng-EpgExeRecordDetail').show();
            }
        },function(res){
            console.log(res);
        });
    });

    $('.EXECUTION').click(function(){
        $('.ng-EpgExexution').show();
        $('.ng-EpgExeRecordDetail').hide();
    });

    $('.ToEpg').click(function(){
        showRight('EpgLists');
        $('.EpgLists ').addClass('homeActive').siblings('li').removeClass('homeActive');
    })



});

function getExecutionConfig(){
    var columns = [{
        radio: true
    }, {
        field: 'executionId',
        title: 'Executed ID',
        formatter:function(value,row,index){
            return simpleId(value);
        }
    }, {
        field: 'epgId',
        title: 'EPG ID',
        formatter:function(value,row,index){
            return simpleId(value);
        }
    }, {
        field: 'date',
        title: 'Create Date'
    }, {
        field: 'status',
        title: 'Status'
    }];
    var url = serverIp + 'epg/executionrecord';
    var queryParams = function(params) {
        var num=(params.offset/params.limit)+1;
        var temp = {
            pageSize: params.limit,
            pageNumber: num,
            epgId: $('.id').val().trim(),
            status:$('.status').val().trim()
        };
        deleteObjKey(temp);
        return temp;
    };
    return {
        columns:columns,
        url:url,
        qp:queryParams
    }
}