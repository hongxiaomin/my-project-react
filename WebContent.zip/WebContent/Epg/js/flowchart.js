var executionMeus={
    timer:null,
    elasticFlag:true
};

var invoke='meu/invokeByEvent/';
var myDiagram=null;
function getAllMeu(epgId,callbcak){
    var allMeuUrl='meu?epgId='+epgId;
    getAjax(allMeuUrl,function(data){
        if(data.code===0){
            callbcak(data.rows);
        }
    },function(res){
        console.log(res);
    })
}

function resetEpgDefinition(epgDefinition){
    epgDefinition=epgDefinition.replace(/\\?&quot;/g,'');
    var definitionObj=parseXMLObj(epgDefinition);
    var definitionJson=xml2json(definitionObj);
    definitionJson="{"+definitionJson.substring(11);
    definitionJson=eval("("+definitionJson+")");
    var events=definitionJson["epg"]["events"]["event"];
    var meus=definitionJson["epg"]["meus"]["meu"];

    if(isClass(events)==='Array'){
        events=events;
    }else if(isClass(events)==='Object'){
        events=[events];
    }
    if(isClass(meus)==='Array'){
        meus=meus;
    }else if(isClass(meus)==='Object'){
        meus=[meus];
    }
    return {
        events:events,
        meus:meus
    }
}

function makeGraph(graphData,allMeu){
    var events=graphData.events;
    var meus=graphData.meus;
    var nodeList=[];
    var linkList=[];
    var destCondition=0;
    var startNode={
        "key":"start",
        "text":"Start",
        "fig":"ellipse"
    };
    var endNode={
        "key":"end",
        "text":"End",
        "fig":"ellipse"
    };
    nodeList.push(startNode);
    nodeList.push(endNode);

    for(var i=0;i<meus.length;i++){
        var id=meus[i]["@id"];
        var currentMeu=null;
        allMeu.forEach(function(meu,j){
            if(meu.id===id){
                currentMeu=meu;
            }
        });
        if(currentMeu){
            var node={
                "key":id,
                "text":currentMeu["name"],
                "type":currentMeu["type"]
            };
            nodeList.push(node);
            if("reference" in currentMeu){
                var referenceArr=currentMeu["reference"];
                referenceArr.forEach(function(item){
                    if(item["meuId"]){
                        var referenceLink={
                            "from":id,
                            "to":item["meuId"],
                            "dash":[4,6],
                            "width":3
                        };
                        linkList.push(referenceLink);
                    }
                })
            }
        }
    }

    for(var x=0;x<events.length;x++){
        var currentEvent=events[x];
        var linkObj={};
        if(currentEvent["@operationId"]){
            linkObj["operationId"]=currentEvent["@operationId"]
        }
        if(currentEvent["@return"]){
            linkObj["return"]=currentEvent["@return"]
        }
        if(currentEvent["@mode"]){
            linkObj["mode"]=currentEvent["@mode"]
        }
        if(currentEvent["@inputParam"]){
            linkObj["inputParam"]=currentEvent["@inputParam"]
        }
        if(currentEvent["@condition"]){
            linkObj["condition"]=currentEvent["@condition"]
        }

        if(!currentEvent["@source"]||currentEvent["@source"]==="external"||currentEvent["@source"]==="timer"){
            linkObj["from"]="start";
        }else{
            linkObj["from"]=currentEvent["@source"];
        }
        if(!currentEvent["@dest"]&&currentEvent["dest"]){
            var diamond=++destCondition+"diamond";
            nodeList.push({
                "key":diamond,
                "text":"",
                "fig":"diamond",
                "category":"nodeMap1"
            });
            linkObj["to"]=diamond;
            currentEvent["dest"].forEach(function(item){
                var linkDestItem={};
                linkDestItem["from"]=diamond;
                if(item["@operationId"]){
                    linkDestItem["operationId"]=item["@operationId"]
                }
                if(item["@return"]){
                    linkDestItem["return"]=item["@return"]
                }
                if(item["@mode"]){
                    linkDestItem["mode"]=item["@mode"]
                }
                if(item["@inputParam"]){
                    linkDestItem["inputParam"]=item["@inputParam"]
                }
                if(item["@condition"]){
                    linkDestItem["condition"]=item["@condition"]
                }
                if(item["@id"]){
                    linkDestItem["to"]=item["@id"];
                }else{
                    linkDestItem["to"]="end";
                }
                linkList.push(linkDestItem);
            })
        }else if(!currentEvent["@dest"]&&!currentEvent["dest"]){
            linkObj["to"]='end';
        }else{
            linkObj["to"]=currentEvent["@dest"];
        }
        linkList.push(linkObj);
    }
    var diagramModel={};
    diagramModel.nodeDataArray=nodeList;
    diagramModel.linkDataArray=linkList;
    return diagramModel;
}


function getWorkMeus(executionId,callback){
    var workMeuUrl='epg/executionrecord/detail?executionId='+executionId;
    getAjax(workMeuUrl,function(data){
        if(data){
            if(data.code===0){
                callback(data.rows);
            }
        }
    },function(res){
        console.log(res);
    });
}

function getErrorMeus(executionId,callback){
    var errorMeuUrl='exception?executionId='+executionId;
    getAjax(errorMeuUrl,function(data){
        if(data.code===0){
            callback(data.rows);
        }
    },function(res){
        console.log(res);
    });
}

function getMonitDatas(executionId,callbcak,errorCall){
    var monitUrl='event/monitor?executionId='+executionId;
    getAjax(monitUrl,function(data){
        if(data.code===0){
            callbcak(data.rows);
        }else{
            errorCall(data);
        }
    },function(res){
        console.log(res);
        errorCall(res);
    });
}

function addNodeColor(executionId,diagramModel,callback){
    var addColorData={
        workMeu:{
            flag:false,
            data:null
        },
        errorMeu:{
            flag:false,
            data:null
        },
        monitMeu:{
            flag:false,
            data:null
        }
    };

    getWorkMeus(executionId,function(data){
        addColorData.workMeu.flag=true;
        addColorData.workMeu.data=data;
        operaAllMeu(addColorData,diagramModel,callback);
    });
    getErrorMeus(executionId,function(data){
        addColorData.errorMeu.flag=true;
        addColorData.errorMeu.data=data;
        operaAllMeu(addColorData,diagramModel,callback);
    });
    getMonitDatas(executionId,function(data){
        addColorData.monitMeu.flag=true;
        addColorData.monitMeu.data=data;
        executionMeus.elasticFlag=true;
        operaAllMeu(addColorData,diagramModel,callback);
    },function(data){
        swal("Error~", data.message, "error");
        executionMeus.elasticFlag=false;
        initMonit(diagramModel);
        clearOutTimer(executionMeus.timer);
    });
}

function operaAllMeu(addColorData,diagramModel,callback){
    if(addColorData.workMeu.flag&&addColorData.errorMeu.flag&&addColorData.monitMeu.flag){
        var workObj={},errorObj={};
        var workData=addColorData.workMeu.data;
        var errorData=addColorData.errorMeu.data;
        var monitData=addColorData.monitMeu.data;
        if(workData){
            workData.forEach(function(work){
                workObj[work.meuId]=work;
            })
        }
        if(errorData){
            errorData.forEach(function(error){
                errorObj[error.meuId]=error;
            })
        }
        var nodeLists=diagramModel.nodeDataArray;
        var linkLists=diagramModel.linkDataArray;
        nodeLists.forEach(function(item){
            if(item["text"]==="Start"||item["text"]==="End"||item["fig"]==="diamond"){
                if(item["text"]==="Start"||item["text"]==="End"){
                    monitData.forEach(function(monit){
                        if(!monit["sourceId"]&&item["text"]==="Start"){
                            item["color"]="green";
                            return;
                        }
                        if(!monit["destId"]&&item["text"]==="End"){
                            item["color"]="green";
                            return;
                        }
                    })
                }
            }else{
                if(workObj[item["key"]]&&!errorObj[item["key"]]){
                    item["color"]="green";
                    if(item["type"]==="dispatch"){
                        linkLists.forEach(function(link){
                            if(link.from==="start"&&link.to===item["key"]){
                                link["color"]="green";
                                nodeLists.filter(function(node){
                                    if(node["key"]==="start"){
                                        node["color"]="green";
                                    }
                                })
                            }
                        })
                    }
                    var workNode=workObj[item["key"]];
                    var workNodeTip={
                        "Container ID":workNode.containerId,
                        "MEU ID":workNode.meuId,
                        "Execution ID":workNode.executeId,
                        "Execution Time":workNode.executionTime+' ms',
                        "Operation ID":workNode.operationId
                    };
                    var workNodeTipStr=JSON.stringify(workNodeTip);
                    item["tiptext"]=workNodeTipStr;
                    item["category"]="nodeMap2";

                }else if(!workObj[item["key"]]&&errorObj[item["key"]]){
                    item["color"]="red";
                    if(item["type"]==="dispatch"){
                        linkLists.forEach(function(link){
                            if(link.from==="start"&&link.to===item["key"]){
                                link["color"]="green";
                                nodeLists.filter(function(node){
                                    if(node["key"]==="start"){
                                        node["color"]="green";
                                    }
                                })
                            }
                        })
                    }
                    var errorNode=errorObj[item["key"]];
                    var errorNodeTip={
                        "Container ID":errorNode.containerId,
                        "MEU ID":errorNode.meuId,
                        "Execution ID":errorNode.executeId,
                        "Msg":errorNode.shortMsg
                    };
                    var errorNodeTipStr=JSON.stringify(errorNodeTip);
                    item["tiptext"]=errorNodeTipStr;
                    item["category"]="nodeMap3";
                }else if(workObj[item["key"]]&&errorObj[item["key"]]){
                    item["color"]="orange";
                    if(item["type"]==="dispatch"){
                        linkLists.forEach(function(link){
                            if(link.from==="start"&&link.to===item["key"]){
                                link["color"]="green";
                                nodeLists.filter(function(node){
                                    if(node["key"]==="start"){
                                        node["color"]="green";
                                    }
                                })
                            }
                        })
                    }
                    var workNodeR=workObj[item["key"]];
                    var errorNodeR=errorObj[item["key"]];
                    var allNodeTip={
                        "Container ID":workNodeR.containerId,
                        "MEU ID":workNodeR.meuId,
                        "Execution ID":workNodeR.executeId,
                        "Execution Time":workNodeR.executionTime+'ms',
                        "Operation ID":workNodeR.operationId,
                        "Msg":errorNodeR.shortMsg
                    };
                    var allNodeTipStr=JSON.stringify(allNodeTip);
                    item["tiptext"]=allNodeTipStr;
                    item["category"]="nodeMap2";
                }else{
                    monitData.forEach(function(monit){
                        if(monit["sourceId"]===item["key"]){
                            item["color"]="green";
                            if(item["type"]==="dispatch"){
                                linkLists.forEach(function(link){
                                    if(link.from==="start"&&link.to===item["key"]){
                                        link["color"]="green";
                                        nodeLists.filter(function(node){
                                            if(node["key"]==="start"){
                                                node["color"]="green";
                                            }
                                        })
                                    }
                                })
                            }
                            return;
                        }
                    })
                }
            }
        });
        var diamondLinks={};
        linkLists.forEach(function(link){
            if(link["from"].indexOf('diamond')!==-1||link["to"].indexOf('diamond')!==-1){
                if(link["from"].indexOf('diamond')!==-1){
                    if(!diamondLinks[link["from"]]){
                        diamondLinks[link["from"]]={};
                        diamondLinks[link["from"]]["from"]={};
                        diamondLinks[link["from"]]["from"][link["to"]]=link;
                    }else{
                        if(!diamondLinks[link["from"]]["from"]){
                            diamondLinks[link["from"]]["from"]={};
                            diamondLinks[link["from"]]["from"][link["to"]]=link;
                        }else{
                            diamondLinks[link["from"]]["from"][link["to"]]=link;
                        }
                    }
                }else if(link["to"].indexOf('diamond')!==-1){
                    if(diamondLinks[link["to"]]){
                        if(!diamondLinks[link["to"]]["to"]){
                            diamondLinks[link["to"]]["to"]={};
                            diamondLinks[link["to"]]["to"][link["from"]]=link;
                        }else{
                            diamondLinks[link["to"]]["to"][link["from"]]=link;
                        }
                    }else{
                        diamondLinks[link["to"]]={};
                        diamondLinks[link["to"]]["to"]={};
                        diamondLinks[link["to"]]["to"][link["from"]]=link;
                    }
                }
            }
            monitData.forEach(function(monit){
                if((!monit["sourceId"]||monit["sourceId"]==="external"||monit["sourceId"]==="timer")&&link["from"]==='start'&&monit["destId"]===link["to"]){
                    link["color"]="green";
                }else if(!monit["destId"]&&link["to"]==="end"&&monit["sourceId"]===link["from"]){
                    if(!link["condition"]){
                        link["color"]="green";
                    }else{
                        var condition=link["condition"];
                        for(var i=0;i<linkLists.length;i++){
                            if(linkLists[i]["condition"]===condition){
                                for(var j=0;j<linkLists.length;j++){
                                    if(linkLists[j]["to"]===linkLists[i]["from"]){
                                        var source=linkLists[j]["from"];
                                        var dest=linkLists[i]["to"];
                                        for(var k=0;k<monitData.length;k++){
                                            if(monitData[k]["sourceId"]===source&&monitData[k]["destId"]===dest){
                                                link["color"]="green";
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }else if(monit["sourceId"]===link["from"]&&monit["destId"]===link["to"]){
                    if(monit["sourceTopic"]&&monit["sourceTopic"].indexOf(invoke)>-1){
                        var hasSourceInvoke=false;
                        monitData.forEach(function(anotherMonit){
                            if(anotherMonit["destTopic"]===monit["sourceTopic"]&&anotherMonit["sourceId"]===monit["destId"]&&anotherMonit["destId"]===monit["sourceId"]){
                                hasSourceInvoke=true;
                                return;
                            }
                        });
                        if(hasSourceInvoke){
                            link["color"]="green";
                        }else{
                            link["color"]="orange";
                        }
                    }else{
                        link["color"]="green";
                    }
                }else if(monit["sourceId"]===link["to"]&&monit["destId"]===link["from"]){
                    if(monit["destTopic"]&&monit["destTopic"].indexOf(invoke)>-1){
                        var hasDestInvoke=false;
                        monitData.forEach(function(anotherMonit){
                            if(anotherMonit["sourceTopic"]===monit["destTopic"]&&anotherMonit["destId"]===monit["sourceId"]&&anotherMonit["sourceId"]===monit["destId"]){
                                hasDestInvoke=true;
                                return;
                            }
                        });
                        if(hasDestInvoke){
                            link["color"]="green";
                        }else{
                            link["color"]="orange";
                        }
                    }
                }
                if(link["from"]==='start'&&link["to"]===monit['sourceId']){
                    link["color"]="green";
                    nodeLists.filter(function(node){
                        if(node["key"]==="start"){
                            node["color"]='green';
                        }
                    })
                }
            })
        });

        for(var diamond in diamondLinks){
            var fromDiamond=diamondLinks[diamond].from;
            var toDiamond=diamondLinks[diamond].to;
            monitData.forEach(function(monit){
                var equalSource=false;
                var equalDest=false;
                var oppositeEqualSource=false;
                var oppositeEqualDest=false;
                var monitLink={};
                var destTopicMonit={};
                for(var fromKey in fromDiamond){
                    if(fromKey===monit["destId"]||(fromKey==='end'&&!monit["destId"])){
                        equalDest=true;
                        monitLink["destLink"]=fromDiamond[fromKey];
                    }
                    if(fromKey===monit["sourceId"]){
                        oppositeEqualDest=true;
                        destTopicMonit["destLink"]=fromDiamond[fromKey];
                    }
                }
                for(var toKey in toDiamond){
                    if(toKey===monit["sourceId"]){
                        equalSource=true;
                        monitLink["sourceLink"]=toDiamond[toKey];
                    }
                    if(toKey===monit["destId"]){
                        oppositeEqualSource=true;
                        destTopicMonit["sourceLink"]=toDiamond[toKey];
                    }
                }
                if(equalSource&&equalDest){
                    if(monit["sourceTopic"]&&monit["sourceTopic"].indexOf(invoke)>-1){
                        var hasSourceInvoke=false;
                        monitData.forEach(function(anotherMonit){
                            if(anotherMonit["destTopic"]===monit["sourceTopic"]&&anotherMonit["sourceId"]===monit["destId"]&&anotherMonit["destId"]===monit["sourceId"]){
                                hasSourceInvoke=true;
                                return;
                            }
                        });
                        if(hasSourceInvoke){
                            monitLink["destLink"]["color"]="green";
                            monitLink["sourceLink"]["color"]="green";

                        }else{
                            monitLink["destLink"]["color"]="orange";
                            monitLink["sourceLink"]["color"]="orange";
                        }
                    }else{
                        monitLink["destLink"]["color"]="green";
                        monitLink["sourceLink"]["color"]="green";
                    }
                    return;
                }
                if(oppositeEqualSource&&oppositeEqualDest){
                    if(monit["destTopic"]&&monit["destTopic"].indexOf(invoke)>-1){
                        var hasDestInvoke=false;
                        monitData.forEach(function(anotherMonit){
                            if(anotherMonit["sourceTopic"]===monit["destTopic"]&&anotherMonit["destId"]===monit["sourceId"]&&anotherMonit["sourceId"]===monit["destId"]){
                                hasDestInvoke=true;
                                return;
                            }
                        });
                        if(hasDestInvoke){
                            destTopicMonit["destLink"]["color"]="green";
                            destTopicMonit["sourceLink"]["color"]="green";

                        }else{
                            destTopicMonit["destLink"]["color"]="orange";
                            destTopicMonit["sourceLink"]["color"]="orange";
                        }
                    }
                }
            })
        }
        callback(diagramModel);
    }
}

function init(diagramModel,ele){
    if(myDiagram){
        myDiagram.clear();
        myDiagram.div=null;
    }
    ele=ele||"myDiagram";
    var $ = go.GraphObject.make;
    myDiagram=$(go.Diagram,ele,{
        initialAutoScale:go.Diagram.Uniform,
        contentAlignment:go.Spot.Center
    });
    myDiagram.layout=$(go.TreeLayout,{
        angle:0,
        layerSpacing:80
    });
    myDiagram.nodeTemplate=$(go.Node,"Auto",
            $(go.Shape,"RoundedRectangle",{
                fill:$(go.Brush,go.Brush.Linear,{
                    0:"white",
                    1:"#ccc"
                }),
                stroke:"#bbb",
                strokeWidth:2,
                figure:"Rectangle"
            },
            new go.Binding("figure","fig"),
            new go.Binding("location","loc",go.Point.Parse),
            new go.Binding("size", "size"),
            new go.Binding("fill", "color")
            ),
            $(go.TextBlock,{
                font:"bold 14pt helvetica, bold arial, sans-serif",
                margin:20
            },
            new go.Binding("text","text")
            )
        );
        myDiagram.nodeTemplateMap.add("nodeMap1",$(go.Node,"Auto",$(go.Shape,"RoundedRectangle",{
            fill:$(go.Brush,go.Brush.Linear,{
                0:"white",
                1:"#ccc"
            }),
            stroke: "#bbb",
            figure: "diamond"
        },
            new go.Binding("figure", "fig"),
            new go.Binding('location', 'loc', go.Point.Parse),
            new go.Binding("fill", "color")
        ),
        $(go.TextBlock,{
            font: "bold 10pt helvetica, bold arial, sans-serif",
            margin: 8
        },
            new go.Binding("text", "text")
        )
        ));
    myDiagram.linkTemplate=$(go.Link,{
        routing: go.Link.AvoidsNodes,
        corner: 0
    },
        new go.Binding("points").makeTwoWay(),
        $(go.Shape,{
            isPanelMain: true,
            stroke: "#bbb"
        },
            new go.Binding("strokeDashArray", "dash"),
            new go.Binding("strokeWidth", "width")
        ),
        $(go.Shape,{
            toArrow: "standard",
            stroke: "#bbb"
        }),
        $(go.TextBlock,{
            textAlign: "center",
            segmentOffset: new go.Point(0, -10),
            font: "14pt helvetica, arial, sans-serif",
            stroke: "#ff0000",
            margin: 4
        },
            new go.Binding("text", "text")
        )
    );
    myDiagram.model=go.Model.fromJson(diagramModel)
}

function initMonit(diagramModel){
    if(myDiagram){
        myDiagram.clear();
        myDiagram.div=null;
    }
    var $ = go.GraphObject.make;
    myDiagram=$(go.Diagram,"myDiagram",{
        initialAutoScale: go.Diagram.Uniform,
        "animationManager.isEnabled": false,
        scrollMode: go.Diagram.InfiniteScroll,
        contentAlignment: go.Spot.Center,
        "toolManager.hoverDelay": 0,
        "toolManager.toolTipDuration":0
    });
    myDiagram.clear();
    myDiagram.layout=$(go.TreeLayout,{
        angle: 0,
        layerSpacing: 80
    });
    myDiagram.nodeTemplate=$(go.Node,"Auto",{
        mouseEnter: mouseEnter,
        mouseLeave: mouseLeave
    },
        $(go.Shape,"RoundedRectangle",{
            fill: $(go.Brush, go.Brush.Linear, { 0: "white", 1: "#ccc" }),
            stroke: "#bbb", strokeWidth: 2,
            figure:"Rectangle"
        },
            new go.Binding("figure", "fig"),
            new go.Binding('location', 'loc', go.Point.Parse),
            new go.Binding("fill", "color")
        ),
        $(go.TextBlock,{
            font: "bold 14pt helvetica, bold arial, sans-serif",
            margin: 20
        },
            new go.Binding("text", "text")
        )
    );
    myDiagram.nodeTemplateMap.add("nodeMap1",$(go.Node,"Auto",{
        mouseEnter: mouseEnter,
        mouseLeave: mouseLeave
    },
    $(go.Shape, "RoundedRectangle",{
        fill:$(go.Brush, go.Brush.Linear, { 0: "white", 1: "#ccc" }),
        figure:"diamond",
        stroke: "#bbb"
    },
        new go.Binding("figure", "fig"),
        new go.Binding('location', 'loc', go.Point.Parse),
        new go.Binding("fill", "color")
    ),
    $(go.TextBlock,{
        font: "bold 10pt helvetica, bold arial, sans-serif",
        margin:8
    },
        new go.Binding("text", "text")
    )
    ));
    myDiagram.nodeTemplateMap.add("nodeMap2",$(go.Node,"Auto",{
        mouseEnter: mouseEnter,
        mouseLeave: mouseLeave
    },
        $(go.Shape,"RoundedRectangle",{
            fill: $(go.Brush, go.Brush.Linear, { 0: "white", 1: "#ccc" }),
            figure:"Rectangle"
        },
            new go.Binding("figure", "fig"),
            new go.Binding('location', 'loc', go.Point.Parse),
            new go.Binding("fill", "color"),
            new go.Binding("stroke", "color1")
        ),
        $(go.TextBlock,{
            font: "bold 14pt helvetica, bold arial, sans-serif",
            margin: 20
        },
            new go.Binding("text", "text")
        ),
        {
            toolTip:$(go.Adornment,"Auto",$(go.Shape,{
                fill: "#eee",
                stroke: "#bbb"
            }),
                $(go.Panel, "Vertical",$(go.TextBlock,{
                    margin:10,
                    width:360,
                    font:20
                },
                    new go.Binding("text", "",gettip)
                ))
            )
        }
    ));
    myDiagram.nodeTemplateMap.add("nodeMap3",$(go.Node, "Auto",{
        mouseEnter: mouseEnter,
        mouseLeave: mouseLeave
    },
        $(go.Shape, "RoundedRectangle",{
            fill:$(go.Brush, go.Brush.Linear,{
                0: "white",
                1: "#ccc"
            }),
            figure: "Rectangle"
        },
            new go.Binding("figure", "fig"),
            new go.Binding('location', 'loc', go.Point.Parse),
            new go.Binding("fill", "color"),
            new go.Binding("stroke", "color1")
        ),
        $(go.TextBlock,{
            font: "bold 14pt helvetica, bold arial, sans-serif",
            margin: 20
        },
            new go.Binding("text", "text")
        ),
        {
            toolTip:$(go.Adornment,"Auto",$(go.Shape,{
                fill: "#eee",
                stroke: "#bbb"
            }),
                $(go.Panel, "Vertical",$(go.TextBlock,{
                    margin:10,
                    width:530,
                    font:20
                },
                    new go.Binding("text", "",gettip)
                ))
            )
        }
    ));
    myDiagram.linkTemplate=$(go.Link,{
        routing: go.Link.AvoidsNodes,
        corner: 0
    },
        new go.Binding("points").makeTwoWay(),
        $(go.Shape,{
            isPanelMain: true,
            stroke: "#bbb"
        },
            new go.Binding("strokeDashArray", "dash"),
            new go.Binding("stroke", "color"),
            new go.Binding("strokeWidth", "width")
        ),
        $(go.Shape,{
            toArrow: "standard",
            stroke: "#bbb"
        },
            new go.Binding("fill", "color")
        ),
        $(go.TextBlock,{
            textAlign: "center",
            segmentOffset: new go.Point(0, -10),
            font: "10pt helvetica, arial, sans-serif",
            stroke: "#ff0000",
            margin: 4
        },
            new go.Binding("text", "text")
        )
    );
    myDiagram.model = go.Model.fromJson(diagramModel);
}
function parseXml(epgId,epgDefinition,ele){
    $('#myDiagram').empty();
    getAllMeu(epgId,function(data){
        var graphData=resetEpgDefinition(epgDefinition);
        var myDiagramModel=makeGraph(graphData,data);
        init(myDiagramModel,ele);
    });
}

function parseMoniteXml(epgId,executionId,epgDefinition){
    $('#myDiagram').empty();
    initParseMonite(epgId,executionId,epgDefinition);
}

function initParseMonite(epgId,executionId,epgDefinition){
    getAllMeu(epgId,function(data){
        var graphData=resetEpgDefinition(epgDefinition);
        var myDiagramModel=makeGraph(graphData,data);
        addNodeColor(executionId,myDiagramModel,function(diagramModel){
            initMonit(diagramModel);
            setTimer(epgId,executionId,epgDefinition);
        })
    });
}

function setTimer(epgId,executionId,epgDefinition){
    clearOutTimer(executionMeus.timer);
    executionMeus.timer=setTimeout(function(){
        initParseMonite(epgId,executionId,epgDefinition)
    },1000)
}

function gettip(getNode){
    return getNode.tiptext.replace(/",/g,'"\n').replace(/:/g,' ： ').replace(/{/g,'').replace(/}/,'').replace(/\\"/g,'"').replace(/;/g,'"\n\n').replace(/"""/g,'"').replace(/""/g,'"').replace(/}/g,'');
}

function mouseEnter() {
    clearOutTimer(executionMeus.timer);
}

function mouseLeave() {
    if(!executionMeus.elasticFlag){
        return;
    }else{
        var epgId=getStorage('epgId');
        var executionId=getStorage('executionId');
        var epgDefinition=getStorage('epgDefinition');
        initParseMonite(epgId,executionId,epgDefinition);
    }
}

$(function(){
    $('.nav-parent').click(function(){
        clearOutTimer(executionMeus.timer);
    });
    $('.children li').click(function(){
        clearOutTimer(executionMeus.timer);
    })
});
