var config = getConfig();
var serverIp=config.serverIp;
$(function(){
    var eventConfig=getEventConfig();
    var eventTable = TableInit();
    eventTable(eventConfig.columns,eventConfig.url,eventConfig.qp);

    $('#btn_query').click(function(){
        $("#tb_table").bootstrapTable('refresh', {url: eventConfig.url});
    });

    $('#tb_table').on('mouseenter','.row_detail_td',function(ev) {
        ev.preventDefault();
        var colIndex=$(this).parents('td').index();
        var index=Number($(this).parents('tr').attr('data-index'));
        var currentData=$('#tb_table').bootstrapTable('getData')[index];
        var eventId = currentData.id;
        var placement='left';
        if(colIndex<4){
            placement='right';
        }
        $('.popover').remove();
        $(this).popover({
            html: true,
            placement:placement,
            title: $('<span>' + eventId + '</span>'),
            content:rowDetail(currentData)
        }).on('shown.bs.popover', function(event) {
            var that = this;
            $(this).parent().find('div.popover').on('mouseenter', function() {
                $(that).attr('in', true);
            }).on('mouseleave', function(event) {
                event.preventDefault();
                $(that).removeAttr('in');
                $(that).popover('hide');
            });
        }).on('hide.bs.popover', function(event) {
            if($(this).attr('in')) {
                event.preventDefault();
            }
        }).popover('show');
    });

    $('#tb_table').on("mouseleave",'.row_detail_td',function(){
        $('div.popover').removeAttr('in');
        $('div.popover').popover('hide');
    });
});

function getEventConfig(){
    var columns=[{
        radio: true
    },{
        field: 'id',
        title: 'Event ID',
        valign:'middle',
        formatter:function(value,row,index){
            value=resetValue(value);
            return simpleId(value);
        }
    },{
        field: 'destinationTopic',
        title: 'DestinationTopic',
        valign:'middle',
        formatter:function(value,row,index){
            value=resetValue(value);
            return tableTopic(value);
        },
        width:200+'px'
    },{
        field: 'epgId',
        title: 'EPG ID',
        valign:'middle',
        formatter:function(value,row,index){
            value=resetValue(value);
            return simpleId(value);
        }
    },{
        field: 'sourceId',
        title: 'Source ID',
        valign:'middle',
        formatter:function(value,row,index){
            value=resetValue(value);
            return simpleId(value);
        }
    },{
        field: 'date',
        title: 'Date',
        valign:'middle',
        formatter:function(value,row,index){
            return getRowDetail(value,row,index);
        }
    },{
        field: 'serilNo',
        title: 'Seril No',
        valign:'middle',
        visible:false,
        formatter:function(value,row,index){
            value=resetValue(value);
            return getRowDetail(value,row,index);
        }
    },{
        field: 'operationId',
        title: 'OperationId',
        valign:'middle',
        visible:false,
        formatter:function(value,row,index){
            value=resetValue(value);
            return simpleId(value);
        }
    },{
        field: 'executionId',
        title: 'Execution ID',
        valign:'middle',
        formatter:function(value,row,index){
            value=resetValue(value);
            return simpleId(value);
        }
    },{
        field: 'sourceTopic',
        title: 'Source Topic',
        valign:'middle',
        formatter:function(value,row,index){
            value=resetValue(value);
            return tableTopic(value);
        }
    },{
        field: 'destinationId',
        title: 'Destination ID',
        valign:'middle',
        visible:false,
        formatter:function(value,row,index){
            value=resetValue(value);
            return simpleId(value);
        }
    }];
    var url=serverIp+'event';
    var queryParams=function(params){
        var num=(params.offset/params.limit)+1;
        var temp = {
            pageSize: params.limit,
            pageNumber: num,
            eventId: $(".eventId").val().trim(),
            destinationTopic: $(".destinationTopic").val().trim(),
            epgId: $(".epgId").val().trim(),
            sourceId: $(".sourceIdd").val().trim(),
            serilNo: $(".serilNo").val().trim(),
            opName: $(".operationId").val().trim(),
            executionId: $(".executionId").val().trim(),
            sourceTopic: $(".sourceTopic").val().trim(),
            destinationId: $(".destinationId").val().trim(),
            startTime: $(".startTime").val().trim(),
            endTime: $(".endTime").val().trim(),
            queryString:$('.keyword').val().trim()
        };
        deleteObjKey(temp);
       return temp;
    };
    return {
        columns:columns,
        url:url,
        qp:queryParams
    }
}

function tableTopic(value,row,index){
    if(value){
        return '<div class="table_topic row_detail_td">'+value+'</div>'
    }else{
        return '<div class="row_detail_td">-</div>';
    }
}

function getRowDetail(value,row,index){
    if(value){
        return '<div class="row_detail_td">'+value+'</div>';
    }else{
        return '<div class="row_detail_td">-</div>';
    }

}
