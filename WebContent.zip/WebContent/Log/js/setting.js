var config = getConfig();
var serverIp=config.serverIp;
var logSetting={
    runtimeData:null,
    containerLogData:{},
    appLogData:{},
    containerAllSwitch:false,
    appAllSwitch:false,
    containerLevel:-2,
    appLevel:-2,
    containerInit:false,
    appInit:false
};
$(function(){
    var RLConfig=getRLConfig();

    $('#runtimeLevel').multiselect({
        numberDisplayed:3,
        buttonWidth:'100%',
        maxHeight:200,
        includeSelectAllOption:false,
        enableFiltering:false,
        selectedClass: 'active-select',
        dropRight: true
    });
    $('#runtimeSwitch').bootstrapSwitch();
    $('#runtimeSwitch').bootstrapSwitch('setState',false);
    $('#runtimeSwitch').bootstrapSwitch('setActive',false);
    $('#runtimeLevel').multiselect('disable');
    getAjax(RLConfig.url,function(data){
        if(data.code===0){
            $('#runtimeSwitch').bootstrapSwitch('setActive',true);
            var dataObj=data.rows;
            logSetting.runtimeData=dataObj;
            if(dataObj.runtime!==-1){
                $('#runtimeSwitch').bootstrapSwitch('setState',true);
                $('#runtimeLevel').multiselect('deselect',0);
                $('#runtimeLevel').multiselect('select',dataObj.runtime);
            }else{
                $('#runtimeSwitch').bootstrapSwitch('setState',false);
                $('#runtimeLevel').multiselect('disable');
            }
        }
    },function(res){
        console.log(res);
        swal("Error~", res.message + " !", "error");
    });

    $('#runtimeSwitch').on('switch-change',function(e,data){
        var value=data.value;
        if(!value){
            $('#runtimeLevel').multiselect('disable');
            if(logSetting.runtimeData){
                logSetting.runtimeData.newLevel=-1;
                logSetting.runtimeData.switchFlag=false;
            }
        }else{
            $('#runtimeLevel').multiselect('enable');
            logSetting.runtimeData.switchFlag=true;
        }
    });

    $('#myTabs a[href="#runtime"]').on('shown.bs.tab',function(e){
        if(logSetting.runtimeData){
            var runtimeLevelData=parseInt($('#runtimeLevel').val());
            if(logSetting.runtimeData.runtime===-1){
                $('#runtimeSwitch').bootstrapSwitch('setState',false);
                $('#runtimeLevel').multiselect('deselect',runtimeLevelData);
                $('#runtimeLevel').multiselect('select',0);
                $('#runtimeLevel').multiselect('disable');
            }else{
                $('#runtimeSwitch').bootstrapSwitch('setState',true);
                $('#runtimeLevel').multiselect('deselect',runtimeLevelData);
                $('#runtimeLevel').multiselect('select',logSetting.runtimeData.runtime);
            }
        }
    });

    $('#myTabs a[href="#container"]').on('shown.bs.tab',function(e){
        if(!logSetting.containerInit){
            logSetting.containerInit=true;
            $('#containerAllSwitch').bootstrapSwitch();
            $('#containerAllSwitch').bootstrapSwitch('setState',false);
            $('#containerAllSwitch').bootstrapSwitch('setActive',false);
            var CLConfig=getCLConfig();
            var CLTable=TableInit('#logContainer',false,'#container_toolbar',function(data){
                $('#containerAllSwitch').bootstrapSwitch('setActive',true);
                logSetting.containerLevel=data.data.container.level;
                if(data.data.container.level!==-1){
                    $('#containerAllSwitch').bootstrapSwitch('setState',true);
                    $('#logContainer .updateLogBox').html(createPencile());
                    logSetting.containerAllSwitch=true;
                }else{
                    $('#containerAllSwitch').bootstrapSwitch('setState',false);
                    $('#logContainer .updateLogBox').html(disableEdit());
                    logSetting.containerAllSwitch=false;
                }

                $('#containerAllSwitch').on('switch-change',function(e,data){
                    var value=data.value;
                    if(!value){
                        logSetting.containerAllSwitch=false;
                        $('#logContainer .updateLogBox').html(disableEdit());
                        for(var key in logSetting.containerLogData){
                            var currentData=logSetting.containerLogData[key].currentData;
                            var id=currentData.id;
                            if(currentData.level!==-1){
                                $('#logSwitch'+id).bootstrapSwitch('setState',true);
                                $('#logSwitch'+id).parents('tr').find('.level_wrap').html(createSelect(id));
                                initCreateSelect(id,currentData);
                                $('#logLevel'+id).multiselect('deselect',0);
                                $('#logLevel'+id).multiselect('select',currentData.level);
                                $('#logLevel'+id).multiselect('disable');
                            }else{
                                $('#logSwitch'+id).bootstrapSwitch('setState',false);
                                $('#logSwitch'+id).parents('tr').find('.level_wrap').html('-');
                            }
                            $('#logSwitch'+id).bootstrapSwitch('setActive',false);
                        }
                        logSetting.containerLogData={};
                    }else{
                        logSetting.containerAllSwitch=true;
                        $('#logContainer .updateLogBox').html(createPencile());
                    }
                    $('#logContainer').bootstrapTable('uncheckAll')
                })

            });

            CLTable(CLConfig.columns,CLConfig.url,CLConfig.qp);
        }
    });

    $('#myTabs a[href="#app"]').on('shown.bs.tab',function(e){
        if(!logSetting.appInit){
            logSetting.appInit=true;
            $('#appAllSwitch').bootstrapSwitch();
            $('#appAllSwitch').bootstrapSwitch('setState',false);
            $('#appAllSwitch').bootstrapSwitch('setActive',false);
            var ALConfig=getALConfig();
            var ALTable=TableInit('#logApp',false,'#app_toolbar',function(data){
                $('#appAllSwitch').bootstrapSwitch('setActive',true);
                logSetting.appLevel=data.data.app.level;
                if(logSetting.appLevel!==-1){
                    $('#appAllSwitch').bootstrapSwitch('setState',true);
                    $('#logApp .updateLogBox').html(createPencile());
                    logSetting.appAllSwitch=true;
                }else{
                    logSetting.appAllSwitch=false;
                    $('#appAllSwitch').bootstrapSwitch('setState',false);
                    $('#logApp .updateLogBox').html(disableEdit());
                }
                $('#appAllSwitch').on('switch-change',function(e,data){
                    var value=data.value;
                    if(!value){
                        logSetting.appAllSwitch=false;
                        $('#logApp .updateLogBox').html(disableEdit());
                        for(var key in logSetting.appLogData){
                            var currentData=logSetting.appLogData[key].currentData;
                            var id=currentData.id;
                            if(currentData.level!==-1){
                                $('#logSwitch'+id).bootstrapSwitch('setState',true);
                                $('#logSwitch'+id).parents('tr').find('.level_wrap').html(createSelect(id));
                                initCreateSelect(id,currentData);
                                $('#logLevel'+id).multiselect('deselect',0);
                                $('#logLevel'+id).multiselect('select',currentData.level);
                                $('#logLevel'+id).multiselect('disable');
                            }else{
                                $('#logSwitch'+id).bootstrapSwitch('setState',false);
                                $('#logSwitch'+id).parents('tr').find('.level_wrap').html('-');
                            }
                            $('#logSwitch'+id).bootstrapSwitch('setActive',false);
                        }
                        logSetting.appLogData={};
                    }else{
                        logSetting.appAllSwitch=true;
                        $('#logApp .updateLogBox').html(createPencile());
                    }
                    $('#logApp').bootstrapTable('uncheckAll')
                })
            });
          ALTable(ALConfig.columns,ALConfig.url,ALConfig.qp);
        }
    });

    $('#myTabs a[href="#container"]').on('hide.bs.tab',function(e){
        var flag = true;
        for(var key in logSetting.containerLogData){
            if(logSetting.containerLogData[key].newData){
                flag=false;
            }
        }

        if(logSetting.containerAllSwitch){
            if(logSetting.containerLevel===-1){
                flag=false;
            }
        }else{
            if(logSetting.containerLevel!==-1){
                flag=false;
            }
        }
        if(!flag){
            $('.alert').removeClass('hide');
            e.preventDefault();
        }
    });

    $('#myTabs a[href="#app"]').on('hide.bs.tab',function(e){
        var flag=true;
        for(var key in logSetting.appLogData){
            if(logSetting.appLogData[key].newData){
                flag=false;
            }
        }

        if(logSetting.appAllSwitch){
            if(logSetting.appLevel===-1){
                flag=false;
            }
        }else{
            if(logSetting.appLevel!==-1){
                flag=false;
            }
        }

        if(!flag){
            $('.alert').removeClass('hide');
            e.preventDefault();
        }
    });

    $('.close').click(function(){
        $('.alert').addClass('hide')
    });

    (function(){
        var flag=false;
        $('.runtimeOk').click(function(){
            var runtimeLevelData=parseInt($('#runtimeLevel').val());
            if(logSetting.runtimeData.switchFlag===false){
                logSetting.runtimeData.newLevel=-1;
            }else{
                logSetting.runtimeData.newLevel=runtimeLevelData;
            }
            var putRuntime=JSON.stringify({"runtime":logSetting.runtimeData.newLevel});
            if(!flag){
                flag=true;
                var url='log/setting/runtime';
                putAjax(url,putRuntime,function(data){
                    if(data.code===0){
                        flag=false;
                        logSetting.runtimeData.runtime=logSetting.runtimeData.newLevel;
                        delete logSetting.runtimeData.newLevel;
                        delete logSetting.runtimeData.switchFlag;
                        swal("Success~","Runtime Log Setting Success !", "success");
                    }else{
                        flag=false;
                        swal("Error~", data.message + " !", "error");
                    }
                },function(res){
                    console.log(res);
                    swal("Error~", res.message + " !", "error");
                })
            }
        })
    })();

    $('.runtimeCancel').click(function(){
        var runtimeLevelData=parseInt($('#runtimeLevel').val());
        if(logSetting.runtimeData.runtime===-1){
            $('#runtimeSwitch').bootstrapSwitch('setState',false);
            $('#runtimeLevel').multiselect('deselect',runtimeLevelData);
            $('#runtimeLevel').multiselect('select',0);
            $('#runtimeLevel').multiselect('disable');
        }else{
            $('#runtimeSwitch').bootstrapSwitch('setState',true);
            $('#runtimeLevel').multiselect('deselect',runtimeLevelData);
            $('#runtimeLevel').multiselect('select',logSetting.runtimeData.runtime);
        }
    });

    $('#logContainer').off('click','.updateLog').on('click','.updateLog',updateLog);

    $('#logApp').off('click','.updateLog').on('click','.updateLog',updateLog);

    $('#logContainer').off('click','.logCancel').on('click','.logCancel',cancelSetting);

    $('#logApp').off('click','.logCancel').on('click','.logCancel',cancelSetting);

    $('.container_save').click(function(){
        var putContainer={
            "container":{
                "level":-1,
                "logLevelInfos":[]
            }
        };
        if(logSetting.containerAllSwitch){
            putContainer.container.level=9;
            for(var key in logSetting.containerLogData){
                var currentData=logSetting.containerLogData[key];
                var containerCurrent={
                    id:currentData.newData.id,
                    level:currentData.newData.level
                };
                putContainer.container.logLevelInfos.push(containerCurrent);
            }
        }else{
            putContainer.container.level=-1;
        }
        putContainer=JSON.stringify(putContainer);
        var url='log/setting/container';
        putAjax(url,putContainer,function(data){
            if(data.code===0){
                for(var key in logSetting.containerLogData){
                    var currentData=logSetting.containerLogData[key];
                    currentData.currentData.level=currentData.newData.level;
                    $('#logSwitch'+currentData.currentData.id).bootstrapSwitch('setActive',false);
                    if(currentData.newData.level!==-1){
                        $('#logLevel'+currentData.currentData.id).multiselect('disable');
                    }
                }
                if(logSetting.containerAllSwitch){
                    $('#logContainer .updateLogBox').html(createPencile());
                    logSetting.containerLevel=9;
                }else{
                    $('#logContainer .updateLogBox').html(disableEdit());
                    logSetting.containerLevel=-1;
                }
                $('#logContainer').bootstrapTable('uncheckAll');
                $('.alert').addClass('hide');
                logSetting.containerLogData={};
                swal("Good~", "Log Setting Success!", "success");
            }else{
                $('.alert').addClass('hide');
                swal("Error~", data.message+"!", "error");
            }
        },function(res){
            console.log(res);
            $('.alert').addClass('hide');
            swal("Error~", res.message+"!", "error");
        })
    });

    $('.container_cancel').click(function(){
        if(logSetting.containerLevel===-1){
            $('#containerAllSwitch').bootstrapSwitch('setState',false);
            $('#logContainer .updateLogBox').html(disableEdit());
        }else{
            $('#containerAllSwitch').bootstrapSwitch('setState',true);
            $('#logContainer .updateLogBox').html(createPencile());
        }
        for(var key in logSetting.containerLogData){
            var currentData=logSetting.containerLogData[key];
            var id=currentData.currentData.id;
            if(currentData.currentData.level!==-1){
                $('#logSwitch'+id).bootstrapSwitch('setState',true);
                $('#logSwitch'+id).parents('tr').find('.level_wrap').html(createSelect(id));
                initCreateSelect(id,currentData.currentData);
                $('#logLevel'+id).multiselect('deselect',0);
                $('#logLevel'+id).multiselect('select',currentData.currentData.level);
                $('#logLevel'+id).multiselect('disable');
            }else{
                $('#logSwitch'+id).bootstrapSwitch('setState',false);
                $('#logSwitch'+id).parents('tr').find('.level_wrap').html('-');
            }
            $('#logSwitch'+id).bootstrapSwitch('setActive',false);
        }
        $('.alert').addClass('hide');
        logSetting.containerLogData={};
        $('#logContainer').bootstrapTable('uncheckAll');
    });

    $('.app_save').click(function(){
        var putApp={
            "app":{
                "level":-1,
                "logLevelInfos":[]
            }
        };
        if(logSetting.appAllSwitch){
            putApp.app.level=9;
            for(var key in logSetting.appLogData){
                var currentData=logSetting.appLogData[key];
                var appCurrent={
                    id:currentData.newData.id,
                    level:currentData.newData.level
                };
                putApp.app.logLevelInfos.push(appCurrent);
            }
        }else{
            putApp.app.level=-1;
        }
        putApp=JSON.stringify(putApp);
        var url='log/setting/app';
        putAjax(url,putApp,function(data){
            if(data.code===0){
                for(var key in logSetting.appLogData){
                    var currentData=logSetting.appLogData[key];
                    currentData.currentData.level=currentData.newData.level;
                    $('#logSwitch'+currentData.currentData.id).bootstrapSwitch('setActive',false);
                    if(currentData.newData.level!==-1){
                        $('#logLevel'+currentData.currentData.id).multiselect('disable');
                    }
                }
                if(logSetting.appAllSwitch){
                    $('#logApp .updateLogBox').html(createPencile());
                    logSetting.appLevel=9;
                }else{
                    $('#logApp .updateLogBox').html(disableEdit());
                    logSetting.appLevel=-1;
                }
                $('#logApp').bootstrapTable('uncheckAll');
                logSetting.appLogData={};
                $('.alert').addClass('hide');
                swal("Good~", "Log Setting Success!", "success");
            }else{
                $('.alert').addClass('hide');
                swal("Error~", data.message+"!", "error");
            }
        },function(res){
            console.log(res);
            $('.alert').addClass('hide');
            swal("Error~", res.message+"!", "error");
        })
    });

    $('.app_cancel').click(function(){
        if(logSetting.appLevel===-1){
            $('#appAllSwitch').bootstrapSwitch('setState',false);
            $('#logApp .updateLogBox').html(disableEdit());
        }else{
            $('#appAllSwitch').bootstrapSwitch('setState',true);
            $('#logApp .updateLogBox').html(createPencile());
        }
        for(var key in logSetting.appLogData){
            var currentData=logSetting.appLogData[key].currentData;
            var id=currentData.id;
            if(currentData.level!==-1){
                $('#logSwitch'+id).bootstrapSwitch('setState',true);
                $('#logSwitch'+id).parents('tr').find('.level_wrap').html(createSelect(id));
                initCreateSelect(id,currentData);
                $('#logLevel'+id).multiselect('deselect',0);
                $('#logLevel'+id).multiselect('select',currentData.level);
                $('#logLevel'+id).multiselect('disable');
            }else{
                $('#logSwitch'+id).bootstrapSwitch('setState',false);
                $('#logSwitch'+id).parents('tr').find('.level_wrap').html('-');
            }
            $('#logSwitch'+id).bootstrapSwitch('setActive',false);
        }
        logSetting.appLogData={};
        $('.alert').addClass('hide');
        $('#logApp').bootstrapTable('uncheckAll');
    });

});

function getCLConfig(){
    var columns=[{
        checkbox: true,
        clickToSelect:false
    },{
        field: 'name',
        title: 'Name',
        clickToSelect:false,
        formatter:function(value,row,index){
            var name=value;
            if(row.webUrl){
                name=value+'('+row.webUrl+')';
            }
            return name;
        }
    },{
        field: 'level',
        title: 'Level',
        formatter:function(value,row,index){
            initSelect(value,row);
            return getLevel(value,row);
        },
        clickToSelect:false
    },{
        field: 'level',
        title: 'Switch',
        formatter:function(value,row,index){
            initSwitch(value,row);
            return getSwitch(row.id);
        },
        clickToSelect:false
    },{
        field: 'id',
        title: '',
        formatter:function(value,row,index){
            return getUpdate(-1);
        },
        valign:'middle',
        width:80,
        clickToSelect:true
    }];
    var url=serverIp+'log/setting/container';
    var queryParams=function(params){
        var num=(params.offset/params.limit)+1;
        var temp={
            pageSize:params.limit,
            pageNumber:num
        };
        return temp;
    };
    return {
      columns:columns,
        url:url,
        qp:queryParams
    }
}

function getALConfig(){
    var columns=[{
        checkbox: true,
        clickToSelect:false
    },{
        field: 'name',
        title: 'Name',
        clickToSelect:false
    },{
        field: 'level',
        title: 'Level',
        formatter:function(value,row,index){
            initSelect(value,row);
            return getLevel(value,row);
        },
        clickToSelect:false
    },{
        field: 'level',
        title: 'Switch',
        formatter:function(value,row,index){
            initSwitch(value,row);
            return getSwitch(row.id);
        },
        clickToSelect:false
    },{
        field: 'id',
        title: '',
        formatter:function(value,row,index){
            return getUpdate(-1);
        },
        valign:'middle',
        width:80,
        clickToSelect:true
    }];
    var url=serverIp+'log/setting/app';
    var queryParams=function(params){
        var num=(params.offset/params.limit)+1;
        var temp={
            pageSize:params.limit,
            pageNumber:num
        };
        return temp;
    };
    return {
      columns:columns,
        url:url,
        qp:queryParams
    }
}

function getRLConfig(){
    var url='log/setting/runtime';
    return {
        url:url
    }
}

function initCreateSelect(id,row){
    $('#logLevel'+id).multiselect({
        buttonWidth:'100%',
        maxHeight:200,
        includeSelectAllOption:false,
        enableFiltering:false,
        selectedClass: 'active-select',
        dropRight: true,
        onChange:function(element,checked){
            var isContainer=false;
            isContainer=row["id"].indexOf('CONTAINER')>-1?true:false;
            if(isContainer){
                logSetting.containerLogData[id].newData["level"]=parseInt(element[0].value);
            }else{
                logSetting.appLogData[id].newData["level"]=parseInt(element[0].value);
            }
        }
    })
}


function updateLog(){
    var parentNode=$(this).parents('table').attr('id');
    var index=$(this).parents('tr').index();
    var currentData=null;
    if(parentNode==='logContainer'){
        currentData=$('#logContainer').bootstrapTable('getData')[index];
        logSetting.containerLogData[currentData.id]={
            currentData:currentData,
            newData:deepClone(currentData)
        };
    }else if(parentNode==='logApp'){
        currentData=$('#logApp').bootstrapTable('getData')[index];
        logSetting.appLogData[currentData.id]={
            currentData:currentData,
            newData:deepClone(currentData)
        };
    }
    $('#logSwitch'+currentData.id).bootstrapSwitch('setActive',true);
    $('#logLevel'+currentData.id).multiselect('enable');
    var btns=createBtn();
    $(this).parent().html(btns);
}

function cancelSetting(){
    var parentNode=$(this).parents('table').attr('id');
    var index=$(this).parents('tr').index();
    var currentData=null;
    if(parentNode==='logContainer'){
        currentData=$('#logContainer').bootstrapTable('getData')[index];
    }else if(parentNode==='logApp'){
        currentData=$('#logApp').bootstrapTable('getData')[index];
    }
    var id=currentData.id;
    if(currentData.level!==-1){
        $('#logSwitch'+id).bootstrapSwitch('setState',true);
        $(this).parents('tr').find('.level_wrap').html(createSelect(id));
        initCreateSelect(id,currentData);
        $('#logLevel'+id).multiselect('deselect',0);
        $('#logLevel'+id).multiselect('select',currentData.level);
        $('#logLevel'+id).multiselect('disable');
    }else{
        $('#logSwitch'+id).bootstrapSwitch('setState',false);
        $(this).parents('tr').find('.level_wrap').html('-');
    }
    if(parentNode==='logContainer'){
        delete logSetting.containerLogData[id];
    }else if(parentNode==='logApp'){
        delete logSetting.appLogData[id];
    }

    $('#logSwitch'+id).bootstrapSwitch('setActive',false);
    $(this).parents('.updateLogBox').html(createPencile());
}

function initSelect(value,row){
    var el = '#logLevel'+row.id;
    setTimeout(function(){
        $(el).multiselect({
            buttonWidth:'100%',
            maxHeight:200,
            includeSelectAllOption:false,
            enableFiltering:false,
            selectedClass: 'active-select',
            dropRight: true,
            onChange:function(element,checked){
                var isContainer=false;
                isContainer=row.id.indexOf('CONTAINER')>-1?true:false;
                if(isContainer){
                    logSetting.containerLogData[row.id].newData["level"]=parseInt(element[0].value);
                }else{
                    logSetting.appLogData[row.id].newData["level"]=parseInt(element[0].value);
                }
            }
        });
        $(el).multiselect('deselect',0);
        $(el).multiselect('select',value);
        $(el).multiselect('disable');
    },100)
}

function initSwitch(value,row){
    setTimeout(function(){
        var el='#logSwitch'+row.id;
        $(el).bootstrapSwitch();
        var isContainer=false;
        isContainer=row.id.indexOf('CONTAINER')>-1?true:false;
        if(value===-1){
            $(el).bootstrapSwitch('setState',false);
        }else{
            $(el).bootstrapSwitch('setState',true);
        }
        $(el).bootstrapSwitch('setActive',false);
        $(el).on('switch-change',function(e,data){
            var value=data.value;
            if(!value){
                $(this).parents('tr').find('.level_wrap').html('-');
                if(isContainer){
                    logSetting.containerLogData[row.id].newData["level"]=-1;
                }else{
                    logSetting.appLogData[row.id].newData["level"]=-1;
                }
            }else{
                var id=row.id;
                $(this).parents('tr').find('.level_wrap').html(createSelect(id));
                initCreateSelect(id,row);
                $('#logLevel'+id).multiselect('deselect',0);
                $('#logLevel'+id).multiselect('select',2);
                if(isContainer){
                    logSetting.containerLogData[row.id].newData["level"]=2;
                }else{
                    logSetting.appLogData[row.id].newData["level"]=2;
                }
            }
        })
    },100)
}

function getSwitch(value){
    return '<div class="switch" tabindex="0" style="outline: none;" id="logSwitch'+value+'">'+
        '<input type="checkbox" checked="checked" name="runtimeSwitch"/>'+
        '</div>';
}

function getLevel(value,row){
    var selectStr=createSelect(row.id);
    if(row.level===-1){
        return '<div class="level_wrap">-</div>';
    }else if(row.level!==-1){
        return '<div class="level_wrap">'+selectStr+'</div>'
    }
}

function createSelect(id){
    return '<select class="multiselect log_level"  name="logLevel" id="logLevel'+id+'">'+
        '<option value="0">TRACE</option>'+
        '<option value="1">DEBUG</option>'+
        '<option value="2">INFO</option>'+
        '<option value="3">WARN</option>'+
        '<option value="4">ERROR</option>'+
        '</select>'
}

function getUpdate(switchData){
    var pencilStr=createPencile();
    var disableEditStr=disableEdit();
    if(switchData===-1){
        return '<div class="updateLogBox">'+disableEditStr+'</div>'
    }else{
        return '<div class="updateLogBox">'+pencilStr+'</div>'
    }

}

function disableEdit(){
    return '<span class="glyphicon glyphicon-pencil text-default"></span>'
}

function createPencile(){
    return '<span class="glyphicon glyphicon-pencil text-primary updateLog"></span>';
}

function createBtn(){
    return '<span class="glyphicon glyphicon-remove logCancel"></span>'
}
