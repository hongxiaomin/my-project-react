var config = getConfig();
serverIp=config.serverIp;
$(function(){
    var meuConfig=getMeuConfig();
    var meuTable=TableInit();
    meuTable(meuConfig.columns,meuConfig.url,meuConfig.qp);

    $('.status').multiselect({
        numberDisplayed:3,
        buttonWidth:'100%',
        maxHeight:200,
        includeSelectAllOption:false,
        enableFiltering:false,
        selectedClass: 'active-select',
        dropRight: true
    });


    $('#btn_query').click(function(){
       $('#tb_table').bootstrapTable('refresh');
    });

    $('#tb_table').off('mouseenter','.meu_signature').on('mouseenter','.meu_signature',function(event){
        if($(this).html()==='-'){
            return;
        }
        showPopover.call(this,event,'Signature','left');
    });

    $('#tb_table').off("mouseleave",'.meu_signature').on("mouseleave",'.meu_signature',function(event){
        hidePopover(event);
    });
});

function getMeuConfig(){
    var columns=[{
        radio: true
    },{
        field: 'id',
        title: 'MEU ID',
        formatter:function(value,row,index){
            return simpleId(value);
        }
    },{
        field: 'name',
        title: 'Name'
    },{
        field: 'type',
        title: 'Type',
        formatter:function(value,row,index){
            value=resetValue(value);
            return value;
        }
    },{
        field: 'status',
        title: 'Status',
        formatter:function(value,row,index){
            value=initMeuStatus(value);
            return value;
        }
    },{
        field: 'containerId',
        title: 'Container ID',
        formatter:function(value,row,index){
            return simpleId(value);
        },
        visible:false
    },{
        field: 'md5',
        title: 'MD5',
        formatter:function(value,row,index){
            value=resetValue(value);
            return simpleId(value);
        },
        visible:false
    },{
        field: 'version',
        title: 'Version',
        formatter:function(value,row,index){
            value=resetValue(value);
            return value;
        },
        visible:false
    },{
        field: 'author',
        title: 'Author',
        formatter:function(value,row,index){
            value=resetValue(value);
            return value;
        },
        visible:false
    },{
        field: 'signature',
        title: 'Signature',
        formatter:function(value,row,index){
            value=resetValue(value);
            if(value){
                return '<p class="meu_signature">'+value+'</p>';
            }else{
                return value;
            }
        },
        width:200+'px',
        visible:false
    },{
        field: 'description',
        title: 'Description',
        formatter:function(value,row,index){
            value=resetValue(value);
            return value;
        }
    }];
    var url=serverIp+'meu';
    var queryParams = function (params) {
        var offset=params.offset;
        var numbers=(offset/params.limit)+1;
        var statusArr=[];
        if($('.status').val()){
            $('.status').val().forEach(function(status){
                statusArr.push(Number(status));
            });
        }

        var temp = {
            pageSize: params.limit,
            pageNumber: numbers,
            meuId: $(".id").val().trim(),
            name: $(".name").val().trim(),
            type: $(".type").val().trim(),
            status:$('.status').val()?JSON.stringify(statusArr):'',
            md5: $(".md5").val().trim(),
            version: $(".version").val().trim(),
            author: $(".author").val().trim(),
            signature: $(".signature").val().trim(),
            description: $(".description").val().trim()
        };
        deleteObjKey(temp);
        return temp;
    };
    return {
        columns:columns,
        url:url,
        qp:queryParams
    }
}

