var config=getConfig();
var serverIp=config.serverIp;
var appListConfig={
    timer:{
      interval:null,
        timeout:null
    },
    deleteAjax:null,
    progressAjax:null,
    appAllMeu:{}
};
$(function(){
    var appConfig=getAppConfig();
    var appTable=TableInit('#tb_table',true);
    appTable(appConfig.columns,appConfig.url,appConfig.qp,'name');

    $('#btn_query').click(function(){
        $('#tb_table').bootstrapTable('refresh',{
            url:appConfig.url
        })
    });

    $('#btn_add').click(function() {
        showRight('deploy');
        menuActive('.menuDeploy');
    });

    $('#btn_delete').click(function(){
        var currentData=$('#tb_table').bootstrapTable('getSelections')[0];
        if(!currentData){
            $(this).css("z-index",0);
            swal("Wait !", "Please select a row to delete !", "info");
            return;
        }
        var appId=currentData.id;
        var deleteAppUrl='app?appId='+appId;
        appListConfig.deleteAjax=deleteAjax(deleteAppUrl,function(data){
            if(data.code===0){
                var deploymentId = data.rows.deploymentId;
                timekeeper(appListConfig.timer,function(){
                    swal("Error~", "Remove Failed!", "error");
                },function(){
                    var progressUrl='deployment/progress?deploymentId=' + deploymentId;
                    getProgress(progressUrl,appListConfig.progressAjax,appId,appListConfig.timer,function(){
                        $('#tips').css('right',0);                         swal("Good~", "Remove Success" + " !", "success");
                        $("#tb_table").bootstrapTable('refresh');
                    },function(){
                        swal("Error~", "Remove Failed !" + " !", "error");
                    },function(){
                        $('.appTable').hide();
                        $('.appProgress').show();
                    });
                });
               
            }else{
                swal("Error!", data.message +" !", "error")
            }
        },function(res){
            swal("Error!", res.message +" !", "error")
        })
    });

    $('.appProgress table').on('click','.deployInfo',function(){
        var value=$(this).val();
        var reg=/Deployment\s*ID\s*=\s*\[([a-z0-9-]+)\]/g;
        if(reg.test(value)){
            var deploymentId=/Deployment\s*ID\s*=\s*\[([a-z0-9-]+)\]/g.exec(value)[1];
            if(deploymentId){
                putStorage('deploymentId',deploymentId);
                showRight('logList');
                menuActive($('.menuLogList'));
            }
        }

    });

    // $('#btn_update').click(function(){
    //     var currentData=$('#tb_table').bootstrapTable('getSelections')[0];
    //     if(!currentData){
    //         $(this).css("z-index",0);
    //         swal("Wait !", "Please select a row to delete !", "info");
    //         return;
    //     }
    //     var appId=currentData.id;
    //     var deployObj={
    //         appId:appId
    //     };
    //     putStorage('deployObj',JSON.stringify(deployObj));
    //     showRight('deploy');
    //     menuActive('.menuDeploy');
    // });

    $('#tb_table').off('click','.deployment_link').on('click','.deployment_link',function(){
        var deploymentId=$('#tb_table').bootstrapTable('getSelections')[0].deploymentId;
        if(deploymentId){
            putStorage('deploymentId',deploymentId);
            showRight('logList');
            menuActive($('.menuLogList'));
        }
    });

    $('#tb_table').off('mouseenter','.appEpg').on('mouseenter','.appEpg',function(event){
        event.preventDefault();
        var EpgID = $(this).attr('data_id');
        var EpgName= $(this).html();
        $('.popover').remove();
        $(this).popover({
            html: true,
            placement:'right',
            title: title(EpgName+'('+EpgID+')'),
            content: function() {
                return content(EpgID);
            }
        }).on('shown.bs.popover', function(event) {
            var that = this;
            $(this).parent().find('div.popover').on('mouseenter', function() {
                $(that).attr('in', true);
            }).on('mouseleave', function() {
                $(that).removeAttr('in');
                $(that).popover('hide');

            });
        }).on('hide.bs.popover', function(event) {
            if($(this).attr('in')) {
                event.preventDefault();
            }
        }).popover('show');
    });

    $('#tb_table').off("mouseleave",'.appEpg').on("mouseleave",'.appEpg',function(event){
        event.preventDefault();
        $('div.popover').removeAttr('in');
        $('div.popover').popover('hide');
    });


    $('#tb_table').off('mouseenter','.appMeu').on('mouseenter', '.appMeu', function() { //show meuDetail
        var meuId = $(this).attr('data_id');
        var epgId=$(this).attr('data_epgId');
        var title=$(this).attr('data_title');
        var index=$(this).parents('.detail-view').prev().attr('data-index');
        var appId=$('#tb_table').bootstrapTable('getData')[index].id;
        var currentMeu=appListConfig.appAllMeu[appId][epgId][meuId];
        $('.popover').remove();
        $(this).popover({
            html: true,
            title: meuTitle(title),
            placement:'left',
            content:meuContent(currentMeu)
        }).on('shown.bs.popover', function(event) {
            var that = this;
            $(this).parent().find('div.popover').on('mouseenter', function() {
                $(that).attr('in', true);
            }).on('mouseleave', function(event) {
                event.preventDefault();
                $(that).removeAttr('in');
                $(that).popover('hide');
            });
        }).on('hide.bs.popover', function(event) {
            if($(this).attr('in')) {
                event.preventDefault();
            }
        }).popover('show');
    });

    $('#tb_table').off("mouseleave",'.appMeu').on("mouseleave",'.appMeu',function(){
        $('div.popover').removeAttr('in');
        $('div.popover').popover('hide');
    });

    $('#tb_table').off('click','.showDetail').on('click','.showDetail',function(){
        var epgValue=$(this).html().split('(')[1].split(')')[0];
        putStorage('epgDetailId',epgValue);
        showRight('EpgLists');
        menuActive($('.menuEPG'));
    });

    $('.APPLIST').click(function(){
        $('.ng-monitor').show();
        $('.ng-listDetail').hide();
    });

    $('#tb_table').off('click','.appId').on('click','.appId',function(){
        var appId=$('#tb_table').bootstrapTable('getSelections')[0].id;
        getAppDetail(appId);
        getAppTree(appId);
        $('.ng-monitor').hide();
        $('.ng-listDetail').show();
    });

    $('.updateMeus').off('change','.updateFile').on('change','.updateFile',function(e){
        e.preventDefault();
        var name=this.files[0].name;
        var updateObj={
            file:$(this),
            btn:$(this).siblings('button'),
            text:$(this).siblings('.updateText'),
            id:$(this).parents('tr').find('.sample_id ').attr('data_id'),
            form:$(this).parent('.updateMeu'),
            box:$(this).parents('tr').children('td').last()
        };
        updateObj["text"].val(name);
        updateMeuSubmit(updateObj);
    });

    $('.nav-parent').on('click',function(){
        clearTimer(appListConfig.timer.interval,appListConfig.timer.timeout);
        abortAjax();
    });

    $('.children li').on('click',function(){
        clearTimer(appListConfig.timer.interval,appListConfig.timer.timeout);
        abortAjax();
    });
});

function getAppConfig(){
    var columns=[{
        radio: true,
        formatter: function(value, row, index) {
            var s = row.status;
            if(s==='Deploying'){
                return {disabled:true};
            }
        }
    },{
        field: 'id',
        title: 'ID',
        formatter: function(value, row, index) {
            var appAllMeu=appListConfig.appAllMeu;
            if(!appAllMeu[row.id]){
                appAllMeu[row.id]={};
            }
            var appEpg=row.epg;
            if(appEpg&&appEpg.length>0){
                appEpg.forEach(function(epg){
                    if(!appAllMeu[row.id][epg.id]){
                        appAllMeu[row.id][epg.id]={};
                    }
                    var epgMeu=epg.meu;
                    epgMeu.forEach(function(meu){
                        appAllMeu[row.id][epg.id][meu.id+meu.containerId]=meu;
                    })
                });
            }
           
            return operateEventsId(value, row, index);

        },
        sortable:true
    },{
        field: 'name',
        title: 'Name',
        sortable:true
    },
    // {
    //     field: 'deploymentId',
    //     title: 'Deployment ID',
    //     formatter: function(value, row, index) {
    //         if(!value){
    //             return null;
    //         }
    //         return '<div class="deployment_link">'+simpleId(value)+'</div>'
    //     }
    // },
    {
        field: 'status',
        title: 'Status',
        sortable:true
    }];
    var url=serverIp+'app';
    var queryParams=function(params){
        var numbers=(params.offset/params.limit)+1;
        var temp={
            pageSize:params.limit,
            pageNumber:numbers,
            appId:$(".id").val().trim(),
            sortName:params.sort,
            sortOrder:params.order
        };
        deleteObjKey(temp);
        return temp;
    };
    return{
        columns:columns,
        url:url,
        qp:queryParams
    }
}


function operateEventsId(value,row,index){

    return '<div class="appId">' + simpleId(value) + '</div>';
}

function content(id){
    var epgUrl='epg?epgId='+id;
    getAjax(epgUrl,function(data){
        var currentEpgData=data.rows[0];
        if(currentEpgData){
            var epgDefinition=currentEpgData.epgDefinition;
            parseXml(id,epgDefinition);
        }
    },function(res){
        console.log(res);
    });
    var data=$('#diagramPopover').html();
    return data;
}

function title(id){
    var titleStr = $('<a href="javascript:;" class="showDetail">' + id + '</a>')
    return titleStr;
}

function meuTitle(id){
    var titles = $('<span>' + id + '</span>');
    return titles;
}

function meuContent(currentMeu){
    var MeuContent=$('<div class="MeuContent"></div>');
    var type=currentMeu.type?currentMeu.type:'';
    var status=currentMeu.status?initMeuStatus(currentMeu.status):'';
    var addMeuData = $('<div><label>MEU ID:</label><span>' + currentMeu.id + '</span></div><div><label>MEU Name:</label><span>' + currentMeu.name + '</span></div><div><label>Type:</label><span>' + type + '</span></div><div><label>Status:</label><span>'+ status+'</span></div><div><label>Container ID:</label><span>'+ currentMeu.containerId+'</span></div><div><label>Description:</label><span>'+currentMeu.description + '</span></div>');
    MeuContent.append(addMeuData);
    return MeuContent;
}

function getAppDetail(appId){
    var appDetailUrl='app?appId='+appId;
    getAjax(appDetailUrl,function(res){
        var data=res.rows[0];
        var epgStr='';
        var meuStr='';
        var meuArr=[];
        data.epg.forEach(function(item){
            epgStr+=item.name+'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
            meuArr=meuArr.concat(item.meu);
        });
        meuArr.forEach(function(item){
            meuStr+=item.name+'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'
        });
        $('.listDetailInfo p:eq(0) span').html(data.id);
        $('.listDetailInfo p:eq(1) span').html(data.name);
        $('.listDetailInfo p:eq(2) span').html(data.description);
        $('.listDetailInfo p:eq(3) span').html(epgStr);
        $('.listDetailInfo p:eq(4) span').html(meuStr);
        $('.listDetailInfo p:eq(5) span').html(data.deploymentId);
        $('.listDetailInfo p:eq(6) span').html(data.status);
    },function(res){
        console.log(res);
    })
}

function getAppTree(appId){
    var setting={
        data:{
            simpleData:{
                enable:true
            },
            key:{
                title:"fullName"
            }
        }
    };
    getConfigurationRecord(appId,setting);
}

function getConfigurationRecord(appId,setting){
    var url='app/configurationrecord?appId=' + appId;
    var configurationTreeNodes=[];
    getAjax(url,function(data){
        var meuLists=[];
        if(data.code===0){
            var datas=data.rows.rel;
            datas.forEach(function(item){
                var clientNode={
                    "name":item.clientId,
                    "open":true,
                    isParent:true,
                    "children":[],
                    "fullName":item.clientId
                };
                var allContainers=item.containers;
                allContainers.forEach(function(container){
                    var containerName=container.containerName;
                    var fullName=deepClone(container);
                    delete fullName.meus;
                    fullName=JSON.stringify(fullName);
                    var containerNode={
                        "name":containerName,
                        "open":true,
                        isParent:true,
                        "children":[],
                        "fullName":fullName
                    };
                    var allMeus=container.meus;
                    allMeus.forEach(function(meu){
                     meuLists.push(meu);
                     var meuDetail=JSON.stringify(meu);
                     var meuNode={
                         "name":meu.meuName,
                         "fullName":meuDetail
                     };
                        containerNode.children.push(meuNode);

                    });
                    clientNode.children.push(containerNode);
                });
                configurationTreeNodes.push(clientNode);
            });
            $.fn.zTree.init($("#configurationTree"), setting,configurationTreeNodes);
        }
        if(meuLists.length>0){
            var mappingTable=$('<table class="table table-border">');
            var thead=$('<thead>');
            var thead_tr='<tr><th width="240px">updateMeu</th><th>meuId</th><th>meuName</th><th>meuType</th><th width="200px">updateProgress</th></tr>';
            thead.append(thead_tr);
            mappingTable.append(thead);
            var tbody=$('<tbody>');
            var tbodyContent='';
            meuLists.forEach(function(meu){
                var meuId=meu.meuId?meu.meuId:null;
                var meuIdStr=simpleId(meuId);
                var meuName=meu.meuName?meu.meuName:'-';
                var meuType=meu.meuType?meu.meuType:'-';
                var tr='<tr><td><form class="updateMeu" enctype="multipart/form-data"><button>Update</button><input type="text" class="updateText" readonly="readonly"><input type="file" name="meu" class="updateFile"/><input type="hidden" name="meuId" class="meuId" value="'+meuId+'"/></form></td><td>'+meuIdStr+'</td><td>'+meuName+'</td><td>'+meuType+'</td><td></td></tr>';
                tbodyContent+=tr;
            });
            tbody.append(tbodyContent);
            mappingTable.append(tbody);
            $('.updateMeus').html(mappingTable);
        }
    },function(res){
        console.log(res);
    });
}

function initUpdateMeu(updateObj){
    $('<input type="file" name="meu" class="updateFile"/>').appendTo(updateObj["form"]);
    updateObj["btn"].css('background','#61619d');
}

function updateMeuProgress(updateObj){
    var timer={
        interval:null,
        timeout:null
    };

    timekeeper(timer,function(){
        initUpdateMeu(updateObj);
        updateObj["box"].html('<span class="text-danger">update failed!<span>');
    },function(){
        getMeuProgress(updateObj,timer);
    });
}

function getMeuProgress(updateObj,intervalTimer,outTimer){
    var url='deployment/meu/progress?meuId=' + updateObj["id"];
    getAjax(url,function(data){
        var record=data.rows;
        var pro=record.progress;
        var progress='<div class="progress progress-striped progressbox"><div class="progress-bar progress-bar-success" style="width: ' + pro + '%"><span>' + pro + '%</span></div></div>';
        updateObj["box"].html(progress);
        if(pro===100){
            clearTimer(intervalTimer,outTimer);
            updateObj["text"].val('');
            initUpdateMeu(updateObj);
            setTimeout(function(){
                updateObj["box"].html('<span class="text-danger">update Success!<span>');
            },500)
        }else if(pro===-1){
            clearTimer(intervalTimer,outTimer);
            initUpdateMeu(updateObj);
            setTimeout(function(){
                updateObj["box"].html('<span class="text-danger">update failed!<span>')
            },500)
        }else{
            clearOutTimer(outTimer);
            outTimer=setTimeout(function(){
                getMeuProgress(updateObj,intervalTimer,outTimer);
            },1000)
        }
    },function(res){
        console.log(res);
    })
}

function clearTimer(intervalTimer,outTimer){
    clearOutTimer(outTimer);
    clearInterTimer(intervalTimer);
}

function updateMeuSubmit(updateObj){
    var updateMeuUrl='deployment/meu';
    updateObj["form"].ajaxSubmit({
        type: "put",
        dataType: "json",
        url: serverIp + updateMeuUrl,
        success:function(data){
            if(data.code===0){
                updateObj["file"].remove();
                updateObj["btn"].css('background','#ddd');
                updateMeuProgress(updateObj);
            }else{
                updateMeuError(updateObj);
            }
        },
        error:function(data){
            updateMeuError(updateObj);
        }
    })
}

function updateMeuError(updateObj){
    updateObj["file"].remove();
    initUpdateMeu(updateObj);
    updateObj["box"].html('<span class="text-danger">update failed!<span>');
}

function abortAjax(){
    if(appListConfig.deleteAjax){
        appListConfig.deleteAjax.abort();
        if(appListConfig.progressAjax){
            appListConfig.progressAjax.abort();
        }
    }
}