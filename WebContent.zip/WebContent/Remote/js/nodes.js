var config = getConfig();
var serverIp = config.serverIp;
var ipReg=/^((?:(?:25[0-5]|2[0-4]\d|((1\d{2})|([1-9]?\d)))\.){3}(?:25[0-5]|2[0-4]\d|((1\d{2})|([1-9]?\d))))$/;

$(function(){
    var clientObj={
        clientSaveAjax:null,
        saveClientTimer:null
    };
    var nodeConfig=getNodeConfig();
    var nodeTable = TableInit();
    nodeTable(nodeConfig.columns,nodeConfig.url,nodeConfig.qp);

    $('#btn_query').click(function(){
        $('#tb_table').bootstrapTable('refresh',{url:nodeConfig.url})
    });

    $('.nodeTable').off('click','tbody tr').on('click','tbody tr',showClientMsg);

    // $('.new').click(function(){
    //     $(".nodes").addClass('hide');
    //     $('.newnode').removeClass('hide');
    //     $('.newinput input').val('');
    //     $('.newinput .info-prompt').hide();
    // });

    $('#txt_search_status').multiselect({
        buttonWidth:'100%',
        maxHeight:200,
        includeSelectAllOption:false,
        enableFiltering:false,
        selectedClass: 'active-select',
        dropRight: true
    });

    (function(){
        var flag=false;
        $('#seePassword').click(function(){
            $(this).toggleClass('glyphicon-eye-close');
            flag=!flag;
            if(flag){
                $('.password').attr('type', 'text');
            }else{
                $('.password').attr('type', 'password');
            }
        })
    })();

    $('.ip').blur(function(){
        var ip = $(this).val();
        if(!ip) {
            $('.ip-prompt span').html('Please enter IP information');
            $('.ip-prompt').show();
            return;
        }
        if(ip&&!ipReg.test(ip)) {
            $('.ip-prompt span').html('IP format is not correct');
            $('.ip-prompt').show();
            return;
        } else {
            $('.ip-prompt').hide();
            return;
        }
    });

    $('.name').keyup(function() {
        var name = $(this).val();
        if(name !== '') {
            $('.username-prompt').hide();
        }
    });

    $('.password').keyup(function() {
        var password = $(this).val();
        if(password !== '') {
            $('.password-prompt').hide();
        }
    });

    $('.cancel').click(function() {
        $(".newnode").addClass('hide');
        $(".nodes").removeClass('hide');
    });

    $('#save').click(function(){
        var ip = $('.newinput .ip').val(),
            name = $('.newinput .name').val(),
            password = $('.newinput .password').val();
        if(!ip){
            $('.ip-prompt span').html('Please enter IP information');
            $('.ip-prompt').show();
            return;
        }
        if(ip&&!ipReg.test(ip)){
            $('.ip-prompt span').html('IP format is not correct');
            $('.ip-prompt').show();
            return;
        }

        if(!name) {
            $('.username-prompt').show();
            return;
        }
        if(!password) {
            $('.password-prompt').show();
            return;
        }
        $('#loadingbg').show();
        var time=new Date();
        var duration=2*60*1000;
        clientObj.saveClientTimer=setInterval(function(){
            var currentTime=new Date();
            if(currentTime-time>=duration){
                $('#loadingbg').hide();
                clearInterTimer(nodeTimer);
                if(clientObj.clientSaveAjax){
                    clientObj.clientSaveAjax.abort();
                }
                swal("Error~","create node failed", "error");
            }
        },5000);
        var url='client?ip='+ip+'&userName='+name+'&password='+password;
        clientObj.clientSaveAjax=postTextAjax(url,function(data){
            if(data.code===0){
                clearInterTimer(clientObj.saveClientTimer);
                $('#loadingbg').hide();
                swal("Good~", data.message + " !", "success");
                $('#tb_table').bootstrapTable('refresh',{
                    url:nodeConfig.url
                });
                $('.newnode').addClass('hide');
                $('.nodes').removeClass('hide');
            }else{
                clearInterTimer(clientObj.saveClientTimer);
                $('#loadingbg').hide();
                swal("Error~", data.message, "error");
            }
        },function(res){
            console.log(res);
            clearInterTimer(clientObj.saveClientTimer);
            $('#loadingbg').hide();
            swal("Error~", res.message, "error");
        })

    });

    $('#environment-lists').click(function() {
        clearInterTimer(clientObj.saveClientTimer);
        if(clientObj.clientSaveAjax){
            clientObj.clientSaveAjax.abort();
        }
        showRight('nodes');
    });

    $('#nodes').click( function() {
        clearInterTimer(clientObj.saveClientTimer);
        if(clientObj.clientSaveAjax){
            clientObj.clientSaveAjax.abort();
        }
        showRight('nodes');
    });

    $('#navParent li').click(function(){
        clearInterTimer(clientObj.saveClientTimer);
        if(clientObj.clientSaveAjax){
            clientObj.clientSaveAjax.abort();
        }
    })
});

function getNodeConfig(){
    var columns=[{
            radio: true
        },
        {
            field: 'hostname',
            title: 'HostName'
        },{
            field: 'network.ip',
            title: 'IP'
        },{
            field: 'kernel.os',
            title: 'OS'
        },{
            field: 'status',
            title: 'Status',
            formatter: function(value, row, index) {
                return statusEvents(value, row, index);
            }
        },{
            field: 'operation',
            title: 'CPU Usage',
            formatter: function(value, row, index) {
                return cpuEvents(value, row, index);
            }
        },{
            field: 'operation',
            title: 'Memory Usage',
            formatter: function(value, row, index) {
                return memoryEvents(value, row, index);
            }
        },{
            field: 'operation',
            title: 'Disk Usage',
            formatter: function(value, row, index) {
                return diskEvents(value, row, index);
            }
        }];
    var url=serverIp+'environment';
    var queryParams=function(params){
        var num=(params.offset/params.limit)+1;
        var temp={
            pageSize:params.limit,
            pageNumber:num,
            hostname:$('#txt_search_hostname').val().trim(),
            ip:$('#txt_search_ip').val().trim(),
            status:$('#txt_search_status').val().trim()
        };
        deleteObjKey(temp);
        return temp;
    };
    return {
      columns:columns,
        url:url,
        qp:queryParams
    }
}

function statusEvents(value,row,index){
    var str='';
    if(value==='available'){
        str='<img src="../../common/img/green.png" class="img-rounded" >';
    }else{
        str='<img src="../../common/img/gray.png" class="img-rounded" >';
    }
    return str;
}

function cpuEvents(value,row,index){
    var cpuUsage=row.cpu.cpuUsage;
    var str='<div class="progress progress-striped active"><div class="progress-bar progress-bar-success" style="width:' + cpuUsage + '"><span style="color:#444c5d">' + cpuUsage + '</span></div></div>';
    return str;
}

function memoryEvents(value,row,index){
    var memoryTotal = row.memory.memoryTotal,
        memoryUsed = row.memory.memoryUsed,
        memoryUsage = row.memory.memoryUsage;
    var str='<div class="progress progress-striped active"><div class="progress-bar progress-bar-success" style="width:' + memoryUsage + '"><span style="color:#444c5d">' + memoryUsed + 'GB(' + memoryTotal + 'GB)</span></div></div>';
    return str;
}

function diskEvents(value,row,index){
    var diskTotal = row.fileSystem.diskTotal,
        diskUsed = row.fileSystem.diskUsed,
        diskUsage = row.fileSystem.diskUsage;
    var str='<div class="progress progress-striped active"><div class="progress-bar progress-bar-success" style="width:' + diskUsage + '"><span style="color:#444c5d">' + diskUsed + 'GB(' + diskTotal + 'GB)</span></div></div>';
    return str;
}

function showClientMsg(){
    var currentData=$('#tb_table').bootstrapTable('getSelections')[0];
    $('.modal-content-inner').empty();
    var nodeId=currentData.id;
    var msgdiv = $("<div class='msgContent'></div>");
    $('.modal-content-inner').append(msgdiv);
    $('.nodeTable tbody tr').removeAttr("data-toggle").removeAttr("data-target");
    $(this).attr({
        "data-toggle": "modal",
        "data-target": "#nodeModal"
    });
    var url='client?id=' + nodeId;
    getAjax(url,function(res){
        var data=res.rows[0];
        var div="",
            lab='',
            span='';
        for(var j in data) {
            if(typeof(data[j]) === "object") {
                div = $('<div class="client_box"></div>');
                if(j === 'kernel') {
                    var divStr = "";
                    divStr += '<p><label>OS:&nbsp</label><span>' + data[j]["os"] + '</span></p><p><label>OS &nbsp; Release:&nbsp</label><span>' + data[j]["osRelease"] + '</span></p><p><label>Platform:&nbsp</label><span>' + data[j]["platform"] + '</span></p><p><label>Platform &nbsp; Version:&nbsp</label><span>' + data[j]["platformVersion"] + '</span></p>';
                    div.html(divStr);
                    div.appendTo(msgdiv);
                }
                if(j ==='network'){
                    var divStr = "";
                    divStr += '<p><label>IP:&nbsp</label><span>' + data[j]["ip"] + '</span></p><p><label>Mac:&nbsp</label><span>'+data[j]["mac"]+ '</span></p><p><label>IPv6 &nbsp; Address:&nbsp</label><span>' + data[j]["ip6address"] + '</span></p>';
                    div.html(divStr);
                    div.appendTo(msgdiv);
                }
                if(j==='cpu') {
                    var divStr = "";
                    divStr += '<p><label>CPU &nbsp; Cores:&nbsp</label><span>' + data[j]["cpuCores"] + '</span></p><p><label>CPU &nbsp; Usage:&nbsp</label><span>' + data[j]["cpuUsage"] + '</span></p>';
                    div.html(divStr);
                    div.appendTo(msgdiv);
                }
                if(j==='memory') {
                    var divStr = "";
                    divStr += '<p><label>Memory &nbsp; Total:&nbsp</label><span>' + data[j]["memoryTotal"] + '&nbsp;GB</span></p><p><label>Memory &nbsp; Used:&nbsp</label><span>' + data[j]["memoryUsed"] + '&nbsp;GB</span></p><p><label>Memory &nbsp; Usage:&nbsp</label><span>' + data[j]["memoryUsage"] + '</span></p>';
                    div.html(divStr);
                    div.appendTo(msgdiv);
                }
                if(j==='fileSystem') {
                    var divStr = "";
                    divStr += '<p><label>Disk &nbsp; Total:&nbsp</label><span>' + data[j]["diskTotal"] + '&nbsp;GB</span></p><p><label>Disk &nbsp; Used:&nbsp;</label><span>' + data[j]["diskUsed"] + '&nbsp;GB</span></p><p><label>Disk &nbsp; Usage:&nbsp</label><span>' + data[j]["diskUsage"] + '</span></p>';
                    div.html(divStr);
                    div.appendTo(msgdiv);
                }
            } else if(typeof(data[j]) ==="string") {
                if(j==="id") {
                    lab = "<label>ID:&nbsp</label>";
                    span = "<span>" + data['id'] + "</span>";
                    $("<p style='padding-left:5px;'>" + lab + span + "</p>").appendTo(msgdiv);
                }
                if(j==='status') {
                    lab = "<label>Status:&nbsp</label>";
                    span = "<span>" + data['status'] + "</span>";
                    $("<p style='padding-left:5px;'>" + lab + span + "</p>").appendTo(msgdiv);
                }
                if(j==='hostname') {
                    lab = "<label>Name:&nbsp</label>";
                    span = "<span>" + data['hostname'] + "</span>";
                    $("<p style='padding-left:5px;'>" + lab + span + "</p>").appendTo(msgdiv);
                }
            }
        }
    },function(res){
        console.log(res);
    })
}