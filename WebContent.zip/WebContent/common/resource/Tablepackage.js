var config =getConfig();
var serverUrl=config.serverUrl;
function TableInit(el,detailView,toolbar,sucf,errf){
    detailView=detailView||false;
    el=el||'#tb_table';
    toolbar=toolbar||'#toolbar';
    return function(columns,url,queryParams,sortName,order){
        const resHandle=function(res){
            if(res){
                if(url.indexOf('log/setting/')!==-1){
                    var newRes = {};
                    for(var key in res){
                        if(key==='rows'){
                            if(res[key]["container"]){
                                newRes[key]=res[key]["container"]["logLevelInfos"];
                            }else if(res[key]["app"]){
                                newRes[key]=res[key]["app"]["logLevelInfos"];
                            }
                            newRes["data"]=res[key];
                        }else{
                            newRes[key]=res[key];
                        }
                    }
                    return newRes;
                }else if(url.indexOf('cloud/meu?group=')!==-1){
                    var newRes = {};
                    for(var key in res){
                        if(key==='rows'){
                            var meuData=res[key][0];
                            if(meuData.license){
                                var licenseArr=meuData.license.licenseList;
                                licenseArr=licenseArr.map(function(license){
                                    var newLicense={};
                                    for(var a in license){
                                        newLicense[a]=license[a];
                                    }
                                    newLicense["group"]=meuData.group;
                                    newLicense["name"]=meuData.name;
                                    newLicense["version"]=meuData.version;
                                    newLicense["type"]=meuData.type;
                                    return newLicense;

                                });
                                newRes[key]=licenseArr;
                            }else{
                                newRes[key]=[];
                            }

                            newRes["data"]=res[key];
                        }else{
                            newRes[key]=res[key];
                        }
                    }
                    return newRes;
                }else{
                    return res;
                }
            }
        };
        $(el).bootstrapTable({
            url:url,
            method:'get',
            toolbar:toolbar,
            striped:true,
            cache:false,
            pagination:true,
            sortable:true,
            sortName:sortName,
            sortOrder:order||'asc',
            queryParams:queryParams,
            sidePagination:"server",
            pageNumber:1,
            pageSize:10,
            pageList:[5,10,25,50,100],
            search:false,
            strictSearch:true,
            showColumns:true,
            showRefresh:true,
            minimumCountColumns:1,
            clickToSelect:true,
            uniqueId:'ID',
            showToggle:false,
            cardView:false,
            columns:columns,
            detailView:detailView,
            responseHandler:resHandle,
            onLoadSuccess:function(data){
                if(sucf&&typeof(sucf)==='function'){
                    sucf(data);
                }
                var tableHeight=$(el).height();
                if(tableHeight>500){
                    $('.fixed-table-container').height(450);
                }else if(tableHeight<200){
                    $('.fixed-table-container').height(350);
                }
            },
            onLoadError:function(status,res){
                console.log(res);
                var rt=JSON.parse(res.responseText);
                if(errf&&typeof(errf)==='function'){
                    errf(status,rt);
                    return;
                }
                if(status===401){
                    if(rt.code===4003||rt.code===4001){
                        window.location=serverUrl+'/login.html';
                        return;
                    }
                }else if(status===403){
                    if(rt.code===-1){
                        swal("Error~", rt.message + " !", "error");
                        return;
                    }
                }
                swal("Error~", rt.message + " !", "error");
            },
            onExpandRow:function(index,row,$detail){
                var newData=[];
                row.epg.forEach(function(epg){
                    newData.push({"epg":epg,"meu":epg.meu});
                });
                var table=$detail.html('<table></table>').find('table');
                table.bootstrapTable({
                    columns:[{
                        field: 'epg',
                        title: 'EPG',
                        formatter: function(value, row, index) {
                            var name=value.name||'-';
                            return '<div class="appEpg" data-toggle="popover" data-placement="right" data-trigger="enter" data_id="'+value.id+'">'+name+'</div>';
                        }
                    },{
                        field: 'meu',
                        title: 'MEU',
                        formatter: function(meu, row, index) {
                            return showEpgMeu(meu, row, index);
                        }
                    }],
                    data:newData
                })

            }

        })
    }
}

function showEpgMeu(value,row,index){
    var temp='';
    if(value.length>0){
        value.forEach(function(item){
            temp+='<div class="appMeu" data-toggle="popover" data-placement="left" data-trigger="enter"  data_title="'+item.id+'" data_id="'+item.id+item.containerId+'" data_epgId="'+row.epg.id+'">' + item.name + '</div>';
        })
    }
    return temp;
}

function resetValue(value){
    if(!value){
        return null;
    }else{
        return value;
    }

}

