test('(Component) <%= pascalEntityName %> match snapshot', () => {

})
