import <%= pascalEntityName %> from './<%= pascalEntityName %>'

export default <%= pascalEntityName %>
