import Confirm from './Confirm'
export default Confirm
