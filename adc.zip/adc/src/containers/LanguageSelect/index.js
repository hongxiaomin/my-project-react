import LanguageSelect from './LanguageSelect'
export default LanguageSelect
