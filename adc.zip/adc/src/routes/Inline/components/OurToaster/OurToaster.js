import { Position, Toaster } from '@blueprintjs/core'

export const OurToaster = Toaster.create({
  className: '',
  position: Position.BOTTOM_RIGHT,
})
export default OurToaster
