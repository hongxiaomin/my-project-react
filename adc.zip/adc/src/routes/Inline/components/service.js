import React from 'react'

const service = () => <div>Service</div>

export default service
