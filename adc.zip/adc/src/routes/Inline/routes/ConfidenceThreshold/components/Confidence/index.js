import Confidence from './Confidence'

export default Confidence
