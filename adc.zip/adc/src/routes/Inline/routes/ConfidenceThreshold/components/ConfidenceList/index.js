import ConfidenceList from './ConfidenceList'

export default ConfidenceList
