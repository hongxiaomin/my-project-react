import ServiceDetailDialog from './ServiceDetailDialog'

export default ServiceDetailDialog
