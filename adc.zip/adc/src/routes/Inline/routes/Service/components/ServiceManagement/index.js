import ServiceManagement from './ServiceManagement'

export default ServiceManagement
