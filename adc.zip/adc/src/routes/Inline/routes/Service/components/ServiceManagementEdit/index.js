import ServiceManagementEdit from './ServiceManagementEdit'

export default ServiceManagementEdit
