import ServiceManagementListContainer from './ServiceManagementList'

export default ServiceManagementListContainer
