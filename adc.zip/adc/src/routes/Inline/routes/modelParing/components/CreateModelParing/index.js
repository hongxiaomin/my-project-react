import CreateModelParing from './CreateModelParing'

export default CreateModelParing
