import EditDialog from './EditDialog'

export default EditDialog
