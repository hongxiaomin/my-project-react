import ModelParing from './ModelParing'

export default ModelParing
