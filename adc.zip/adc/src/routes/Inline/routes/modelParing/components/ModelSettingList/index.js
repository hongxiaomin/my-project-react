import ModelSettingList from './ModelSettingList'

export default ModelSettingList
