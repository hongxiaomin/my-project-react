import Languages from './components/Languages'

// Sync route definition
export default {
  path: 'languages',
  component: Languages,
}
