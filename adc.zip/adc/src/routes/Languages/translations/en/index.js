export { default } from './en.json'
