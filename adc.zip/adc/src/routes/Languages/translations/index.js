import zh from './zh'
import en from './en'

export { zh, en }
