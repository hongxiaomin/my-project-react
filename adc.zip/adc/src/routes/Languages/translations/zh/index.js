export { default } from './zh.json'
