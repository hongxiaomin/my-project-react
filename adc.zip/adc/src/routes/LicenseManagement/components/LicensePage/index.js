import LicensePage from './LicensePage'

export default LicensePage
