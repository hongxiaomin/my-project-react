import CreateUser from './Create'
import EditUser from './Edit'

export default { CreateUser, EditUser }
