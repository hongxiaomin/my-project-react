import LicenseManagement from './License'

export default LicenseManagement
