import LicenseCard from './LicenseCard'

export default LicenseCard
