import Model from './Model'

export default Model
