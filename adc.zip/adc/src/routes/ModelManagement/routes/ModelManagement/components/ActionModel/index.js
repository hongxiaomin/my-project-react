import ActionModel from './ActionModel'

export default ActionModel
