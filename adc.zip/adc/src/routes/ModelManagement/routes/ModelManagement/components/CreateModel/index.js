import CreateModel from './CreateModel'

export default CreateModel
