import ModelDetail from './ModelDetail'

export default ModelDetail
