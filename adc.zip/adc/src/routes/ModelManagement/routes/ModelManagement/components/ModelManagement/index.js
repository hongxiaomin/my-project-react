import ModelManagement from './ModelManagement'

export default ModelManagement
