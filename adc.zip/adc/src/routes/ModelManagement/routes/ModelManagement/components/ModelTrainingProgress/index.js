import ModelTrainingProgress from './ModelTrainingProgress'

export default ModelTrainingProgress
