import TestResultCopy from './TestResultCopy'
export default TestResultCopy
