import Train from './Train'

export default Train
