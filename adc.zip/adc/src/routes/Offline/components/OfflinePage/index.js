import OfflinePage from './OfflinePage'

export default OfflinePage
