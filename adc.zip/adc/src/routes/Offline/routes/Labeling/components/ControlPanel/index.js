import ControlPanelContainer from './ControlPanel'

export default ControlPanelContainer
