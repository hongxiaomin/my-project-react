import DefectCodeContainer from './DefectCode'

export default DefectCodeContainer
