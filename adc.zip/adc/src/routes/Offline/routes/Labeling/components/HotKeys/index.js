import HotKeysContainer from './HotKeys'

export default HotKeysContainer
