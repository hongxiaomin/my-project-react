import ImagePathContainer from './ImagePath'

export default ImagePathContainer
