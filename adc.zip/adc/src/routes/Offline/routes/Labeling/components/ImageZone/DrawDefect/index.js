import DrawDefect from './DrawDefect'
export default DrawDefect
