import LabelingListContainer from './LabeledList'

export default LabelingListContainer
