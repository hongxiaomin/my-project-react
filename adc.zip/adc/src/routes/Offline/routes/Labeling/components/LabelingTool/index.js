import LabelingTool from './LabelingTool'

export default LabelingTool
