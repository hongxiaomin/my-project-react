import LabelingToolExpand from './LabelingToolExpand'
export default LabelingToolExpand
