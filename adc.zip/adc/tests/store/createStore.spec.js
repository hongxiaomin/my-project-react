// import createStore from 'store/createStore'
// import isEmpty from 'lodash.isempty'

// describe('(Store) createStore', () => {
//   // let store

//   // beforeEach(() => {
//   //   store = createStore()
//   // })

//   // it('should have an empty asyncReducers object', () => {
//   //   expect(typeof store.asyncReducers).toBe('object')
//   //   expect(isEmpty(store.asyncReducers)).toBeTruthy()
//   // })

//   // describe('(Location)', () => {
//   //   it('store should be initialized with Location state', () => {
//   //     const location = {
//   //       pathname: '/echo',
//   //     }
//   //     store.dispatch({
//   //       type: 'LOCATION_CHANGE',
//   //       payload: location,
//   //     })
//   //     expect(store.getState().location).toEqual(location)
//   //   })
//   // })
// })
