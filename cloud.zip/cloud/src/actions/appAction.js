import {createAction} from 'redux-actions';
import {
    SET_APP_LIST,
    SET_SELECTED_PROJECT_APP,
    SET_IS_APP_EDIT,
    EDIT_PROJECT_APP,
    ADD_PROJECT_APP,
    DELETE_PROJECT_APP,
} from '../constants/actionTypes';

export const setAppList = createAction(SET_APP_LIST);
export const setSelecteProjectdApp = createAction(SET_SELECTED_PROJECT_APP);
export const setIsAppEdit = createAction(SET_IS_APP_EDIT);
// export const setIsAppEdit = () => { console.log('sdf') }
export const editProjectApp = createAction(EDIT_PROJECT_APP);
export const addProjectApp = createAction(ADD_PROJECT_APP);
export const deleteProjectApp = createAction(DELETE_PROJECT_APP);