import {createAction} from 'redux-actions';
import {
    SET_PROJECT_EPG_LIST,
    ADD_PROJECT_EPG,
    DELETE_PROJECT_EPG,
    SET_NEW_EPG,
    SET_SELECTED_EPG,
    SET_IS_EDIT,
    EDIT_PROJECT_EPG
} from '../constants/actionTypes';

export const setProjectEpg = createAction(SET_PROJECT_EPG_LIST);
export const addProjectEpg = createAction(ADD_PROJECT_EPG);
export const deleteProjectEpg = createAction(DELETE_PROJECT_EPG);
export const setNewEpg = createAction(SET_NEW_EPG);
export const setSelectedEpg=createAction(SET_SELECTED_EPG);
export const setIsEdit=createAction(SET_IS_EDIT);
export const editProjectEpg=createAction(EDIT_PROJECT_EPG);