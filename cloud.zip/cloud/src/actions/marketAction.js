import {createAction} from 'redux-actions';
import {
    SET_MEU_LIST,
    SET_COMPONENT_LIST,
    SET_PROJECT_MEU_LIST,
    ADD_MEU_TO_PROJECT,
    DELETE_PROJECT_MEU,
    UPDATE_PROJECT_MEU
} from '../constants/actionTypes';

export const setMeuList = createAction(SET_MEU_LIST);
export const setComponentList = createAction(SET_COMPONENT_LIST);
export const setProjectMeuList = createAction(SET_PROJECT_MEU_LIST);
export const addMeuToProject = createAction(ADD_MEU_TO_PROJECT);
export const deleteProjectMeu = createAction(DELETE_PROJECT_MEU);
export const updateProjectMeu = createAction(UPDATE_PROJECT_MEU);