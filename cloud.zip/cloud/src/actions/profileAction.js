import {createAction} from 'redux-actions';
import {
    SET_APP_PROFILE_LIST,
    SET_ENV_PROFILE_LIST,
    SET_SELECTED_ENV,
    SET_SELECTED_APP,
    ADD_ENV_PROFILE,
    ADD_APP_PROFILE,
    DELETE_ENV_PROFILE,
    DELETE_APP_PROFILE,
    EDIT_ENV_PROFILE,
    EDIT_PROJECT_EPG,
    SET_IS_ENVIRONMENT_EDIT,
    SET_IS_APP_PROFILE_EDIT,
    UPDATE_APP_PROFILE,
    UPDATE_ENV_PROFILE,
} from '../constants/actionTypes';

export const setEnvProfileList = createAction(SET_ENV_PROFILE_LIST);
export const setAppProfileList = createAction(SET_APP_PROFILE_LIST);
export const setSelectedEnv = createAction(SET_SELECTED_ENV);
export const setSelectedApp = createAction(SET_SELECTED_APP);
export const setIsEnvEdit = createAction(SET_IS_ENVIRONMENT_EDIT);
export const setIsAppProfileEdit = createAction(SET_IS_APP_PROFILE_EDIT);
export const addEnvProfile = createAction(ADD_ENV_PROFILE);
export const deleteEnvProfile = createAction(DELETE_ENV_PROFILE);
export const deleteAppProfile = createAction(DELETE_APP_PROFILE);
export const addAppProfile = createAction(ADD_APP_PROFILE);
export const updateAppProfile = createAction(UPDATE_APP_PROFILE);
export const updateEnvProfile = createAction(UPDATE_ENV_PROFILE);