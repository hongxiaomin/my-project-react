import {createAction} from 'redux-actions';
import {
    GET_PROJECT,
    SET_SELECTED_PROJECT,
    ADD_PROJECT,
    DELETE_PROJECT,
    UPDATE_PROJECT,

} from '../constants/actionTypes';
import { create } from 'domain';

export const getProject = createAction(GET_PROJECT);
export const setSelectedProject = createAction(SET_SELECTED_PROJECT);
export const addProject = createAction(ADD_PROJECT);
export const deleteProject = createAction(DELETE_PROJECT);
export const updateProject=createAction(UPDATE_PROJECT);

