import PropTypes from 'prop-types';

export const BREADMAP = 'breadMap';
export const defaultProps = {
    [BREADMAP]:[]
}

export const propTypes = {
    [BREADMAP]:PropTypes.array
};