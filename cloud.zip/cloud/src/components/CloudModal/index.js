import React from 'react';
import {Modal,Button} from 'antd';
import {
    TITLE,
    VISIBLE,
    ONOK,
    ONCANCEL,
    CHILDREN,
    defaultProps,
    propTypes,
    WIDTH
} from './props';
import './style.less';

const CloudModal = (props) => {
    return (
        <Modal 
            title={props[TITLE]} 
            visible={props[VISIBLE]} 
            onOk={props[ONOK]} 
            onCancel={props[ONCANCEL]} 
            width={props[WIDTH]}
            destroyOnClose={true}
        >
            {typeof props[CHILDREN]==='function'?props[CHILDREN]():props[CHILDREN]}
        </Modal>
    )
}

CloudModal.defaultProps=defaultProps;
CloudModal.propTypes=propTypes;
export default CloudModal;