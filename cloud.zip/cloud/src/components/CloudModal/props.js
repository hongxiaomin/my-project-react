import PropTypes from 'prop-types';
export const TITLE = 'title';
export const VISIBLE ='visible';
export const ONOK = 'onOk';
export const ONCANCEL = 'onCancel';
export const CHILDREN = 'children';
export const WIDTH = 'width';

export const defaultProps = {
    [TITLE]:'',
    [VISIBLE]:false,
    [ONOK]:(response) => response,
    [ONCANCEL]:(response) => response,
    [CHILDREN]:null,
    [WIDTH]:'520px'
};

export const propTypes = {
    [TITLE]:PropTypes.string,
    [VISIBLE]:PropTypes.bool,
    [ONOK]:PropTypes.func,
    [ONCANCEL]:PropTypes.func,
    [CHILDREN]:PropTypes.oneOfType([PropTypes.node,PropTypes.func]),
    [WIDTH]:PropTypes.string
};