import React,{Component} from 'react';
import {Button,Upload,Icon} from 'antd';

class CloudUpload extends Component{
    constructor(props){
        super(props);
        this.state={
            fileList:[],
        }
    }
    render(){
        const uploadProps = {
            onRemove:(file)=>{
              this.setState(({ fileList }) => {
                const index = fileList.indexOf(file);
                const newFileList = fileList.slice();
                newFileList.splice(index, 1);
                return {
                  fileList: newFileList,
                };
              });
            },
            beforeUpload:(file)=>{
              
              this.setState(({ fileList }) => ({
                fileList: [...fileList, file],
              }));
              return false;
            },
            fileList: this.state.fileList,
        };
        return (
            <Upload {...uploadProps}>
                <Button type="primary" shape="circle" size="small">
                    <Icon type="upload"/>
                </Button>
            </Upload>
        )
    }
}
export default CloudUpload;