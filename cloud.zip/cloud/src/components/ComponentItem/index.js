import React from 'react';
import {Button,Icon} from 'antd';
import './style.less';

const ComponentItem = (props)=>{
    let {data,handleComponentClick,handleAddComponentToProject}=props;
    return (
        <div className="meu_item" onClick={handleComponentClick}>
            <h4>
                <p>
                {data.componentName}
                </p>
            </h4>
            <div className="meu_bot">
                <div className="meu_price pull-left">
                    ¥
                    <em>0.1</em>
                    <em>/</em>
                    <em>Month</em>
                </div>
                <div className="pull-right meu_price_btn">
                    <Button type="primary" shape="circle" icon="plus" onClick={handleAddComponentToProject}/>
                </div>
            </div>
        </div>
    )
}

export default ComponentItem