import React,{Component} from 'react';
import {Input,Select,Button,Icon,message} from 'antd';
import './style.less';

const Option = Select.Option;

class InputParam extends Component{
    constructor(props){
        super(props);
        let paramList = [...this.props.defaultParam];
        this.state={
            type:'',
            paramList,
            inputVariable:''
        }
    }
    changeVariale=(value)=>{
        let type='';
        if(this.props.inputParamList.length>0){
            let currentInput=this.props.inputParamList.filter(item=>{
                return item.value===value
            })
            if(currentInput.length>0){
                type=currentInput[0].type;
            }
        }
        this.setState({
            inputVariable:value,
            type
        })
    }
    addParam=()=>{
        if(!this.state.inputVariable){
            message.error('Input Available Variable!');
            return;
        }
        let paramList=[...this.state.paramList];
        paramList.push(`\$\{${this.state.inputVariable}\}`);
        this.setState({
            paramList
        })
    }
    deleteParam=(index)=>()=>{
        let paramList=[...this.state.paramList];
        paramList.splice(index,1);
        this.setState({
            paramList:[].concat(paramList)
        })
    }

    handleCancelParam=()=>{
        this.props.handleShowInputParam();
    }
    handleSureParam=()=>{
        this.props.handleSetInputParam(this.state.paramList);
        this.props.handleShowInputParam();
    }
    changeInputParam=(data,index)=>(e)=>{
        let value = e.target.value;
        let paramList=[...this.state.paramList];
        paramList = paramList.map((item,key)=>{
            if((item===data)&&(key===index)){
                return value;
            }else{
                return item;
            }
        })
       this.setState({
           paramList
       })
    }
    render(){
        const {inputParamList}=this.props;
        let inputData=[];
        if(inputParamList){
            inputData=[...inputParamList];
        }
        return (
            <div className="input_param_box">
                <h4>Input Parameter List</h4>
                
                <div className="input_param_content">
                    <div className="input_param_item">
                        <label>Variable:</label>
                        <Select
                            mode="combobox"
                            defaultValue=""
                            value={this.state.inputVariable}
                            onChange={this.changeVariale}
                            style={{ width: 260 }}
                            >
                            {
                                inputData.map((item,index)=>{
                                    return <Option 
                                                key={item} 
                                                value={item.value}
                                            >
                                                {item.value}
                                            </Option>
                                })
                            }
                        </Select>
                    </div>

                    <div className="input_param_item">
                        <label>Type:</label>
                        <Input value={this.state.type} disabled style={{ width: 260 }}/>
                    </div>
                    <div className="input_param_list">
                        <div className="param_btn">
                            <label>InputParameter List:</label>
                            <Button type="primary" onClick={this.addParam}>Add</Button>
                        </div>
                        <div className="input_param_list_content">
                            {
                                this.state.paramList.map((item,index)=>{
                                    return <div key={index} className="input_param_item">
                                                <Input defaultValue={item} style={{ width: 200 }} onChange={this.changeInputParam(item,index)}/>
                                                <Icon type="close" onClick={this.deleteParam(index)}/>
                                            </div>
                                })
                            }
                        </div>
                    </div>
                </div>
                <div className="btn_group">
                    <Button type="primary" onClick={this.handleSureParam}>OK</Button>
                    <Button onClick={this.handleCancelParam}>Cancel</Button>
                </div>
            </div>
        )
    }
}

export default InputParam;