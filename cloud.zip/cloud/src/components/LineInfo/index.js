import React,{Component} from 'react';
import {Input,Select,Button,message} from 'antd';
import Dragger from 'react-dragger-r';
import { getXmlJsonData } from '../../utils/todoXml';
import InputParam from '../InputParam';
import './style.less';
import { isArray, isObject } from '../../utils/Common';
const Option = Select.Option;
class LineInfo extends Component{
    constructor(props){
        super(props);
        const {targetMeu,selectedLineInfo}=this.props;
        let targetOperations=[];
        if(targetMeu){
            let definition = targetMeu.definition;
            definition=getXmlJsonData(definition);
            let operations = definition.meu.operations;
            if(operations){
                operations=operations.operation;
                if(isArray(operations)){
                    targetOperations=[...operations];
                }else if(isObject(operations)){
                    targetOperations=[operations];
                }
            }
        }
        let mode='';
        let operationId='';
        let condition='';
        let returnValue='';
        let defaultParam=[];
        if(selectedLineInfo){
            mode=selectedLineInfo["mode"]?selectedLineInfo["mode"]:'';
            condition=selectedLineInfo["condition"]?selectedLineInfo["condition"]:'';
            returnValue=selectedLineInfo["return"]?selectedLineInfo["return"]:'';
            operationId=selectedLineInfo["operationId"]?selectedLineInfo["operationId"]:'';
            let inputParam=selectedLineInfo["inputParam"];
            if(inputParam){
                defaultParam=inputParam.split(',');
            }
        }
        this.state=({
            targetOperations,
            mode,
            operationId,
            condition,
            returnValue,
            inputParamVisible:false,
            defaultParam,
            hasReturn:false,
        })
    }
    handleChangeMode=(value)=>{
        this.setState({
            mode:value
        })
    }
    changeOperationId=(value)=>{
        this.setState({
            operationId:value
        })
    }
    changeCondition=(e)=>{
        let value = e.target.value;
        value=value.replace(/</g,'&lt;').replace(/>/g,'&gt;');
        this.setState({
            condition:value
        })
    }
    changeReturn=(e)=>{
        let value=e.target.value;
        let selectedLineInfo=this.props.selectedLineInfo;
        let currentValue=this.props.inputParamList.filter(item=>{
            if(item.from===selectedLineInfo.from&&item.to===selectedLineInfo.to){
                return false;
            }else{
                return item.value===value;
            }
        })
        if(currentValue.length>0){
            message.error(`${value} is existed!`);
            this.setState({
                hasReturn:true
            })
            return;
        }else{
            this.setState({
                hasReturn:false,
                returnValue:value
            })
        }
    }
    handleOK=()=>{
        if(this.state.hasReturn){
            message.error('Input available return!');
            return;
        }else{
            const{mode,operationId,condition,returnValue,defaultParam}=this.state;
            let selectedLineInfo=this.props.selectedLineInfo;
            selectedLineInfo["mode"]=mode;
            selectedLineInfo["operationId"]=operationId;
            selectedLineInfo["condition"]=condition;
            selectedLineInfo["return"]=returnValue;
            selectedLineInfo["inputParam"]=defaultParam.join(',');

            if(returnValue&&!this.state.hasReturn){
                let inputParamList=[...this.props.inputParamList];
                let currentParam = inputParamList.filter(item=>{
                    return (item.from===selectedLineInfo.from)&&(item.to===selectedLineInfo.to)
                });
                if(currentParam.length>0){
                    currentParam=currentParam[0];
                    if(currentParam.value!==returnValue){
                        let myDiagram = this.props.myDiagram;
                        let linkDataArray = myDiagram.model.linkDataArray;
                        myDiagram.model.linkDataArray=linkDataArray.map(item=>{
                            if(item.inputParam){
                                let inputParamArr = item.inputParam.split(',');
                                inputParamArr=inputParamArr.map((param)=>{
                                    let paramArr1 = param.split('{');
                                    let paramArr2 = paramArr1[1].split('}');
                                    let newParam = paramArr2[0];
                                    if(newParam===currentParam.value){
                                        return `${paramArr1[0]}\{${returnValue}\}${paramArr2[1]}`;
                                    }else{
                                        return param;
                                    }
                                })
                                item.inputParam=inputParamArr.join(',');
                            }
                            return item;
                        })
                        currentParam.value=returnValue;
                    }
                }else{
                    let returnType = this.state.targetOperations.filter(item=>{
                        return item["@id"]===operationId;
                    })
                    let type='';
                    if(returnType.length>0){
                        type=returnType[0]["@returnType"];
                    }
                    inputParamList.push({
                        value:returnValue,
                        from:selectedLineInfo.from,
                        to:selectedLineInfo.to,
                        type
                    })
                }
                this.props.setInputParam(inputParamList);
            }
            this.props.setSelectedLine(selectedLineInfo)
            this.props.showLineInfo(false);
        }
    }

    handleCancel=()=>{
        this.props.showLineInfo(false);
    }
    
    handleShowInputParam=()=>{
        this.setState({
            inputParamVisible:!this.state.inputParamVisible
        })
    }
    handleSetInputParam=(value)=>{
        this.setState({
            defaultParam:value
        })
    }
    render(){
        return (
            <div className="line_info_box">
                <h4>Event Properties Information</h4>
                <div className="line_info_content">
                    <div className="line_info_item">
                        <label>mode:</label>
                        <Select defaultValue={this.state.mode} style={{ width: 260 }} onChange={this.handleChangeMode}>
                            <Option value="">&nbsp;&nbsp;</Option>
                            <Option value="invoke">invoke</Option>
                        </Select>
                    </div>
                    <div className="line_info_item">
                        <label>operationId:</label>
                        <Select defaultValue={this.state.operationId} style={{ width: 260 }} onChange={this.changeOperationId}>
                            <Option value="">&nbsp;&nbsp;</Option>
                            {
                                this.state.targetOperations.map((item,index)=>{
                                    return <Option value={item["@id"]} key={index}>{`${item["@methodName"]}-${item["@id"]}`}</Option>
                                })
                            }
                        </Select>
                    </div>

                    <div className="line_info_item">
                        <label>condition:</label>
                        <Input style={{ width: 260 }} defaultValue={this.state.condition} onChange={this.changeCondition}/>
                    </div>
                    <div className="line_info_item">
                        <label>return:</label>
                        <Input style={{ width: 260 }} defaultValue={this.state.returnValue} onChange={this.changeReturn}/>
                    </div>
                    <div className="line_info_item">
                        <label>inputParam:</label>
                        <div className="input_param" onClick={this.handleShowInputParam}>{
                            this.state.defaultParam.map((item,index)=>{
                                return <span key={index}>{item}</span>
                            })
                        }</div>
                    </div>
                </div>
                <div className="btn_group">
                    <Button type="primary" onClick={this.handleOK}>OK</Button>
                    <Button onClick={this.handleCancel}>Cancel</Button>
                </div>
                {
                    this.state.inputParamVisible?
                    <Dragger 
                        style={{
                                zIndex:1000,
                                right:150,
                                top:200,
                                position:'absolute',
                                background:'rgb(245,244,244)',
                                border:'1px solid #000'
                                }}>
                        <InputParam 
                            inputParamList={this.props.inputParamList} 
                            defaultParam={this.state.defaultParam}
                            handleShowInputParam={this.handleShowInputParam}
                            handleSetInputParam={this.handleSetInputParam}
                        />
                    </Dragger>:null
                }
            </div>
        )
    }
}

export default LineInfo;