import React, { Component } from 'react';
import { Input } from 'antd';
import  CloudModal  from '../CloudModal';
import './style.less';

const { TextArea } = Input;

class MeuInfo extends Component {
    constructor(props) {
        super(props);
        this.state = {
            showXml: false,
        }
    }
    handleHideXML = () => {
        this.setState({
            showXml: false
        })
    }
    showXML = () => {
        this.setState({
            showXml: true
        })
    }
    render() {
        const { data,dataType } = this.props;
        return (
            <div className="meu_modal_box">
                <CloudModal
                    title="MEU XML"
                    visible={this.state.showXml}
                    onOk={this.handleHideXML}
                    onCancel={this.handleHideXML}
                    width="860px"
                >
                    <TextArea rows={6} autosize={true} defaultValue={data.definition} />
                </CloudModal>
                <div className="meu_modal">
                    <div className="meuSummary meu_section">
                        <h4>{dataType==="component"?"Component Summary":"MEU Summary"}</h4>
                        <div className="meu_summary_detail detail_box">
                            <p>
                                <label>Name:</label>
                                <span>{dataType==="component"?data.componentName:data.name}</span>
                            </p>
                            <p>
                                <label>Type:</label>
                                <span>{data.type}</span>
                            </p>
                            <p>
                                <label>Language:</label>
                                <span>{data.language}</span>
                            </p>
                            <p>
                                <label>Author:</label>
                                <span>{data.author}</span>
                            </p>
                            <p>
                                <label>Version:</label>
                                <span>{data.version}</span>
                            </p>
                            <p>
                                <label>Create Date:</label>
                                <span>{data.createDate}</span>
                            </p>
                        </div>
                    </div>
                    <div className="meu_section">
                        <h4>{dataType==="component"?"Component Description":"MEU Description"}</h4>
                        <div className="detail_box meu_description_detail">
                            <article>
                                {data.description}
                            </article>
                            <p>
                                {
                                    dataType==="component"?null:<a href="javaScript:;" onClick={this.showXML}>"The xml file of the MEU in the link"</a>
                                }
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default MeuInfo;