import React from 'react';
import {Button,Icon} from 'antd';
import './style.less';

const MeuItem = (props)=>{
    let {data,handleClickMeu,handleAddMeuToProject,handleDeleteProjectMeu,handleClickLicenseNum,exist,meuType}=props;
    let licenseNum = data.license?data.license.totalNum:0;
    return (
        <div className="meu_item" onClick={handleClickMeu}>
            <h4>
                <p>
                {data.group}
                </p>
                <p>
                {data.name}
                </p>
                <p>
                {data.version}
                </p>
            </h4>
            {
                 meuType=="2"?<a className="license_num" onClick={handleClickLicenseNum}>{licenseNum}</a>:null
            }
            {data.description?(<p>{data.description}</p>):null}
            <div className="meu_bot">
                <div className="meu_price pull-left">
                    ¥
                    <em>0.2</em>
                    <em>/</em>
                    <em>Month</em>
                </div>
                
                    <div className="pull-right meu_price_btn">
                    {
                        meuType=="1"?<Button type="primary" disabled={exist?exist:false} shape="circle" icon="plus" onClick={handleAddMeuToProject}/>:
                        <Button type="primary"  shape="circle" icon="delete" onClick={handleDeleteProjectMeu}/>
                    }
                    
                     </div>
                
                
            </div>
        </div>
    )
}

export default MeuItem