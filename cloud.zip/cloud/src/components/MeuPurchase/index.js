import React,{Component} from 'react';
import Term from '../Term';
import {Input,Table} from 'antd';
import {
    defaultProps,
    propTypes
} from './props';
import './style.less';

const tableColumns=[
    {
        title: 'Name',
        dataIndex: 'name',
        key: 'name',
      }, {
        title: 'Value',
        dataIndex: 'value',
        key: 'value',
      }
];

 const MeuPurchase = (props)=>{
     const {data,dataType,licenseNum,nodeNum,changeLicenseNum,changeNodeNum}=props;
     const tableDataSource=[
        {
            key:'1',
            name:'name',
            value:(data.name?data.name:data.componentName)
        },
        {
            key:'2',
            name:'type',
            value:data.type
        },
        {
            key:'3',
            name:'language',
            value:data.language
        },
        {
            key:'4',
            name:'version',
            value:data.version
        },
        {
            key:'5',
            name:'author',
            value:data.author
        },
        {
            key:'6',
            name:'description',
            value:data.description
        }
    ];
    return (
        <div className="meu_pruchase">
            <div className="meu_section">
                <div className="detail_box purchase_box">
                    <section>
                        <label>Name:</label>
                        <span>{dataType==='component'?data.componentName:data.name}</span>
                    </section>
                    <section>
                        <label>Instance Number:</label>
                        <Input 
                            type="number" 
                            min="0" 
                            defaultValue={licenseNum} 
                            onChange={changeLicenseNum} 
                            style={{width:220}}
                        />
                    </section>
                    {
                        dataType==='component'?(<section>
                            <label>PC Number:</label>
                            <Input 
                                type="number" 
                                min="0" 
                                defaultValue={nodeNum} 
                                onChange={changeNodeNum} 
                                style={{width:220}}
                            />
                        </section>):null
                    }
                    <section>
                        <label>Term Length:</label>
                        <Term 
                            style={{width:220,display:'inline-block'}} 
                            changeLicenseTerm={props.changeLicenseTerm} 
                            changeLicenseUnit={props.changeLicenseUnit}
                            />
                    </section>
                </div>
            </div>
            <div className="meu_section">
                <h4>{dataType==='component'?"Component Summary":"MEU Summary"}</h4>
                <div className="detail_box">
                    <Table 
                        showHeader={false}  
                        columns={tableColumns}  
                        dataSource={tableDataSource} 
                        bordered={true}
                        pagination={false}
                        />
                </div>
            </div>
        </div>
    )
}

export default MeuPurchase;