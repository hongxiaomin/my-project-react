import React,{Component} from 'react';
import Term from '../Term';
import {Table,Input} from 'antd';
import './style.less';
class MeuRenew extends Component{
    constructor(props){
        super(props);
    }
 
    changeMeuLicenseTerm=(meu)=>(value)=>{
        this.props.changeMeuLicense({
            licenseId:meu.licenseId,
            licenseTerm:value
        })
    } 
    changeMeuLicenseUnit=(meu)=>(value)=>{
        this.props.changeMeuLicense({
            licenseId:meu.licenseId,
            licenseUnit:value
        })
    }
    render(){
        const {data,type,dataType} = this.props;
        let licenses=[];
        let columnsList =[];
        if(data){
            if(dataType==="meu"){
                const licenseDatas = JSON.stringify(data.license.licenseList);
                licenses = JSON.parse(licenseDatas);
                licenses=licenses.map((item,i)=>{
                    let {license,...x}=data;
                    item=Object.assign(item,x,{key:item.licenseId+'i'});
                    return item;
                })
                columnsList = [
                    {
                        title: 'LicenseId',
                        dataIndex: 'licenseId',
                        width:80,
                        key:'licenseId'
                    },
                    {
                        title: 'Group',
                        dataIndex: 'group',
                        width:80,
                        key:'group'
                    },
                    {
                        title: 'Name',
                        dataIndex: 'name',
                        width:80,
                        key:'name'
                    },
                    {
                        title: 'Version',
                        dataIndex: 'version',
                        width:80,
                        key:'version'
                    },
                    {
                        title: 'Status',
                        dataIndex: 'status',
                        width:80,
                        key:'status'
                    },
                    {
                        title: 'App Name',
                        dataIndex: 'appName',
                        width:100,
                        key:'appName'
                    },
                    {
                        title: 'Expire Date',
                        dataIndex: 'expireDate',
                        width:160,
                        key:'expireDate'
                    },
                    {
                        title: 'Purchase Date',
                        dataIndex: 'purchaseDate',
                        width:160,
                        key:'purchaseDate'
                    },
                    
                ];
            }else if(dataType==="component"){
                const tableItem=JSON.parse(JSON.stringify(data));
                tableItem.key=tableItem.componentName
                licenses=[tableItem];
                columnsList=[
                    {
                        title: 'ID',
                        dataIndex: 'id',
                        width:120,
                        render:(text)=>`*${(text+'').substr(-6)}`,
                        key:'id'
                    },
                    {
                        title: 'Name',
                        dataIndex: 'componentName',
                        width:150,
                        key:'componentName'
                    },
                    {
                        title: 'Instance Number',
                        dataIndex: 'instanceNum',
                        width:200,
                        key:'instanceNum'
                    },
                    {
                        title: 'Used Instance Number',
                        dataIndex: 'usedInstanceNum',
                        width:260,
                        key:'usedInstanceNum'
                    },
                    {
                        title: 'Instance ID',
                        dataIndex: 'instanceIds',
                        render:(arr)=>{
                            return arr.map((item,index)=><p key={index}>{`*${item.substr(-6)}`}</p>)
                        } ,
                        width:260,
                        key:'instanceIds'
                    },
                    {
                        title: 'PC Number',
                        dataIndex: 'pcNum',
                        width:200,
                        key:'pcNum'
                    },
                    {
                        title: 'Used PC Number',
                        dataIndex: 'usedPcNum',
                        width:200,
                        key:'usedPcNum'
                    },
                    {
                        title: 'Hardward ID',
                        dataIndex: 'hardwardIds',
                        render:(arr)=>{
                            return arr.map((item,index)=><p key={index}>{`*${item.substr(-6)}`}</p>)
                        } ,
                        width:200,
                        key:'hardwardIds'
                    },
                    {
                        title: 'Expire Date',
                        dataIndex: 'expireDate',
                        width:260,
                        key:'expireDate'
                    }
                ]
            }
            
        }
       
        let columns=[];
        if(type==='2'){
            columns=columnsList
            if(dataType==="meu"){
                columns[0].render=(text)=>`*${text.substr(-6)}`
            }
        }else if(type==='1'&&dataType==="meu"){
            columns=JSON.parse(JSON.stringify(columnsList));
            columns[0].render=(text)=>`*${text.substr(-6)}`
            columns.push({
                title: 'Term Length',
                key:'operation',
                width:300,
                render:(value)=> {
                return <Term
                        changeLicenseTerm={this.changeMeuLicenseTerm(value)} 
                        changeLicenseUnit={this.changeMeuLicenseUnit(value)}/>}
            });
        }
        return (
            <div>
                {
                  ((type==='1'&&dataType==="meu") ||type==='2')?
                    <Table 
                        columns={columns}  
                        dataSource={licenses} 
                        pagination={false} 
                        scroll={{x:1600,y:500}}
                    />:
                    <div>
                        <div className="renew_component">
                        <section>
                            <label>Name:</label>
                            <span>{data.componentName}</span>
                        </section>
                        <section>
                            <label>Instance Number:</label>
                            <Input 
                                type="number" 
                                min="0" 
                                value={this.props.licenseNum} 
                                onChange={this.props.changeLicenseNum} 
                                style={{width:220}}
                            />
                        </section>
                        <section>
                            <label>PC Number:</label>
                            <Input 
                                type="number" 
                                min="0" 
                                value={this.props.nodeNum} 
                                onChange={this.props.changeNodeNum} 
                                style={{width:220}}
                            />
                        </section>
                        <section>
                            <label>Term Length:</label>
                            <Term 
                                style={{width:220,display:'inline-block'}} 
                                changeLicenseTerm={this.props.changeLicenseTerm} 
                                changeLicenseUnit={this.props.changeLicenseUnit}
                                />
                        </section>
                    </div>
                    </div>        
                }
               
            </div>
        )
    }
    
    }

    
   

export default MeuRenew;