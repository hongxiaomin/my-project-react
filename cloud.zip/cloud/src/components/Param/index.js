import React,{Component} from 'react';
import {Input,Icon} from 'antd';

class Param extends Component{
    constructor(props){
        super(props);
        this.state={
            type:'',
            value:''
        }
    }   
    changeType=(e)=>{
        this.setState({
            type:e.target.value
        })
        this.props.changeParam('type',e.target.value)
    }

    changeValue=(e)=>{
        let value = e.target.value;
        console.log('value',value);
        this.setState({
            value
        })
        this.props.changeParam('value',value)
    }
    render(){
        return (
            <div className="param_item">
                <div className="param_type">
                    <label>Type:</label>
                    <Input style={{width:260}} onChange={this.changeType} value={this.state.type}/>
                </div>
                <div className="param_value">
                    <label>Value:</label>
                    <Input style={{width:260}} onChange={this.changeValue} value={this.state.value}/>
                </div>
                <Icon type="close-circle" 
                    style={{
                        color:'#096dd9',
                        fontSize:'20px',
                        marginLeft:'10px',
                        marginTop:'5px'
                    }}
                    onClick={this.props.deleteParam}
                    />
            </div>
        )
    }

}

export default Param;