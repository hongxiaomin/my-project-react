import React, { Component } from 'react';
import { Select, Button, message, Input, Table } from 'antd';
import './style.less';

const Option = Select.Option;
const InputGroup = Input.Group;

class StartTimer extends Component {
    constructor(props) {
        super(props);
        this.state = {
            timerList:[],
            selectedRowKeys:[],

        }
    }

    componentDidMount(){
        let timerList=[...this.props.timerList];
        let selectedRowKeys = [...this.state.selectedRowKeys];
        let selectedTimer = timerList.filter(item => {
            return item.checked===true;
        });
        if(selectedTimer.length>0){
            selectedTimer=selectedTimer[0];
            let selectedKey = selectedTimer.key;
            selectedRowKeys.push(selectedKey);
        }
        this.setState({
            timerList,
            selectedRowKeys
        })
    }

    changeType = (timer) => (value) => {
        let timerList=[...this.state.timerList];
        timerList=timerList.map(item=>{
            if(item.key===timer.key){
                item.type=value;
            }
            return item;
        })
        this.setState({
            timerList
        })
    }
    changeTimer=(selectedRowKeys)=>{
        let timerList=[...this.state.timerList];
        timerList=timerList.map(item=>{
            if(item.key===selectedRowKeys[0]){
                item.checked=true;
            }else{
                item.checked=false;
            }
            return item;
        })
        this.setState({
            selectedRowKeys,
            timerList
        })
    }
    changeTimeUnit=(timer)=>(value)=>{
        let timerList=[...this.state.timerList];
        timerList=timerList.map(item=>{
            if(item.key===timer.key){
                item.timeUnit=value;
            }
            return item;
        })
        this.setState({
            timerList
        })
    }

    changeValue=(timer)=>(e)=>{
        let value = e.target.value;
        let timerList=[...this.state.timerList];
        timerList=timerList.map(item=>{
            if(item.key===timer.key){
                item.value=value;
            }
            return item;
        })
        this.setState({
            timerList
        })
    }
    addTimer=()=>{
        let timerList = [...this.state.timerList];
        let newTimer = this.props.initStartTimer();
        timerList.push(newTimer);
        this.setState({
            timerList
        })
    }
    removeTimer=()=>{
        let selectedKey = this.state.selectedRowKeys[0];
        let timerList = [...this.state.timerList];
        timerList=timerList.filter(item=>{
            return item.key!==selectedKey;
        })
        timerList[0].checked=true;
        this.setState({
            timerList,
            selectedRowKeys:[timerList[0].key]
        })
    }

    handleOK=()=>{
        let timerList=[...this.state.timerList];
        let selectedTimer = timerList.filter(item=>{
            return item.checked===true;
        })
        if(selectedTimer.length>0){
            selectedTimer=selectedTimer[0];
            this.props.startNode.timerId=selectedTimer.id;
        }
        this.props.showTimer(false);
        this.props.setTimerList(timerList);
    }
    handleCancel=()=>{
        this.props.showTimer(false);
    }

    render() {
        const columns = [
            {
                title: 'ID',
                dataIndex: 'id',
                key: 'id',
            },
            {
                title: 'Type',
                dataIndex: 'type',
                key: 'type',
                render: (value, row) => {
                    return (
                        <Select defaultValue={value} style={{ width: 120 }} onChange={this.changeType(row)}>
                            <Option value="cron">cron</Option>
                            <Option value="period">period</Option>
                        </Select>
                    )
                }
            },
            {
                title: 'Value',
                dataIndex: 'value',
                key: 'value',
                render: (value, row) => {
                    if (row.type === "cron") {
                        return <Input style={{ width: 200 }} onChange={this.changeValue(row)} defaultValue={value}/>
                    } else if (row.type === "period") {
                        return <InputGroup compact>
                            <Select defaultValue={row.timeUnit} onChange={this.changeTimeUnit}>
                                <Option value="nanoseconds">nanoseconds</Option>
                                <Option value="microseconds">microseconds</Option>
                                <Option value="milliseconds">milliseconds</Option>
                                <Option value="seconds">seconds</Option>
                                <Option value="minutes">minutes</Option>
                                <Option value="hours">hours</Option>
                                <Option value="days">days</Option>
                            </Select>
                            <Input style={{ width: 100 }} defaultValue={value} onChange={this.changeValue(row)}/>
                        </InputGroup>
                    }
                }
            }
        ];

        const rowSelection={
            selectedRowKeys:this.state.selectedRowKeys,
            onChange:this.changeTimer,
            type:'radio'
        }

        return (
            <div className="start_timer_box">
                <h4>Edit Timer</h4>
                <div className="start_timer_content">
                    <div className="btn_group1">
                        <Button type="Primary" onClick={this.addTimer}>Add</Button>
                        <Button type="Primary" onClick={this.removeTimer}>Remove</Button>
                    </div>
                    <Table 
                        columns={columns} 
                        dataSource={this.state.timerList}
                        rowSelection={rowSelection}
                        pagination={false}

                    />
                </div>
                <div className="btn_group">
                    <Button type="primary" onClick={this.handleOK}>OK</Button>
                    <Button onClick={this.handleCancel}>Cancel</Button>
                </div>
            </div>
        )

    }
}

export default StartTimer;