import React, { Component } from 'react';
import { Select, Button, message } from 'antd';
import './style.less';

const Option = Select.Option;

class StartType extends Component {
    constructor(props) {
        super(props);
        this.state = {
            type: "",
            sync: "false"
        }
    }
    componentDidMount(){
        let startNode=this.props.startNode;
        let type = startNode.type;
        let sync = startNode.sync;
        console.log('sync',sync)
        if(type){
            this.setState({
                type
            })
        }else{
            this.setState({
                type:''
            })
        }

        if(sync){
            this.setState({
                sync
            })
        }else{
            this.setState({
                sync:'false'
            })
        }
    }
    changeType = (value) => {
        this.setState({
            type: value
        })
    }
    changeSync = (value) => {
        this.setState({
            sync: value
        })
    }
    handleOK = () => {
        let type = this.state.type;
        let sync = this.state.sync;
        let startNode = this.props.startNode
        if (type && type === "external") {
            startNode.type = type;
            startNode.sync = sync;
            this.props.setIsTimer(false);
        } else if (type && type === "timer") {
            startNode.type = type;
            delete startNode.sync;
            this.props.setIsTimer(true);
            console.log('timerList',this.props.timerList.length);
            if(this.props.timerList.length===0){
                let arr=[this.props.initStartTimer()]
                this.props.setTimerList(arr);
            }
        } else {
            startNode.type = type;
            delete startNode.sync;
            this.props.setIsTimer(false);
        }
        this.props.showStartType(false);
    }

    handleCancel = () => {
        this.props.showStartType(false);
    }


    render() {
        return (
            <div className="start_type_box">
                <h4>Start Information</h4>
                <div className="start_type_content">
                    <div className="start_type_item">
                        <label>type:</label>
                        <Select value={this.state.type} style={{ width: 260 }} onChange={this.changeType}>
                            <Option value="">&nbsp;&nbsp;</Option>
                            <Option value="timer">timer</Option>
                            <Option value="external">external</Option>
                        </Select>
                    </div>
                    {
                        this.state.type === "external" ? <div className="start_type_item">
                            <label>sync:</label>
                            <Select value={this.state.sync} style={{ width: 260 }} onChange={this.changeSync}>
                                <Option value="false">false</Option>
                                <Option value="true">true</Option>
                            </Select>
                        </div> : null
                    }
                </div>
                <div className="btn_group">
                    <Button type="primary" onClick={this.handleOK}>OK</Button>
                    <Button onClick={this.handleCancel}>Cancel</Button>
                </div>
            </div>
        )

    }
}

export default StartType;