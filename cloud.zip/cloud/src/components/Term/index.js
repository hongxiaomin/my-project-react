import React,{Component} from 'react';
import {Input, Select} from 'antd';
import { AutoComplete } from 'material-ui';

const InputGroup =Input.Group;
const Option =Select.Option;

export default class Term extends Component{
    constructor(props){
        super(props);
        this.state={
            unit:'Months',
            num:0
        }
    }
    changeUnit=(value)=>{
        this.setState({
            unit:value
        });
        this.props.changeLicenseUnit(value);
    }
    changeNum=(e)=>{
        this.setState({
            num:e.target.value
        });
        this.props.changeLicenseTerm(Number(e.target.value));
    }
    render(){
        return (
            <InputGroup compact style={this.props.style}>
                <Input 
                    onChange={this.changeNum} 
                    style={{width:'120px'}} 
                    type="number"
                    value={this.state.num}
                    min="0"
                />
                <Select defaultValue={this.state.unit} onChange={this.changeUnit} style={{width:'100px'}}>
                    <Option value="Months">Months</Option>
                    <Option value="Years">Years</Option>
                </Select>
            </InputGroup>
        )
    }
}