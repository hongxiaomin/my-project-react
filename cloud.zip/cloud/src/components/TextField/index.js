import React from 'react';
import TextField from 'material-ui/TextField';

export const style={
    floatingLabelStyle:{
        color:'#1890ff',
        
    },
    underlineStyle:{
        borderColor:'#1890ff',
    }
}


const CloudTextField = (props) => {
    const {text,handlerChange,field}=props;
    const changeText=(event,newValue)=>{
        handlerChange({[field]:newValue});
    }
    return (<TextField
        floatingLabelText={text}
        type="text"
        floatingLabelStyle={style.floatingLabelStyle}
        underlineStyle={style.underlineStyle}
        onChange={changeText}
    />)
};

export default CloudTextField;