import React,{Component} from 'react';
import {Collapse} from 'antd';
import './style.less';
import { isArray } from 'util';

const Panel = Collapse.Panel;
class ToolbarContainer extends Component{
    constructor(props){
        super(props);
        this.state={
            contents:[]
        }
    }
    componentWillMount(){
        let contents = this.props.contents;
        if(!isArray(contents)){
            contents=[contents];
        }
        this.setState({
            contents
        })
    }

    render(){
        const {name,isParent}=this.props;
        return (
            <div className="toolbar_container">
                {
                    isParent?(
                        <Collapse>
                            <Panel header={name} >
                                "contents"
                                {
                                    this.state.contents.map((item)=>{
                                        console.log(item);
                                    })
                                }
                            </Panel>
                      </Collapse> 
                    ):(<div className="toolbar_Item">
                            <div className="toolbar_icon"></div>
                            <div className="toolbar_name">{this.state.contents}</div>
                    </div>)
                }
            </div>
        )
        
    }
}

export default ToolbarContainer;