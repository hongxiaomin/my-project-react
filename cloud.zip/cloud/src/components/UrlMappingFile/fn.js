import {getXmlJsonData} from '../../utils/todoXml';
import { isArray } from 'util';
import { isObject } from 'util';
export const changeMeu = _this => (value) => {
    console.log('changeMeu', value);
    _this.setState({
        meu:value
    })
    _this.props.changeUrlMaping("@dest",value);
    setTimeout(()=>{
        _this.props.changeUrlMaping("@operationId",'');
    },500)
    let selectedMeu = _this.props.selectedMeus.filter(item => {
        return item.id === value;
    })
    selectedMeu = selectedMeu[0];
    let definition = getXmlJsonData(selectedMeu["definition"]);
    let operations = definition.meu.operations;
    if (operations) {
        operations=operations.operation;
        if (isArray(operations)) {
            operations = operations;
        } else if (isObject(operations)) {
            operations = [operations];
        }
        _this.setState({
            operationList:operations
        })
    }else{
        _this.setState({
            operationList:[]
        })
    }
    _this.setState({
        operationId:''
    })
}

export const changeOperationId =_this=>(value)=>{
    console.log('changeOperationId',value);
    _this.setState({
        operationId:value
    })
    _this.props.changeUrlMaping("@operationId",value);
}

export const chnageMethod=_this=>(value)=>{
    console.log('chnageMethod',value);
    _this.setState({
        method:value
    })
    _this.props.changeUrlMaping("@method",value);
}

export const changeUrl = _this =>(e)=>{
    let value = e.target.value
    console.log('changeUrl',value);
    _this.setState({
        url:value
    })
    _this.props.changeUrlMaping("@url",value);
}