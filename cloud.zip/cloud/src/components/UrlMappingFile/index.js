import React, { Component } from 'react';
import { Input, Select } from 'antd';
import {getXmlJsonData} from '../../utils/todoXml';
import { 
    changeMeu,
    changeOperationId,
    chnageMethod,
    changeUrl
 } from './fn';
import './style.less';
import { isArray,isObject } from '../../utils/Common';

const Option = Select.Option;

class UrlMappingFile extends Component {
    constructor(props) {
        super(props);
        this.changeMeu=changeMeu(this);
        this.changeOperationId=changeOperationId(this);
        this.chnageMethod=chnageMethod(this);
        this.changeUrl=changeUrl(this);
        let addUrlMappingData=this.props.addUrlMappingData

        this.state = {
            url: addUrlMappingData["@url"],
            meu: addUrlMappingData["@dest"],
            operationId: addUrlMappingData["@operationId"],
            operationList: [],
            method: addUrlMappingData["@method"]
        }
    }

    componentDidMount=()=>{
        let selectedMeu = this.props.selectedMeus.filter(item => {
            return item.id === this.props.addUrlMappingData["@dest"] ;
        })
        if(selectedMeu.length>0){
            selectedMeu = selectedMeu[0];
            let definition = getXmlJsonData(selectedMeu["definition"]);
            let operations = definition.meu.operations;
            if (operations) {
                operations=operations.operation;
                if (isArray(operations)) {
                    operations = operations;
                } else if (isObject(operations)) {
                    operations = [operations];
                }
                this.setState({
                    operationList:operations
                })
            }else{
                this.setState({
                    operationList:[]
                })
            }
        }
      
    }

    render() {
        return (
            <div className="url_mapping_file">
                <div className="url_mapping_file_item">
                    <label>Url:</label>
                    <Input 
                        value={this.state.url} 
                        style={{ width: 300 }} 
                        onChange={this.changeUrl}
                    />
                </div>
                <div className="url_mapping_file_item">
                    <label>MEU:</label>
                    <Select
                        showSearch
                        style={{ width: 300 }}
                        placeholder="Select a meu"
                        optionFilterProp="children"
                        onChange={this.changeMeu}
                        value={this.state.meu}
                        filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
                    >
                        {
                            this.props.selectedMeus.map((item,index)=>{
                                return <Option value={item.id} key={index}>{item.id}</Option>
                            })
                        }
                    </Select>
                </div>

                 <div className="url_mapping_file_item">
                    <label>Operation ID:</label>
                    <Select
                        style={{ width: 300 }}
                        placeholder="Select a operation id"
                        onChange={this.changeOperationId}
                        value={this.state.operationId}
                    >
                        {
                            this.state.operationList.map((item,index)=>{
                                return <Option value={item["@id"]} key={index}>{item["@id"]}</Option>
                            })
                        }
                    </Select>
                </div>

                <div className="url_mapping_file_item">
                    <label>Method:</label>
                    <Select
                        style={{ width: 300 }}
                        placeholder="Select a method"
                        onChange={this.chnageMethod}
                        value={this.state.method}
                    >
                       <Option value="GET" key="GET">GET</Option>
                       <Option value="POST" key="POST">POST</Option>
                       <Option value="PUT" key="PUT">PUT</Option>
                       <Option value="DELETE" key="DELETE">DELETE</Option>
                    </Select>
                </div>

            </div>
        )
    }
}

export default UrlMappingFile;