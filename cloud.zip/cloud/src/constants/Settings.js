import lazyLoading from '../hocs/lazyLoading';

export default [
  {
    route: '',
    title: 'Market',
    component: lazyLoading(() => import('../routes/Market')),
  },
  {
    route: 'Resource',
    title: 'Resource',
    children: [
      {
        route: 'Meu',
        title: 'MEU',
        component: lazyLoading(() => import('../routes/Resource/MEU')),
      },
      {
        route: 'Components',
        title: 'Components',
        component: lazyLoading(() => import('../routes/Resource/Components')),
      },
      {
        route: 'EPG',
        title: 'EPG',
        component: lazyLoading(() => import('../routes/Resource/EPG')),
      },
      {
        route: 'App',
        title: 'App',
        component: lazyLoading(() => import('../routes/Resource/App')),
      },
      {
        route: 'Profile',
        title: 'Profile',
        component: lazyLoading(() => import('../routes/Resource/Profile')),
      },
      {
        route: 'ExecutionRecord',
        title: 'Execution Record',
        component: lazyLoading(() => import('../routes/Resource/ExecutionRecord')),
      },
    ],
  }
];
