import { SERVER_IP } from '../../constants/Config';

export const getProjectUrl = `${SERVER_IP}/cloudServer/project`;
export const getProjectMeuUrl = `${SERVER_IP}/cloudServer/project/meu`;
export const getProjectEpgUrl = `${SERVER_IP}/cloudServer/project/epg`;
export const getProjectAppUrl = `${SERVER_IP}/cloudServer/app`;
export const getEnvProfileUrl = `${SERVER_IP}/cloudServer/envProfile`;
export const getAppProfileUrl = `${SERVER_IP}/cloudServer/appProfile`;


export const columns = [{
  title: 'ID',
  dataIndex: 'id',
  key: 'id',
  width:'10%'
}, {
  title: 'Name',
  dataIndex: 'name',
  key: 'name',
  width:'25%'
}, {
  title: 'Description',
  dataIndex: 'description',
  key: 'description',
  width:'25%'
}, {
  title: 'Create Time',
  dataIndex: 'createTime',
  key: 'createTime',
  width:'20%'
}, {
  title: 'Update Time',
  dataIndex: 'updateTime',
  key: 'updateTime',
  width:'20%'
}
];