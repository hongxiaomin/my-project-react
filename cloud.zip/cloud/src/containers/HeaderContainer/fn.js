import {message} from 'antd';
import {getProjectUrl,getProjectMeuUrl,getProjectEpgUrl,getEnvProfileUrl,getAppProfileUrl,getProjectAppUrl} from './config';
import request from '../../utils/fetchData';


export const getProjectData = _this=>async(cb)=>{
    let response =await request(getProjectUrl);
    if(response.message.code===0){
        cb(response.message.rows);
    }else{
        message.error(response.message.message);
    }
}

export const handleProject =_this=>() => {
    if (_this.props.projectList.length > 0) {
        _this.setState({
            projectVisible: true
        })
    } else {
        _this.props.history.push('/project/create');
    }
}

export const selectProjectOk =_this=> () => {
    let projectList = _this.props.projectList;
    let selectedKey = _this.state.selectedRowKeys;
    if(selectedKey.length>0){
        selectedKey=selectedKey[0];
        let selectedProject = projectList.filter(item=>{
            return item.key === selectedKey;
        })
        selectedProject=selectedProject[0];
        _this.props.setSelectedProject(selectedProject);
        localStorage.setItem('selectedProjectId',selectedProject.id);
        _this.setState({
            projectVisible:false
        })
    }else{
        message.error('Select A Project!');
    }
}

export const selectProjectCancel = _this => () => {
    _this.setState({
        projectVisible:false
    })
}

export const changeProject =_this=> (selectedRowKeys) =>{
    _this.setState({
        selectedRowKeys
    })
}

export const addProject=_this=>()=>{
    _this.setState({
        projectVisible:false
    })
    _this.props.history.push('/project/create');
}

export const setProject=_this=>()=>{
    _this.setState({
        projectVisible:false
    })
    _this.props.history.push('/project/set');
}

export const getProjectMeuList=_this=>async(project,cb)=>{
    let response =await request(getProjectMeuUrl,{
        data:{projectId:project.id}
    });
    if(response.message.code===0){
        let data=response.message.rows;
        let newData = data.map(item=>{
            let id = `${item.group}/${item.name}/${item.version}`;
            let key =id;
            return {...item,id,key};
        })
        cb(newData);
    }else{
        message.error(`Get Project ${project.name} meu error!`)
    }
}

export const getProjectEpgData=_this=>async(project,cb)=>{
    let response =await request(getProjectEpgUrl,{
        data:{projectId:project.id}
    });
    if(response.message.code===0){
        let data=response.message.rows;
        let newData = data.map(item=>{
            let key =item.id;
            return {...item,key};
        })
        cb(newData);
    }else{
        message.error(`Get Project ${project.name} epg error!`)
    }
}

export const getProjectEnvProfile=_this=>async(project,cb)=>{
    let response =await request(getEnvProfileUrl,{
        data:{projectId:project.id}
    });
    if(response.message.code===0){
        let data=response.message.rows;
        let newData = data.map(item=>{
            let key =item.id;
            return {...item,key};
        })
        cb(newData);
    }else{
        message.error(`Get Project ${project.name} environment profile error!`)
    }
}

export const getProjectAppProfile=_this=>async(project,cb)=>{
    let response =await request(getAppProfileUrl,{
        data:{projectId:project.id}
    });
    if(response.message.code===0){
        let data=response.message.rows;
        let newData = data.map(item=>{
            let key =item.id;
            return {...item,key};
        })
        cb(newData);
    }else{
        message.error(`Get Project ${project.name} app profile error!`)
    }
}

export const getProjectApp=_this=>async(project,cb)=>{
    let response =await request(getProjectAppUrl,{
        data:{projectId:project.id}
    });
    if(response.message.code===0){
        let data=response.message.rows;
        let newData = data.map(item=>{
            let key =item.id;
            return {...item,key};
        })
        cb(newData);
    }else{
        message.error(`Get Project ${project.name} app error!`)
    }
}