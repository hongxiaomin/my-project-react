import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { Layout, Icon, Input, Button, Table } from 'antd';
import CloudModal from '../../components/CloudModal';
import { toJS } from 'immutable';
import { getProject, setSelectedProject, setProjectMeuList,setProjectEpg,setEnvProfileList,setAppProfileList,setAppList } from '../../actions';
import {
    getProjectData,
    handleProject,
    selectProjectOk,
    selectProjectCancel,
    changeProject,
    addProject,
    setProject,
    getProjectMeuList,
    getProjectEpgData,
    getProjectEnvProfile,
    getProjectAppProfile,
    getProjectApp,

} from './fn'
import { columns } from './config';
import './style.less';

const { Header } = Layout;



class HeaderContainer extends Component {
    constructor(props) {
        super(props);
        this.getProjectData = getProjectData(this);
        this.handleProject = handleProject(this);
        this.selectProjectOk = selectProjectOk(this);
        this.selectProjectCancel = selectProjectCancel(this);
        this.changeProject = changeProject(this);
        this.addProject = addProject(this);
        this.setProject = setProject(this);
        this.getProjectMeuList = getProjectMeuList(this);
        this.getProjectEpgData=getProjectEpgData(this);
        this.getProjectEnvProfile=getProjectEnvProfile(this);
        this.getProjectAppProfile=getProjectAppProfile(this);
        this.getProjectApp=getProjectApp(this);

        this.state = {
            projectVisible: false,
            selectedRowKeys: [],
        }
    }

    componentWillReceiveProps(props) {
        let selectedProject = props.selectedProject;
        if(selectedProject){
            let id = selectedProject.id;
            let selectedRowKey = this.state.selectedRowKeys[0];
            this.getProjectMeuList(selectedProject, (data) => {
                this.props.setProjectMeuList(data);
            })
            this.getProjectEpgData(selectedProject,(data)=>{
                this.props.setProjectEpg(data);
            });
    
            this.getProjectEnvProfile(selectedProject,(data)=>{
                this.props.setEnvProfileList(data);
            });
    
            this.getProjectAppProfile(selectedProject,(data)=>{
                this.props.setAppProfileList(data);
            });
            this.getProjectApp(selectedProject,(data)=>{
                this.props.setAppList(data);
            });
    
            if (id == selectedRowKey) {
                return;
            } else {
                this.setState({
                    selectedRowKeys: [id]
                })
            }
        }
        
    }

    componentDidMount() {
        this.getProjectData((data) => {
            data = data.map((item, index) => {
                let key = item.id;
                let selectedProjectId = localStorage.getItem('selectedProjectId');
                console.log('selectedProjectId',selectedProjectId);
                if (selectedProjectId) {
                    if(selectedProjectId == key){
                        this.props.setSelectedProject(item);
                        this.setState({
                            selectedRowKeys: [key]
                        })
                        this.getProjectMeuList(item, (data) => {
                            this.props.setProjectMeuList(data);
                        })
                        this.getProjectEpgData(item,(data)=>{
                            this.props.setProjectEpg(data);
                        });
                        this.getProjectEnvProfile(item,(data)=>{
                            this.props.setEnvProfileList(data);
                        });
                        this.getProjectAppProfile(item,(data)=>{
                            this.props.setAppProfileList(data);
                        });
                        this.getProjectApp(item,(data)=>{
                            this.props.setAppList(data);
                        });
                    }
                    
                } else {
                    if (index === 0) {
                        this.props.setSelectedProject(item);
                        localStorage.setItem('selectedProjectId', item.id);
                        this.setState({
                            selectedRowKeys: [key]
                        })
                        this.getProjectMeuList(item, (data) => {
                            this.props.setProjectMeuList(data);
                        });
                        this.getProjectEpgData(item,(data)=>{
                            this.props.setProjectEpg(data);
                        });
                        this.getProjectEnvProfile(item,(data)=>{
                            this.props.setEnvProfileList(data);
                        });
                        this.getProjectAppProfile(item,(data)=>{
                            this.props.setAppProfileList(data);
                        });
                        this.getProjectApp(item,(data)=>{
                            this.props.setAppList(data);
                        });
                    }
                }
                item = { key, ...item };
                return item;
            });
            this.props.getProject(data);
        })
    }

    render() {

        const rowSelection = {
            onChange: this.changeProject,
            selectedRowKeys: this.state.selectedRowKeys,
            type: 'radio'
        }
        return (
            <div>
                <Header className="header">
                    <Icon type={this.props.collapsed ? 'menu-unfold' : 'menu-fold'} onClick={this.props.toggleCollapsed} style={{ color: '#fff', fontSize: '20px', marginTop: '25px' }} />
                    <h1 style={{ display: 'inline-block', color: '#fff', fontSize: '24px', marginLeft: '30px' }}>Cornerstone Cloud</h1>
                    <div className="project_wrapper" onClick={this.handleProject}>
                        <Icon type="api" style={{ color: '#fff', fontSize: '12px' }} />
                        <span>{this.props.selectedProject ? this.props.selectedProject.name : 'Select Project'}</span>
                        <Icon type="caret-down" style={{ color: '#fff', fontSize: '12px' }} />
                    </div>
                </Header>
                <CloudModal
                    title="Select A Project"
                    visible={this.state.projectVisible}
                    onOk={this.selectProjectOk}
                    onCancel={this.selectProjectCancel}
                    width='960px'
                >
                    <div className="project-top">
                        <Input prefix={<Icon type="search" style={{ color: '#0086DB' }} />} style={{ width: '500px' }} />
                        <Button type="primary" icon="setting" onClick={this.setProject} />
                        <Button type="primary" icon="plus" onClick={this.addProject} />
                    </div>
                    <div className="project-table">
                        <Table
                            rowSelection={rowSelection}
                            columns={columns}
                            dataSource={this.props.projectList}
                        />
                    </div>

                </CloudModal>
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    state = state.toJS();
    return {
        selectedProject: state.project.selectedProject,
        projectList: state.project.projectList
    }
};

const mapDispatchToProps = (dispatch) => ({
    getProject: (data) => {
        dispatch(getProject({
            projectList: data
        }))
    },
    setSelectedProject: (data) => {
        dispatch(setSelectedProject({
            selectedProject: data
        }))
    },
    setProjectMeuList: (data) => {
        dispatch(setProjectMeuList({
            projectMeuList: data
        }))
    },
    setProjectEpg:(data)=>{
        dispatch(setProjectEpg({
            projectEpgList:data
        }))
    },
    setEnvProfileList:(data)=>{
        dispatch(setEnvProfileList({
            envProfileList:data
        }))
    },
    setAppProfileList:(data)=>{
        dispatch(setAppProfileList({
            appProfileList:data
        }))
    },
    setAppList:(data)=>{
        dispatch(setAppList({
            appList:data
        }))
    }
})

HeaderContainer = withRouter(HeaderContainer);

export default connect(mapStateToProps, mapDispatchToProps)(HeaderContainer);