import React, { Component } from 'react';
import { Layout, Menu } from 'antd';
import { Link,withRouter} from 'react-router-dom';
import './style.less';


const { SubMenu } = Menu;
const { Content, Sider } = Layout;

class SiderMenu extends Component {
    constructor(props){
        super(props);
        this.state={
            selectedKeys:[],
        }
    }
    componentDidUpdate(){
        let pathname = this.props.location.pathname;
        let selectedKey=''
        let currentSelectedKey = this.state.selectedKeys[0];
        if(pathname==='/'){
            selectedKey = 'market';
        }else{
            let keyArr = pathname.split('/');
            selectedKey = keyArr[keyArr.length-1];
        }
        if(selectedKey!==currentSelectedKey){
            this.setState({
                selectedKeys:[selectedKey],
            })
        }
    }
    render() {
        return (
            <Sider
                width={300}
                collapsed={this.props.collapsed}
                collapsedWidth={0}
                collapsible={true}
                trigger={null}
                style={{
                    color: 'rgba(0, 0, 0, 0.87)',
                    backgroundColor: 'rgb(255, 255, 255)',
                    transition: 'transform 450ms cubic-bezier(0.23, 1, 0.32, 1) 0ms',
                    boxSizing: 'border-box',
                    fontFamily: ' Roboto, sans-serif',
                    webkittapHighlightColor: 'rgba(0, 0, 0, 0)',
                    boxShadow: 'rgba(0, 0, 0, 0.16) 0px 3px 10px, rgba(0, 0, 0, 0.23) 0px 3px 10px',
                    borderRadius: '0px',
                }}
            >
                <Menu
                    mode="inline"
                    selectedKeys={this.state.selectedKeys}
                    mode="inline"
                    inlineCollapsed={this.props.collapsed}
                    style={{ height: '100%', borderRight: 0, fontSize: '16px' }}
                >
                    <Menu.Item key="market">
                        <Link to="/">
                            Market
                        </Link>
                    </Menu.Item>
                    <SubMenu key="resource" title="Resource">
                        <Menu.Item key="meu">
                            <Link to="/resource/meu">
                                MEU
                            </Link>
                        </Menu.Item>
                        {/* <Menu.Item key="components">
                            <Link to="/resource/components">
                                Components
                            </Link>
                        </Menu.Item> */}
                        <Menu.Item key="epg">
                            <Link to="/resource/epg">
                                EPG
                            </Link>
                        </Menu.Item>
                        <Menu.Item key="app">
                            <Link to="/resource/app">
                                App
                            </Link>
                        </Menu.Item>
                        <SubMenu key="profile" title="Profile">
                            <Menu.Item key="environmentProfile">
                                <Link to="/resource/profile/environmentProfile">
                                    Environment Profile
                                </Link>
                            </Menu.Item>
                            <Menu.Item key="appProfile">
                                <Link to="/resource/profile/appProfile">
                                    App Profile
                                </Link>
                            </Menu.Item>
                        </SubMenu>
                        <Menu.Item key="executionrecord">
                            <Link to="/resource/executionrecord">
                                Execution Record
                            </Link>
                        </Menu.Item>
                    </SubMenu>
                </Menu>
            </Sider>
        )
    }
}
SiderMenu=withRouter(SiderMenu);
export default SiderMenu;