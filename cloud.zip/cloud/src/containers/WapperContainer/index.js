import React, { Component } from 'react';
import { Layout} from 'antd';
import { ThemeProvider, getTheme } from '@delta/common-utils';
import MyRouter from '../../routes';
import Header from '../HeaderContainer';
import SiderMenu from '../SiderMenu';
import './style.less';

const theme = getTheme({
  appBar: {
    color: '#0086DB',
    height: 56,
  },
});

class Wrapper extends Component {
  constructor(props) {
    super(props);
    this.state = {
      collapsed: false,
    }
  }

  toggleCollapsed=()=>{
    this.setState({
      collapsed: !this.state.collapsed,
    });
  }

  render() {
    return (
      <ThemeProvider muiTheme={theme}>
        <Layout>
          <Header 
            collapsed={this.state.collapsed}
            toggleCollapsed={this.toggleCollapsed}
            />
          <Layout>
            <SiderMenu collapsed={this.state.collapsed}/>
            <Layout style={{ padding: '0 24px 24px',background:'#fff' }}>
              <MyRouter />
            </Layout>
          </Layout>
        </Layout>
      </ThemeProvider>
    )
  }
}


export default Wrapper;
