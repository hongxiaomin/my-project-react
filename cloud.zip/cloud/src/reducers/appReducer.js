import {
    SET_APP_LIST,
    SET_SELECTED_PROJECT_APP,
    SET_IS_APP_EDIT,
    EDIT_PROJECT_APP,
    ADD_PROJECT_APP,
    DELETE_PROJECT_APP,
} from '../constants/actionTypes';

const initialState = {
    appList:[],
    selectedApp:null,
    isEdit:false,
}

const setAppList = (state,{payload})=>{
    let appList = payload.appList;
    let newState={...state,appList};
    return newState;
}

const setSelecteProjectdApp = (state,{payload})=>{
    let newState = {...state};
    let selectedApp = {...payload.app};
    newState={...newState,selectedApp};
    return newState;
}

const setIsAppEdit=(state,{payload})=>{
    let newState = {...state};
    let isEdit = newState.isEdit;
    if(isEdit!==payload.isEdit){
        isEdit = payload.isEdit;
        newState={...newState,isEdit};
    }
    return newState;
}

const editProjectApp=(state,{payload})=>{
    let appList = [...state.appList];
    let currentApp = payload.app;
    appList=appList.map(item=>{
        if(item.id === currentApp.id){
            return {...currentApp};
        }else{
            return {...item};
        }
    });
    let newState={...state,appList};
    return newState;
}

const addProjectApp =(state,{payload})=>{
    let appList =[...state.appList];
    let currentApp = payload.app;
    appList.push(currentApp);
    let newState = {...state,appList};
    return newState;
}

const deleteProjectApp = (state,{payload})=>{
    let appList =[...state.appList];
    let currentApp = payload.app;
    appList=appList.filter(item=>{
        return item.id!==currentApp.id;
    })
    let newState = {...state,appList};
    return newState;
}

const reducers = {
    [SET_APP_LIST]:setAppList,
    [SET_SELECTED_PROJECT_APP]:setSelecteProjectdApp,
    [SET_IS_APP_EDIT]:setIsAppEdit,
    [EDIT_PROJECT_APP]:editProjectApp,
    [ADD_PROJECT_APP]:addProjectApp,
    [DELETE_PROJECT_APP]:deleteProjectApp,
};

const projectApp = (state = initialState,action) =>{
    let nextState = state;
    if(reducers[action.type]){
        nextState = reducers[action.type](state,action);
    }
    return nextState;
}



export default projectApp;