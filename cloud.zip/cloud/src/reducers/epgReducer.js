import {
    SET_PROJECT_EPG_LIST,
    ADD_PROJECT_EPG,
    DELETE_PROJECT_EPG,
    SET_SELECTED_EPG,
    SET_IS_EDIT,
    EDIT_PROJECT_EPG,
} from '../constants/actionTypes';

const initialState = {
    projectEpgList:[],
    selectedEpg:{},
    createNewEpg:{},
    isEdit:false,
}

const setProjectEpg = (state,{payload})=>{
    let projectEpgList = [...payload.projectEpgList];
    state={...state,projectEpgList};
    return state;
}

const addProjectEpg = (state,{payload})=>{
    let projectEpgList = [...state.projectEpgList];
    let currentEpg = payload.epg;
    projectEpgList.push(currentEpg);
    state = {...state,projectEpgList};
    return state;
}

const deleteProjectEpg = (state,{payload})=>{
    let projectEpgList = [...state.projectEpgList];
    let currentEpg = payload.epg;
    projectEpgList=projectEpgList.filter(item=>{
        return item.id!==currentEpg.id;
    })
    state={...state,projectEpgList};
    return state;
}

const setSelectedEpg = (state,{payload})=>{
    let newState = {...state};
    let selectedEpg = {...payload.epg};
    newState={...newState,selectedEpg};
    return newState;
}

const setIsEdit=(state,{payload})=>{
    let isEdit = payload.isEdit;
    state={...state,isEdit};
    return state;
}

const editProjectEpg=(state,{payload})=>{
    let projectEpgList = [...state.projectEpgList];
    let currentEpg = payload.epg;
    projectEpgList=projectEpgList.map(item=>{
        if(item.id === currentEpg.id){
            return {...currentEpg};
        }else{
            return {...item};
        }
    });
    state={...state,projectEpgList};
    return state;
}

const reducers = {
    [SET_PROJECT_EPG_LIST]:setProjectEpg,
    [ADD_PROJECT_EPG]:addProjectEpg,
    [DELETE_PROJECT_EPG]:deleteProjectEpg,
    [SET_SELECTED_EPG]:setSelectedEpg,
    [SET_IS_EDIT]:setIsEdit,
    [EDIT_PROJECT_EPG]:editProjectEpg
};

const projectEpg = (state = initialState,action) =>{
    let nextState = state;
    if(reducers[action.type]){
        nextState = reducers[action.type](state,action);
    }
    return nextState;
}



export default projectEpg;