import {combineReducers} from 'redux-immutable';
import project from './projectReducer';
import market from './markertReducer';
import projectEpg from './epgReducer';
import profile from './profileReducer';
import projectApp from './appReducer';

export default combineReducers({
    project,
    market,
    projectEpg,
    profile,
    projectApp
})
