import {
    SET_MEU_LIST,
    SET_COMPONENT_LIST,
    SET_PROJECT_MEU_LIST,
    ADD_MEU_TO_PROJECT,
    DELETE_PROJECT_MEU,
    UPDATE_PROJECT_MEU
} from '../constants/actionTypes';

const initialState = {
    meuList:[],
    componentList:[],
    projectMeuList:[],
    projectComponentList:[]
}

const setMeuList = (state,{payload})=>{
    let meuList = payload.meuList;
    state = {...state,meuList};
    return state;
}

const setComponentList = (state,{payload})=>{
    let componentList = payload.componentList;
    state = {...state,componentList};
    return state;
}

const setProjectMeuList = (state,{payload})=>{
    let projectMeuList=payload.projectMeuList;
    state={...state,projectMeuList};
    return state;
}

const updateProjectMeu = (state,{payload})=>{
    let currentMeu = payload.meu;
    let projectMeuList=state.projectMeuList;
    projectMeuList=projectMeuList.map(item=>{
        if(item.id===currentMeu.id){
            item={...item,...currentMeu};
        }
        return item;
    })
    state={...state,projectMeuList};
    return state;
}

const addMeuToProject = (state,{payload})=>{
    let projectMeuList = [...state.projectMeuList];
    let addMeu = payload.meu;
    projectMeuList.push(addMeu);
    state={...state,projectMeuList};
    return state;
}

const deleteProjectMeu = (state,{payload})=>{
    let projectMeuList = state.projectMeuList;
    let currentMeu = payload.meu;
    projectMeuList=projectMeuList.filter(item=>{
        return item.id!==currentMeu.id;
    })
    state={...state,projectMeuList};
    return state;
}

const reducers = {
    [SET_MEU_LIST]:setMeuList,
    [SET_COMPONENT_LIST]:setComponentList,
    [SET_PROJECT_MEU_LIST]:setProjectMeuList,
    [ADD_MEU_TO_PROJECT]:addMeuToProject,
    [DELETE_PROJECT_MEU]:deleteProjectMeu,
    [UPDATE_PROJECT_MEU]:updateProjectMeu,
};

const market = (state = initialState,action) =>{
    let nextState = state;
    if(reducers[action.type]){
        nextState = reducers[action.type](state,action);
    }
    return nextState;
}

export default market;