import {
    SET_ENV_PROFILE_LIST,
    ADD_ENV_PROFILE,
    DELETE_ENV_PROFILE,
    EDIT_ENV_PROFILE,
    SET_SELECTED_ENV,
    SET_SELECTED_APP,
    SET_APP_PROFILE_LIST,
    ADD_APP_PROFILE,
    DELETE_APP_PROFILE,
    EDIT_APP_PROFILE,
    SET_IS_ENVIRONMENT_EDIT,
    SET_IS_APP_PROFILE_EDIT,
    UPDATE_APP_PROFILE,
    UPDATE_ENV_PROFILE,
} from '../constants/actionTypes';

// const appProfileData = {
//     "key":1,
//     "id": 1,
//     "envProfileId": 6,
//     "appProfileId": "appProfile001",
//     "appId": "APP-813cf1d1af104d00aba2d64747623a08",
//     "meus": [
//         {
//             "id": "MEU-3210b60f5b994cee8d3a2e9c69d083db",
//             "configs": [
//                 {
//                     "fileName": "config1",
//                     "content": "config: meu_doOne_modify"
//                 }
//             ]
//         },
//         {
//             "id": "MEU-11dc144ea5c04b689c8fa8a68dfc4973"
//         },
//         {
//             "id": "MEU-8a67ca9acacf4ec294e381b72faa17ec",
//             "configs": [
//                 {
//                     "fileName": "config3",
//                     "content": "config: meu_doThree_modify"
//                 }
//             ]
//         }
//     ],
//     "containerMeuMappings": [
//         {
//             "containerId": "CONTAINER1",
//             "meuIds": [
//                 "MEU-a0c7897a2c68476eb028065d31061fa4",
//                 "MEU-19895036ba0a482d85974dff16673eca"
//             ]
//         },
//         {
//             "containerId": "CONTAINER2",
//             "meuIds": [
//                 "MEU-bb15cb624e0b487e99f77549d203eaa7"
//             ]
//         }
//     ],
//     "createTime": "2018-04-27 16:02:30",
//     "updateTime": "2018-04-27 16:13:37"
// };
    



const initialState = {
    appProfileList: [],
    envProfileList: [],
    selectedAppProfile: null,
    selectedEnvProfile: null,
    isEnvironmentEdit: false,
    isAppEdit: false,
}

const setEnvProfileList = (state, { payload }) => {
    let envProfileList = [...payload.envProfileList];
    let newState = { ...state, envProfileList };
    return newState;
}

const setAppProfileList = (state, { payload }) => {
    let appProfileList = [...payload.appProfileList];
    let newState = { ...state, appProfileList };
    return newState;
}

const setIsEnvironmnetEdit = (state, { payload }) => {
    let isEnvironmentEdit = payload.isEdit;
    let newState = { ...state, isEnvironmentEdit };
    return newState;
}

const setIsAppProfileEdit = (state, { payload }) => {
    let isAppEdit = payload.isEdit;
    let newState = { ...state, isAppEdit };
    return newState;
}

const setSelectedEnv = (state, { payload }) => {
    let selectedEnvProfile = { ...state.selectedEnvProfile };
    let newSelectedEnvProfile = payload.profile;
    if (!selectedEnvProfile && newSelectedEnvProfile) {
        selectedEnvProfile = { ...newSelectedEnvProfile };
    } else if (selectedEnvProfile && newSelectedEnvProfile) {
        selectedEnvProfile = { ...selectedEnvProfile, ...newSelectedEnvProfile }
    } else if (selectedEnvProfile && !newSelectedEnvProfile) {
        selectedEnvProfile = newSelectedEnvProfile;
    }
    let newState = { ...state, selectedEnvProfile };
    return newState;
}

const setSelectedApp = (state, { payload }) => {
    let selectedAppProfile = { ...state.selectedAppProfile };
    let newSelectedAppProfile = payload.profile;
    if (!selectedAppProfile && newSelectedAppProfile) {
        selectedAppProfile = newSelectedAppProfile;
    } else if (selectedAppProfile && newSelectedAppProfile) {
        selectedAppProfile = { ...selectedAppProfile, ...newSelectedAppProfile }
    } else if (selectedAppProfile && !newSelectedAppProfile) {
        selectedAppProfile = newSelectedAppProfile;
    }
    let newState = { ...state, selectedAppProfile };
    return newState;
}

const addEnvProfile = (state, { payload }) => {
    let envProfileList = [...state.envProfileList];
    let currentProfile = payload.profile;
    envProfileList.push(currentProfile);
    let newState = { ...state, envProfileList };
    return newState;
}

const addAppProfile = (state, { payload }) => {
    let appProfileList = [...state.appProfileList];
    let currentProfile = payload.profile;
    appProfileList.push(currentProfile);
    let newState = { ...state, appProfileList };
    return newState;
}

const deleteEnvProfile = (state, { payload }) => {
    let envProfileList = [...state.envProfileList];
    let currentProfile = payload.profile;
    envProfileList = envProfileList.filter(item => {
        return item.id !== currentProfile.id;
    });
    let newState = { ...state, envProfileList };
    return newState;
}

const deleteAppProfile = (state, { payload }) => {
    let appProfileList = [...state.appProfileList];
    let currentProfile = payload.profile;
    appProfileList = appProfileList.filter(item => {
        return item.id !== currentProfile.id;
    });
    let newState = { ...state, appProfileList };
    return newState;
}

const updateEnvProfile = (state, { payload }) => {
    let envProfileList = [...state.envProfileList];
    let currentProfile = payload.profile;
    envProfileList = envProfileList.map(item => {
        if (item.id === currentProfile.id) {
            return currentProfile;
        } else {
            return item;
        }
    });
    let newState = { ...state, envProfileList };
    return newState;
}

const updateAppProfile = (state, { payload }) => {
    let appProfileList = [...state.appProfileList];
    let currentProfile = payload.profile;
    appProfileList = appProfileList.map(item => {
        if (item.id === currentProfile.id) {
            return currentProfile;
        } else {
            return item;
        }
    });
    let newState = { ...state, appProfileList };
    return newState;
}

const reducers = {
    [SET_ENV_PROFILE_LIST]: setEnvProfileList,
    [SET_APP_PROFILE_LIST]: setAppProfileList,
    [SET_IS_ENVIRONMENT_EDIT]: setIsEnvironmnetEdit,
    [SET_IS_APP_PROFILE_EDIT]: setIsAppProfileEdit,
    [SET_SELECTED_ENV]: setSelectedEnv,
    [SET_SELECTED_APP]: setSelectedApp,
    [ADD_ENV_PROFILE]: addEnvProfile,
    [ADD_APP_PROFILE]: addAppProfile,
    [DELETE_ENV_PROFILE]: deleteEnvProfile,
    [DELETE_APP_PROFILE]: deleteAppProfile,
    [UPDATE_APP_PROFILE]: updateAppProfile,
    [UPDATE_ENV_PROFILE]:updateEnvProfile,
};

const profile = (state = initialState, action) => {
    let nextState = state;
    if (reducers[action.type]) {
        nextState = reducers[action.type](state, action);
    }
    return nextState;
}

export default profile;