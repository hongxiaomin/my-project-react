import {
    GET_PROJECT,
    SET_SELECTED_PROJECT,
    ADD_PROJECT,
    DELETE_PROJECT,
    UPDATE_PROJECT,
} from '../constants/actionTypes';

const initialState = {
    projectList:[],
    selectedProject:null,
};

const getProject = (state,{payload})=>{
    let projectList = state.projectList;
    let newProjectList = payload.projectList;
    if(newProjectList.length>0){
        state = {...state,projectList:newProjectList};
    }
    return state;
}

const setSelectedProject = (state,{payload})=>{
    let selectedProject = payload.selectedProject;
    state = {...state,selectedProject}
    return state;
}

const addProject = (state,{payload})=>{
    let projectList = state.projectList;
    projectList.unshift(payload.addProjectData);
    state = {...state,projectList};
    return state;
}

const deleteProject = (state,{payload})=>{
    let projectList = state.projectList;
    let deleteProjectList = payload.deleteProjectList;
    for(let i=0;i<deleteProjectList.length;i++){
        projectList=projectList.filter(item=>{
            return item.id!==deleteProjectList[i].id;
        })
    }
    state={...state,projectList};
    return state;
}

const updateProject = (state,{payload})=>{
    let projectList = state.projectList;
    let updataData = payload.updateData;
    projectList = projectList.map(item=>{
        if(item.id===updataData.id){
            return {...item,...updataData};
        }
        return item;
    })
    state={...state,projectList};
    return state;
}

const reducers = {
    [GET_PROJECT]:getProject,
    [SET_SELECTED_PROJECT]:setSelectedProject,
    [ADD_PROJECT]:addProject,
    [DELETE_PROJECT]:deleteProject,
    [UPDATE_PROJECT]:updateProject,
}

const project = (state = initialState,action) =>{
    let nextState = state;
    if(reducers[action.type]){
        nextState = reducers[action.type](state,action);
    }
    return nextState;
}

export default project;