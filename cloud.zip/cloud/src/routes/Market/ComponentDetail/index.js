import React,{Component} from 'react';
import {connect} from 'react-redux';
import {toJS} from 'immutable';
import Page from '../../../components/Page';
import Bread from '../../../components/Bread';
import ComponentItem from '../../../components/ComponentItem';
import CloudModal from '../../../components/CloudModal';
import MeuInfo from '../../../components/MeuInfo';
import {
    setComponentList
} from '../../../actions';
import { breadMap} from './config';
import {
    getComponentData,
    handleComponentClick,
    handleAddComponentToProject,
    handleComponentDetail,

} from '../fn';
import '../style.less';
 
class ComponentDetail extends Component{
    constructor(props){
        super(props);
        this.getComponentData=getComponentData(this);
        this.handleComponentClick=handleComponentClick(this);
        this.handleAddComponentToProject=handleAddComponentToProject(this);
        this.handleComponentDetail=handleComponentDetail(this);
        this.state={
            componentVisible:false,
            componentInfo:null
        }
    }

    componentDidMount=()=>{

        if(this.props.componentList.length===0){
            this.getComponentData((data)=>{
                this.props.setComponentList(data);
            });
        }
    }

    render(){
        return (
            <Page>
                <Bread breadMap={breadMap} />
                <div className="card_section">
                    {
                        this.props.componentList.map(item=>{
                            return <ComponentItem 
                            data={item} 
                            key={item.key}
                            handleComponentClick={this.handleComponentClick(item)}
                            handleAddComponentToProject = {this.handleAddComponentToProject(item)}
                            />
                        })
                    }
                </div>
                <CloudModal
                    title="Component Detail"
                    visible={this.state.componentVisible}
                    onOk={this.handleComponentDetail}
                    onCancel={this.handleComponentDetail}
                    width="860px"
                >
                    <MeuInfo data={this.state.componentInfo} dataType="component"/>
                </CloudModal>
            </Page>
        )
    }
}

const mapStateToProps = (state) =>{
    state=state.toJS();
    return {
        componentList: state.market.componentList
    }
};

const mapDispatchToProps = (dispatch)=>({
    setComponentList:(data)=>{
      dispatch(setComponentList({
        componentList:data
      }))
    }
  })

export default connect(mapStateToProps,mapDispatchToProps)(ComponentDetail);