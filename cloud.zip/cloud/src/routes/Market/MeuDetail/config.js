export const breadMap = [
    {
        path:'',
        name:'Index'
    },
    {
        path:'/',
        name:'Market'
    },
    {
        path:'',
        name:'Meu List'
    }
];
