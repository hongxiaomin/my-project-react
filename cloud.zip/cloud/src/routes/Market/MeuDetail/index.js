import React,{Component} from 'react';
import {connect} from 'react-redux';
import{Modal,Button} from 'antd';
import {toJS} from 'immutable';
import {Link} from 'react-router-dom';
import Page from '../../../components/Page';
import Bread from '../../../components/Bread';
import MeuItem from '../../../components/MeuItem';
import MeuInfo from '../../../components/MeuInfo';
import CloudModal from '../../../components/CloudModal';
import {
    setMeuList,
    addMeuToProject,
    updateProjectMeu
} from '../../../actions';
import { breadMap} from './config';
import {
    getMeuData,
    handleClickMeu,
    handleAddMeuToProject,
    handleMeuDetail,
    postProjectMeu,
    setAlertVisible
} from '../fn';
import '../style.less';
 
class MeuDetail extends Component{
    constructor(props){
        super(props);
        this.getMeuData=getMeuData(this);
        this.handleClickMeu=handleClickMeu(this);
        this.handleAddMeuToProject=handleAddMeuToProject(this);
        this.handleMeuDetail=handleMeuDetail(this);
        this.postProjectMeu=postProjectMeu(this);
        this.setAlertVisible=setAlertVisible(this);
        this.state={
            meuVisible:false,
            meuInfo:null,
            alertVisible:false
        }
    }

    componentDidMount=()=>{
        if(this.props.meuList.length===0){
            this.getMeuData((data)=>{
                this.props.setMeuList(data);
            });
        }
    }

    render(){
        return (
            <Page>
                <Bread breadMap={breadMap} />
                <div className="card_section">
                    {
                        this.props.meuList.map(item=>{
                            let exist=false;
                            let hasMeu = this.props.projectMeuList.filter(meu=>{
                                return meu.id===item.id
                            });
                            if(hasMeu.length>0){
                                exist=true;
                            }
                            return <MeuItem 
                                data={item} 
                                key={item.key} 
                                handleClickMeu={this.handleClickMeu(item)}
                                handleAddMeuToProject={this.handleAddMeuToProject(item)}
                                exist={exist}
                                meuType="1"
                                />
                        })
                    }
                </div>
                <CloudModal
                    title="MEU Detail"
                    visible={this.state.meuVisible}
                    onOk={this.handleMeuDetail}
                    onCancel={this.handleMeuDetail}
                    width="860px"
                >
                    <MeuInfo data={this.state.meuInfo} dataType="meu"/>
                </CloudModal>
                <Modal
                    title="Warning"
                    width="560px"
                    visible={this.state.alertVisible}
                    onCancel={this.setAlertVisible}
                    footer={null}
                    destroyOnClose={true}
                >
                    <p>Must select a project before adding menu to project</p>
                    <Link to="/project/create">
                        <Button type="primary">Create</Button>
                    </Link>
                </Modal>
            </Page>
        )
    }
}

const mapStateToProps = (state) =>{
    state=state.toJS();
    return {
        meuList: state.market.meuList,
        projectMeuList:state.market.projectMeuList,
        selectedProject:state.project.selectedProject
    }
};

const mapDispatchToProps = (dispatch)=>({
    setMeuList:(data)=>{
      dispatch(setMeuList({
        meuList:data
      }))
    },
    addMeuToProject:(data)=>{
        dispatch(addMeuToProject({
            meu:data
        }))
    }
  })

export default connect(mapStateToProps,mapDispatchToProps)(MeuDetail);