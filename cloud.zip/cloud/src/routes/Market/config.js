import {SERVER_IP} from '../../constants/Config';
export const getMeuUrl = `${SERVER_IP}/cloudServer/marketplace/meu`;
export const getComponentUrl = `${SERVER_IP}/cloudServer/component`;
export const postProjectMeuUrl = `${SERVER_IP}/cloudServer/project/meu`
export const breadMap = [
    {
        path:'',
        name:'Index'
    },
    {
        path:'',
        name:'Market'
    }
];
