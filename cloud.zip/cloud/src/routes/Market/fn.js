import request from '../../utils/fetchData';
import {message} from 'antd';
import {getMeuUrl,getComponentUrl,postProjectMeuUrl} from './config';

export const getMeuData = _this=>async(cb)=>{
    let response = await request(getMeuUrl);
    if(response.message.code===0){
        let data=response.message.rows;
        let newData = data.map(item=>{
            let id = `${item.group}/${item.name}/${item.version}`;
            let key = id;

            return {...item,key,id};
        })
        cb(newData);
    }else{
        message.error(response.message.message);
    }
}

export const getComponentData = _this=>async(cb)=>{
    let response = await request(getComponentUrl);
    if(response.message.code===0){
        let data = response.message.rows;
        let newData = data.map(item=>{
            let key = item.componentName;
            return {...item,key};
        })
        cb(newData);
    }else{
        message.error(response.message.message);
    }
}

export const handleMeuDetail=_this=>()=>{
    _this.setState({
        meuVisible:false,
    })
}

export const handleComponentDetail=_this=>()=>{
    _this.setState({
        componentVisible:false,
    })
}

export const setAlertVisible = _this=>()=>{
    _this.setState({
        alertVisible:false
    })
}

export const handleClickMeu=_this=>(data)=>()=>{
    _this.setState({
        meuInfo:data,
        meuVisible:true,
    })
}

export const  handleAddMeuToProject=_this=>(data)=>(e)=>{
    e.stopPropagation();
    let selectedProject=_this.props.selectedProject;
    console.log('handleAddMeuToProject',selectedProject);
    if(!selectedProject){
        _this.setState({
            alertVisible:true
        })
    }else{
        let postData={
            projectId:selectedProject.id,
            meus:[{
                    group:data.group,
                    name:data.name,
                    version:data.version
                }]
        }
        
        _this.postProjectMeu(postData,()=>{
            _this.props.addMeuToProject(data);
        })
    }
}

export const postProjectMeu = _this =>async(postData,cb)=>{
    let response = await request(postProjectMeuUrl,{
        method: 'POST',
        data: JSON.stringify(postData),
        contentType: 'raw',
        headers: new Headers(),
    });
    if(response.message.code===0){
        message.success('Add Meu to Project Success!');
        cb();
    }
}

export const handleComponentClick=_this=>(data)=>()=>{
    _this.setState({
        componentVisible:true,
        componentInfo:data
    })
}

export const handleAddComponentToProject=_this=>(data)=>(e)=>{
    e.stopPropagation();
}


