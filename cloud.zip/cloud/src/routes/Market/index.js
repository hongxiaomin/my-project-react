import React,{Component} from 'react';
import {connect} from 'react-redux';
import {toJS} from 'immutable';
import {Card,Modal,Button} from 'antd';
import {Link} from 'react-router-dom';
import Page from '../../components/Page';
import Bread from '../../components/Bread';
import MeuItem from '../../components/MeuItem';
import ComponentItem from '../../components/ComponentItem';
import CloudModal from '../../components/CloudModal';
import MeuInfo from '../../components/MeuInfo';
import {
    setMeuList,
    setComponentList,
    addMeuToProject,
    updateProjectMeu
} from '../../actions';
import { breadMap} from './config';
import {
    getMeuData,
    getComponentData,
    handleMeuDetail,
    handleComponentDetail,
    handleClickMeu,
    handleAddMeuToProject,
    handleComponentClick,
    handleAddComponentToProject,
    postProjectMeu,
    setAlertVisible,

} from './fn';
 
class Market extends Component{
    constructor(props){
        super(props);
        this.getMeuData=getMeuData(this);
        this.getComponentData=getComponentData(this);
        this.handleMeuDetail=handleMeuDetail(this);
        this.handleComponentDetail=handleComponentDetail(this);
        this.handleClickMeu=handleClickMeu(this);
        this.handleAddMeuToProject=handleAddMeuToProject(this);
        this.handleComponentClick=handleComponentClick(this);
        this.handleAddComponentToProject=handleAddComponentToProject(this);
        this.postProjectMeu=postProjectMeu(this);
        this.setAlertVisible=setAlertVisible(this);

        this.state={
            meuVisible:false,
            meuInfo:null,
            componentVisible:false,
            componentInfo:null,
            alertVisible:false
        }
    }

    componentDidMount=()=>{
        if(this.props.meuList.length===0){
            this.getMeuData((data)=>{
                this.props.setMeuList(data);
            });
        }

        if(this.props.componentList.length===0){
            this.getComponentData((data)=>{
                this.props.setComponentList(data);
            });
        }
    }

    render(){
        let meuList = this.props.meuList;
        let newMeuList = meuList.length<4?meuList:meuList.slice(0,4);
        let componentList = this.props.componentList;
        let newComponentList = componentList.length<4?componentList:componentList.slice(0,4);
        return (
            <Page>
                <Bread breadMap={breadMap} />
                <Card 
                    title="MEU"
                    extra={<Link to="/market/meu">more</Link>}
                    style={{marginTop:'30px',background:'rgba(0,0,0,0.045)'}}
                >
                    <div className="card_section">
                        {
                            newMeuList.map(item=>{
                                let exist=false;
                                let hasMeu = this.props.projectMeuList.filter(meu=>{
                                    return meu.id===item.id
                                });
                                if(hasMeu.length>0){
                                    exist=true;
                                }
                                return <MeuItem 
                                data={item} 
                                key={item.key}
                                handleClickMeu={this.handleClickMeu(item)}
                                handleAddMeuToProject={this.handleAddMeuToProject(item)}
                                projectMeuList={this.props.projectMeuList}
                                exist={exist}
                                meuType="1"
                                />
                            })
                        }
                    </div>
                </Card>
                <Card 
                    title="Component"
                    extra={<Link to="/market/component">more</Link>}
                    style={{marginTop:'50px',background:'rgba(0,0,0,0.045)'}}
                >
                    <div className="card_section">
                        {
                            newComponentList.map(item=>{
                                return <ComponentItem 
                                data={item} 
                                key={item.key}
                                handleComponentClick={this.handleComponentClick(item)}
                                handleAddComponentToProject={this.handleAddComponentToProject(item)}
                                />
                            })
                        }
                    </div>
                </Card>
                <CloudModal
                    title="MEU Detail"
                    visible={this.state.meuVisible}
                    onOk={this.handleMeuDetail}
                    onCancel={this.handleMeuDetail}
                    width="860px"
                >
                    <MeuInfo data={this.state.meuInfo} dataType="meu"/>
                </CloudModal>

                <CloudModal
                    title="Component Detail"
                    visible={this.state.componentVisible}
                    onOk={this.handleComponentDetail}
                    onCancel={this.handleComponentDetail}
                    width="860px"
                >
                    <MeuInfo data={this.state.componentInfo} dataType="component"/>
                </CloudModal>

                <Modal
                    title="Warning"
                    width="560px"
                    visible={this.state.alertVisible}
                    onCancel={this.setAlertVisible}
                    footer={null}
                    destroyOnClose={true}
                >
                    <p>Must select a project before adding menu to project</p>
                    <Link to="/project/create">
                        <Button type="primary">Create</Button>
                    </Link>
                </Modal>
            </Page>
        )
    }
}

const mapStateToProps = (state) =>{
    state=state.toJS();
    return {
        meuList: state.market.meuList,
        componentList: state.market.componentList,
        selectedProject:state.project.selectedProject,
        projectMeuList:state.market.projectMeuList,
    }
};

const mapDispatchToProps = (dispatch)=>({
    setMeuList:(data)=>{
      dispatch(setMeuList({
        meuList:data
      }))
    },
    setComponentList:(data)=>{
      dispatch(setComponentList({
        componentList:data
      }))
    },
    addMeuToProject:(data)=>{
        dispatch(addMeuToProject({
            meu:data
        }))
    }
  })

export default connect(mapStateToProps,mapDispatchToProps)(Market);