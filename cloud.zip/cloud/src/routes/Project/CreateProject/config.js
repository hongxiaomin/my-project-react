import {SERVER_IP} from '../../../constants/Config';

export const postProjectUrl = `${SERVER_IP}/cloudServer/project`;
export const getProjectUrl = `${SERVER_IP}/cloudServer/project`;