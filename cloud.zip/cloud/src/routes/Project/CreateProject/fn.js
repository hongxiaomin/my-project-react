import {message} from 'antd';
import request from '../../../utils/fetchData';
import { postProjectUrl,getProjectUrl } from './config';

export const changeName=_this=>(e)=>{
    _this.setState({
        name:e.target.value
    })
}

export const changeDescription=_this=>(e)=>{
    _this.setState({
        description:e.target.value
    })
}

export const submitProject = _this=>() =>{
    const name=_this.state.name?_this.state.name.trim():'';
    const description=_this.state.description?_this.state.description.trim():'';
    if(!name||!description){
        message.error('Input available name or description!');
        return;
    }
    let projectData={
        name,
        description
    };
    let selectedProjectId = localStorage.getItem('selectedProjectId');
    _this.postProject(projectData,(data)=>{
        _this.getProjectData(getData=>{
            let selectedProject = getData.filter(item=>{
                return item.id === data.id;
            })[0];
            if(!selectedProjectId){
                localStorage.setItem('selectedProjectId',selectedProject.id);
                _this.props.setSelectedProject(selectedProject);
            }
            _this.props.getProject(getData);
            _this.props.history.goBack();
        })
        
    })

}

export const postProject = _this =>async(postData,cb)=>{
    let response = await request(postProjectUrl,{
        method: 'POST',
        data: JSON.stringify(postData),
        contentType: 'raw',
        headers: new Headers(),
    });
    if(response.message.code===0){
        message.success('Create Project Success!');
        cb(response.message.rows);
    }else{
        message.error(response.message.message);
    }
}

export const cancelProject =_this=>()=>{
    _this.props.history.goBack();
}

export const getProjectData = _this=>async(cb)=>{
    let response =await request(getProjectUrl);
    if(response.message.code===0){
        let data = response.message.rows;
        data = data.map(item=>{
            let key = item.id;
            return {...item,key};
        })
        cb(data);
    }else{
        message.error(response.message.message);
    }
}

