import React, { Component } from 'react';
import { Divider, Input, Button,Icon } from 'antd';
import {withRouter} from 'react-router-dom';
import {connect} from 'react-redux';
import Page from '../../../components/Page';
import {
    changeName,
    changeDescription,
    submitProject,
    postProject,
    cancelProject,
    getProjectData
} from './fn';
import { 
    addProject,
    setSelectedProject,
    getProject,
} from '../../../actions';
import './style.less';

class CreateProject extends Component {
    constructor(props) {
        super(props);
        this.changeName=changeName(this);
        this.changeDescription=changeDescription(this);
        this.submitProject=submitProject(this);
        this.postProject=postProject(this);
        this.cancelProject=cancelProject(this);
        this.getProjectData=getProjectData(this);

        this.state = {
            name:'',
            description:'',
        }
    }
    render() {
        return (
            <Page>
                <h3>
                    Create New Project
                </h3>
                <Divider />
                <div className="input_box">
                    <div className="input_item">
                        <label>Project Name:</label>
                        <Input style={{ width: '300px' }}  onChange={this.changeName} value={this.state.name}/>
                    </div>
                    <div className="input_item">
                        <label>Project Description:</label>
                        <Input style={{ width: '300px' }} onChange={this.changeDescription} value={this.state.description}/>
                    </div>
                </div>
                <div className="btn_group">
                    <Button type="primary" onClick={this.submitProject}>OK</Button>
                    <Button onClick={this.cancelProject}>Cancel</Button>
                </div>

            </Page>
        )

    }
}

CreateProject=withRouter(CreateProject)

const mapStateToProps=(state)=>({

});

const mapDispatchTOProps = (dispatch)=>({
    getProject: (data) => {
        dispatch(getProject({
            projectList: data
        }))
    },
    addProject:(data)=>{
      dispatch(addProject({
        addProjectData:data
      }))
    },
    setSelectedProject:(data)=>{
        dispatch(setSelectedProject({
            selectedProject:data
        }))
    }
  });

export default connect(mapStateToProps,mapDispatchTOProps)(CreateProject)