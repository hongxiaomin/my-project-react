import { SERVER_IP } from '../../../constants/Config';
export const getProjectUrl = `${SERVER_IP}/cloudServer/project`;
export const deleteProjectUrl = `${SERVER_IP}/cloudServer/project`;
export const putProjectUrl = `${SERVER_IP}/cloudServer/project`;