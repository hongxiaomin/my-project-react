import {message} from 'antd';
import {getProjectUrl,deleteProjectUrl,putProjectUrl} from './config';
import request from '../../../utils/fetchData';

export const getProjectData = _this=>async(cb)=>{
    let response =await request(getProjectUrl);
    if(response.message.code===0){
        cb(response.message.rows);
    }else{
        message.error(response.message.message);
    }
}

export const goBackPage = _this=>()=>{
    _this.props.history.goBack();
}

export const addProject=_this=>()=>{
    _this.props.history.push('/project/create');
}

export const   changeSelectedProject=_this=>(selectedRowKeys)=>{
    let isDelete = true;
    if(selectedRowKeys.length>0){
        isDelete=false
    }
    _this.setState({
        selectedRowKeys,
        isDelete
    })
}

export const handleDeleteProject = _this=>()=>{
    let selectedProject = _this.state.selectedProject;
    let deleteData=[selectedProject];
    _this.handleDeleteData(selectedProject,()=>{
        _this.props.deleteProject(deleteData);
        let selectedProjectId = localStorage.getItem('selectedProjectId');
        if(selectedProjectId==selectedProject.id){
            let projectList = _this.props.projectList;
            if(projectList.length>0){
                let newSelectedProject = projectList[0];
                _this.props.setSelectedProject(newSelectedProject);
                localStorage.setItem('selectedProjectId',newSelectedProject.id);
            }else{
                localStorage.removeItem('selectedProjectId');
                _this.props.setSelectedProject(null);
            }
        }
    })
}

export const handleDeleteData = _this=>async(data,cb)=>{
    const response = await request(deleteProjectUrl,{
        method: 'DELETE',
        param: {id:data.id},
        contentType: 'x-www-form-urlencode',
        headers: new Headers(),
    });
    if(response.message.code===0){
        message.success(`Delete ${data.name} Success!`);
        cb();
        return;
    }else{
        message.error(response.message.message);
        return;
    }
}

export const handleSetProject=_this=>(record)=>(visible)=>{
    if(visible){
        _this.setState({
            selectedProject:record
        })
    }
}

export const handleUpdateProject = _this=>async(putData,cb)=>{
    const response = await request(putProjectUrl,{
        method: 'PUT',
        data: JSON.stringify(putData),
        contentType: 'raw',
        headers: new Headers(),
    });
    if(response.message.code===0){
        message.success(`Update ${putData.name} Success!`)
        cb(response.message.rows);
    }else{
        message.error(response.message.message);
    }
}

export const edit =_this=> () => {
    let target = _this.state.selectedProject;
    if(target){
        target.editable=true;
        target.editName=target.name;
        target.editDescription=target.description;
        _this.props.updateProject(target);
    }
}

export const  save=_this=>(record)=>{
    let target = _this.props.projectList.filter(item=>{
        return item.id===record.id;
    })[0];
    if(target){
        if(!target.editName||!target.editDescription){
            message.error('Input available name or description!');
            return;
        }
        _this.handleUpdateProject({
            id:target.id,
            name:target.editName,
            description:target.editDescription
        },(data)=>{
            delete target.editable;
            delete target.editName;
            delete target.editDescription;
            _this.props.updateProject(data);
            _this.cacheData=_this.props.projectList.map(item=>({...item}));
            let selectedProjectId = localStorage.getItem('selectedProjectId');
            if(selectedProjectId==data.id){
                _this.props.setSelectedProject(data);
            }
        })
       
    }
}

export const cancel=_this=>(record)=>{
    let target = record;
    delete target.editable;
    delete target.editName;
    delete target.editDescription;
    _this.props.updateProject(target);
}



export const  handleChange=_this=>(value,record,column)=>{
    const target = record;
    if(column==="name"){
        target["editName"]=value.trim();
    }else if(column==="description"){
        target["editDescription"]=value.trim();
    }
    _this.props.updateProject(target);
}