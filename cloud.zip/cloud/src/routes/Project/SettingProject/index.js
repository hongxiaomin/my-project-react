import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { Divider, Input, Button, Icon, Menu, Dropdown, Table, Popconfirm } from 'antd';
import { toJS } from 'immutable';
import Page from '../../../components/Page';
import { getProject, deleteProject, updateProject,setSelectedProject } from '../../../actions';
import {
    getProjectData,
    goBackPage,
    addProject,
    changeSelectedProject,
    handleDeleteProject,
    handleSetProject,
    handleDeleteData,
    handleUpdateProject,
    edit,
    save,
    handleChange,
    cancel
} from './fn';
import './style.less';
const Search = Input.Search;

const EditableCell = ({editable,value,onchange})=>{
    return (
        <div>
            {
                editable?
                <Input style={{margin:'-5px 0'}} value={value} onChange={e=>onchange(e.target.value)}/>:value
            }
        </div>
    )
}


class SettingProject extends Component {
    constructor(props) {
        super(props);
        this.getProjectData = getProjectData(this);
        this.goBackPage = goBackPage(this);
        this.addProject = addProject(this);
        this.changeSelectedProject = changeSelectedProject(this);
        this.handleDeleteProject = handleDeleteProject(this);
        this.handleSetProject = handleSetProject(this);
        this.handleDeleteData = handleDeleteData(this);
        this.handleUpdateProject=handleUpdateProject(this);
        this.edit=edit(this);
        this.save=save(this);
        this.handleChange=handleChange(this);
        this.cancel=cancel(this);

        this.state = {
            editingKey: '',
            selectedRowKeys: [],
            isDelete: true,
            selectedProject: null,

        };
        this.cacheData=[];
        this.columns = [{
            title: 'ID',
            dataIndex: 'id',
            key: 'id',
            width: '5%',
        }, {
            title: 'Name',
            dataIndex: 'name',
            key: 'name',
            width: '20%',
            render:(text,record)=>this.renderColumns(text,record,'name'),
        }, {
            title: 'Description',
            dataIndex: 'description',
            key: 'description',
            width: '20%',
            render:(text,record)=>this.renderColumns(text,record,'description'),
        }, {
            title: 'Create Time',
            dataIndex: 'createTime',
            key: 'createTime',
            width: '15%',
        }, {
            title: 'Update Time',
            dataIndex: 'updateTime',
            key: 'updateTime',
            width: '15%',
        }, {
            title: '',
            dataIndex: '',
            width: '25%',
            render: (text, record) => {
                const {editable} = record;
                return (<div className="editable-row-operations">{
                    editable ? (
                        <span>
                            <Button
                                type="primary"
                                onClick={() => {
                                    this.save(record);
                                }}
                            >
                                {/* <Icon type="ok" /> */}
                                Save
                            </Button>
                            <Popconfirm
                                title="Sure to Cancel?"
                                onConfirm={() => {
                                    this.cancel(record);
                                }}
                            >
                                <Button>
                                    {/* <Icon type="cancel" /> */}
                                    Cancel
                                </Button>
                            </Popconfirm>
                        </span>
                    ) : (
                            <Dropdown overlay={this.toolMenu} onVisibleChange={this.handleSetProject(record)}>
                                <Icon type="tool" style={{ fontSize: '20px', color: '#0086db', margin: '5px 0 0', cursor: 'pointer' }} />
                            </Dropdown>
                        )
                }</div>)
            }
        }];

    }

    toolMenu = (
        <Menu onClick={({ item, key }) => {
            if (key === 'delete') {
                this.handleDeleteProject();
            } else if (key === 'edit') {
                this.edit();
            }
        }}>
            <Menu.Item key="delete">
                <Icon type="delete" />
            </Menu.Item>
            <Menu.Item key="edit">
                <Icon type="edit" />
            </Menu.Item>
        </Menu>
    )

   renderColumns=(text,record,column)=>{
       let value ='';
       if(column==="name"){
           value = record.editable?record.editName:text;
       }else if(column === "description"){
           value = record.editable?record.editDescription:text;
       }
        return (
            <EditableCell
                editable={record.editable}
                value={value}
                onchange={value=>this.handleChange(value,record,column)}
            />
        )
    }
    

   


    componentDidMount = () => {
        this.getProjectData(data => {
            data = data.map(item => {
                let key = item.id;
                return { ...item, key };
            })
            this.props.getProject(data);
            this.cacheData=data.map(item=>({...item}));
        })
    }

    render() {
        return (
            <Page>
                <div className="section_top">
                    <Icon type="left" style={{ fontSize: '20px', color: '#0086db', margin: '5px 0 0', cursor: 'pointer' }} onClick={this.goBackPage} />
                    <h3>Project Management</h3>
                    {/* <Button type="primary" onClick={this.addProject}>
                        <Icon type="plus"/>
                    </Button>
                    <Button type="danger" disabled={this.state.isDelete}>
                        <Icon type="delete"/>
                    </Button> */}
                </div>
                <Divider />
                <Search
                    placeholder="input search text"
                    onSearch={this.searchProject}
                    enterButton
                    size="large"
                    style={{ width: '40%', marginBottom: '50px' }}
                />
                <div>
                    <Table
                        columns={this.columns}
                        dataSource={this.props.projectList}
                        bordered
                    />
                </div>
            </Page>
        )
    }
}


SettingProject = withRouter(SettingProject);

const mapStateToProps = (state) => {
    state = state.toJS();
    return {
        projectList: state.project.projectList,
        selectedProject:state.project.selectedProject
    }
};

const mapDispatchToProps = (dispatch) => ({
    getProject: (data) => {
        dispatch(getProject({
            projectList: data
        }))
    },
    deleteProject: (data) => {
        dispatch(deleteProject({
            deleteProjectList: data
        }))
    },
    updateProject: (data) => {
        dispatch(updateProject({
            updateData: data
        }))
    },
    setSelectedProject:(data)=>{
        dispatch(setSelectedProject({
            selectedProject:data
        }))
    }
})

export default connect(mapStateToProps, mapDispatchToProps)(SettingProject);