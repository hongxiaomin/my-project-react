import {SERVER_IP} from '../../../../constants/Config';

export const postAppUrl = `${SERVER_IP}/cloudServer/app`;
export const putAppUrl = `${SERVER_IP}/cloudServer/app`;