import {message} from 'antd';
import request from '../../../../utils/fetchData';
import {
    postAppUrl,
    putAppUrl,
} from './config';

export const changeName=_this=>(e)=>{
    let value = e.target.value.trim();
    _this.setState({
        appName:value
    })
}

export const changeDesc=_this=>(e)=>{
    let value = e.target.value.trim();
    _this.setState({
        appDesc:value
    })
}

export const changeSelectedEpg=_this=>(checkedValues)=>{
    _this.setState({
        selectedEpgId:checkedValues
    })
}

export const submitApp=_this=>()=>{
    const {appName,appDesc,selectedEpgId} = _this.state;
    if(!appName||selectedEpgId.length===0){
        message.error('Input available Name Or EPG！');
        return;
    }
    
    const currentApp = {
        name:appName,
        description:appDesc,
        epgs:selectedEpgId
    };

    if(_this.props.isEdit){
        let selectedApp = _this.props.selectedApp;
        currentApp["id"] = selectedApp.id;
        _this.putAppData(currentApp,(data)=>{
            _this.props.editProjectApp(data);
            _this.props.setSelecteProjectdApp(null);
            _this.props.showCreate(false);
        })

    }else{
        currentApp["projectId"]=_this.props.selectedProject.id;
        _this.postAppData(currentApp,(data)=>{
            _this.props.addProjectApp(data);
            _this.props.setSelecteProjectdApp(null);
            _this.props.showCreate(false);
        })
    }
}

export const postAppData = _this=>async(postData,cb)=>{
    let response = await request(postAppUrl,{
        method:'POST',
        data:JSON.stringify(postData),
        contentType:'raw',
        headers:new Headers(),
    });
    if(response.message.code===0){
        message.success(`Create App ${postData.name} Success!`);
        let data = response.message.rows;
        let key = data.id;
        data = {...data,key};
        cb(data);
    }else{
        message.error(response.message.message);
    }
}

export const putAppData = _this =>async(putData,cb)=>{
    let response = await request(putAppUrl,{
        method:'PUT',
        data:JSON.stringify(putData),
        contentType:'raw',
        headers:new Headers(),
    });
    if(response.message.code===0){
        message.success(`Update App ${putData.name} Success!`);
        let data = response.message.rows;
        let key = data.id;
        data = {...data,key};
        cb(data);
    }else{
        message.error(response.message.message);
    }
}

export const cancelAppCreate=_this=>()=>{
    _this.props.setSelecteProjectdApp(null);
    _this.props.showCreate(false);
}