import React, { Component } from 'react';
import { connect } from 'react-redux';
import { toJS } from 'immutable';
import { Card, Button, Input, List, Checkbox, message } from 'antd';
import {Prompt} from 'react-router-dom';
import {
    setSelecteProjectdApp,
    editProjectApp,
    addProjectApp,
} from '../../../../actions';
import {
    changeName,
    changeDesc,
    changeSelectedEpg,
    submitApp,
    postAppData,
    putAppData,
    cancelAppCreate,
} from './fn';
import './style.less';


class Create extends Component {
    constructor(props) {
        super(props);
        this.changeName = changeName(this);
        this.changeDesc = changeDesc(this);
        this.changeSelectedEpg = changeSelectedEpg(this);
        this.submitApp=submitApp(this);
        this.postAppData=postAppData(this);
        this.putAppData=putAppData(this);
        this.cancelAppCreate=cancelAppCreate(this);

        this.state = {
            appName: '',
            appDesc: '',
            selectedEpgId: [],
        }
    }
    componentDidMount(){
        if(this.props.isEdit){
            let selectedApp = this.props.selectedApp;
            let selectedEpgId = selectedApp.epgs.map(item=>{
                return item.id;
            })
            this.setState({
                appName:selectedApp.name,
                appDesc:selectedApp.description,
                selectedEpgId
            })
        }
    }
    render() {
        return (
            <div className="create-app-box">
                <Card title="Basic Information">
                    <div className="card-section basci_info">
                        <p>
                            <label>
                                <span className="mark">*</span>
                                <em>Name:</em>
                            </label>
                            <Input
                                placeholder="Input a valid App name!"
                                style={{ width: 240 }}
                                onChange={this.changeName}
                                value={this.state.appName}
                            />
                        </p>
                        <p>
                            <label>
                                <em>Description:</em>
                            </label>
                            <Input
                                placeholder="Input a  App description!"
                                style={{ width: 240 }}
                                onChange={this.changeDesc}
                                value={this.state.appDesc}
                            />
                        </p>
                    </div>
                </Card>
                <Card title="EPG List">
                    <div className="card-section">
                        <Checkbox.Group onChange={this.changeSelectedEpg} value={this.state.selectedEpgId}>
                            <List
                                dataSource={this.props.projectEpgList}
                                renderItem={item => <List.Item><Checkbox value={item.id} /><span>{item.name}</span></List.Item>}
                            />
                        </Checkbox.Group>
                    </div>
                </Card>
                <div className="btn-group">
                    <Button type="primary" onClick={this.submitApp}>Ok</Button>
                    <Button onClick={this.cancelAppCreate}>Cancel</Button>
                </div>
                <Prompt message="Are you sure you want to leave?" when={true}/>
            </div >
        )
    }
}

const mapStateToProps = (state) => {
    state = state.toJS();
    return {
        selectedProject: state.project.selectedProject,
        projectEpgList: state.projectEpg.projectEpgList,
        isEdit: state.projectApp.isEdit,
        selectedApp: state.projectApp.selectedApp
    }
};

const mapDispatchToProps = (dispatch) => ({
    setSelecteProjectdApp: (data) => {
        dispatch(setSelecteProjectdApp({
            app: data
        }))
    },
    editProjectApp: (data) => {
        dispatch(editProjectApp({
            app: data
        }))
    },
    addProjectApp: (data) => {
        dispatch(addProjectApp({
            app: data
        }))
    }
})



export default connect(mapStateToProps, mapDispatchToProps)(Create);