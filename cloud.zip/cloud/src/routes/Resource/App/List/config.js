import {SERVER_IP} from '../../../../constants/Config';

export const deleteAppUrl = `${SERVER_IP}/cloudServer/app`;
export const showLogUrl = `${SERVER_IP}/cloudServer/app/buildlog`;
export const getAppListUrl = `${SERVER_IP}/cloudServer/app`;