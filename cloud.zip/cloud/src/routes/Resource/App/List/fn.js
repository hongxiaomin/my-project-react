import {message} from 'antd';
import request from '../../../../utils/fetchData';
import {deleteAppUrl,showLogUrl,getAppListUrl} from './config';
export const changeSelectedRow=_this=>(selectedRowKeys)=>{
    let isSelected = selectedRowKeys.length>0?true:false;
    _this.setState({
        isSelected,
        selectedRowKeys,
    })
}

export const hideLog=_this=>()=>{
    _this.setState({
        logInfo:null,
        logVisible:false,
    })
}

export const handleCreate = _this =>()=>{
    _this.props.setIsAppEdit(false);
    _this.props.showCreate(true);
}


export const handleDelete = _this =>()=>{
    let appList = _this.props.appList;
    let deleteApp = appList.filter(item=>{
        return item.key === _this.state.selectedRowKeys[0];
    })[0];
    _this.deleteAppData(deleteApp,()=>{
        _this.props.deleteProjectApp(deleteApp);
        _this.setState({
            selectedRowKeys:[],
            isSelected:false
        })
    })
}

export const deleteAppData = _this => async(deleteData,cb) =>{
    let response = await request(deleteAppUrl,{
        param:{id:deleteData.id},
        method:'DELETE',
        headers:new Headers()
    });
    if(response.message.code===0){
        message.success(`Delete ${deleteData.name} success!`);
        cb();
    }else{
        message.error(response.message.message);
    }
}

export const handleUpdate = _this =>()=>{
    let appList = _this.props.appList;
    let currentApp = appList.filter(item=>{
        return item.key === _this.state.selectedRowKeys[0];
    })[0];
    _this.props.setIsAppEdit(true);
    _this.props.setSelecteProjectdApp(currentApp);
    _this.props.showCreate(true);
}

export const showLog=_this=>(app)=>async()=>{
    let response = await request(showLogUrl,{
        data:{
            id:app.id
        }
    });
    if(response.message.code === 0){
        let logInfo = response.message.rows.message;
        _this.setState({
            logInfo,
            logVisible:true
        })
    }else{
        message.error(response.message.message);
    }
}

export const refreshAppList = _this=>async()=>{
    let response = await request(getAppListUrl,{
        data:{
            projectId:_this.props.selectedProject.id
        }
    });
    if(response.message.code===0){
        let data = response.message.rows.map(item=>{
            let key = item.id;
            return {...item,key};
        })
        _this.props.setAppList(data);
    }else{
        message.error(response.message.message);
    }
}
