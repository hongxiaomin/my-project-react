import React, { Component } from 'react';
import { connect } from 'react-redux';
import { toJS } from 'immutable';
import { Link } from 'react-router-dom';
import { Button, Input, Table, Modal } from 'antd';
import {
    setAppList,
    setIsAppEdit,
    setSelecteProjectdApp,
    deleteProjectApp
} from '../../../../actions';
import {
    changeSelectedRow,
    hideLog,
    handleCreate,
    deleteAppData,
    handleDelete,
    handleUpdate,
    showLog,
    refreshAppList

} from './fn';
import './style.less';

const Search = Input.Search;
const { TextArea } = Input;

class List extends Component {
    constructor(props) {
        super(props);
        this.changeSelectedRow = changeSelectedRow(this);
        this.hideLog = hideLog(this);
        this.handleCreate = handleCreate(this);
        this.deleteAppData = deleteAppData(this);
        this.handleDelete = handleDelete(this);
        this.handleUpdate = handleUpdate(this);
        this.showLog = showLog(this);
        this.refreshAppList = refreshAppList(this);

        this.state = {
            selectedRowKeys: [],
            isSelected: false,
            logVisible: false,
            logInfo: null,
        }
    }

    render() {
        const columns = [
            {
                title: 'Name',
                dataIndex: 'name',
                key: 'name',
                width: '15%'
            },
            {
                title: 'Description',
                dataIndex: 'description',
                key: 'description',
                width: '15%'
            },
            {
                title: 'EPG',
                dataIndex: 'epgs',
                render: (value) => value.map((item, index) => {
                    return (<span key={index} style={{ marginRight: '20px' }}>
                        {item.name}
                    </span>)
                }),
                key: 'epgs',
                width: '15%'
            },
            {
                title: 'MEU',
                dataIndex: 'meus',
                render: (value) => {
                    return value.map((item, index) => {
                        return (<span key={index} style={{ marginRight: '20px' }}>
                            {`${item.group}/${item.name}/${item.version}`}
                        </span>)
                    })
                },
                key: 'meus',
                width: '30%'
            },
            {
                title: 'Status',
                dataIndex: 'status',
                render: (value, row) => {
                    let text = '';
                    switch (value) {
                        case 1: text = 'Building';
                            break;
                        case 2: text = 'Build Success';
                            break;
                        case -1: text = 'Build Failed'
                            break;
                        default: text = '';
                    }
                    return <a href="javascript:;" onClick={this.showLog(row)}>{text}</a>

                },
                key: 'status',
                width: '15%'
            },
            {
                title: '',
                dataIndex: '',
                render: (value) => {
                    let status = value.status;
                    if (status === 2) {
                        let appId = value.id;
                        return (
                            <Link to={`/resource/profile/appProfile?appId=${appId}`}>
                                <Button type="primary">
                                    Create Profile
                                 </Button>
                            </Link>

                        )
                    } else {
                        return null;
                    }
                },
                key: 'createProfile',
                width: '10%'
            }
        ];
        const rowSelection = {
            selectedRowKeys: this.state.selectedRowKeys,
            onChange: this.changeSelectedRow,
            type: 'radio'
        }
        return (
            <div className="app_list_box">
                <div className="app_list_header">
                    <span className="btn_group">
                        <Button type="primary" onClick={this.handleCreate}>Create</Button>
                        <Button type="primary" onClick={this.refreshAppList}>Refresh</Button>
                        <Button type="primary" disabled={!this.state.isSelected} onClick={this.handleUpdate}>Edit</Button>
                        <Button type="primary" disabled={!this.state.isSelected} onClick={this.handleDelete}>Delete</Button>
                    </span>
                    <Search
                        placeholder="input search text"
                        onSearch={value => console.log(value)}
                        enterButton
                        style={{ width: 260, display: 'inline-block' }}
                    />
                </div>
                <Table
                    className="components-table-demo-nested"
                    rowSelection={rowSelection}
                    columns={columns}
                    dataSource={this.props.appList}
                />
                <Modal
                    title="App Build Log"
                    visible={this.state.logVisible}
                    onCancel={this.hideLog}
                    destroyOnClose={true}
                    footer={null}
                    width="960px"
                >
                    <TextArea autosize={{ minRows: 6, maxRows: 20 }} defaultValue={this.state.logInfo} />
                </Modal>

            </div>
        )
    }
}

const mapStateToProps = (state) => {
    state = state.toJS();
    return {
        appList: state.projectApp.appList,
        selectedProject: state.project.selectedProject
    }
};

const mapDispatchToProps = (dispatch) => ({
    setAppList: (data) => {
        dispatch(setAppList({
            appList: data
        }))
    },
    setSelecteProjectdApp: (data) => {
        dispatch(setSelecteProjectdApp({
            app: data
        }))
    },
    setIsAppEdit: (data) => {
        dispatch(setIsAppEdit({
            isEdit: data
        }))
    },
    deleteProjectApp: (data) => {
        dispatch(deleteProjectApp({
            app: data
        }))
    }
})

export default connect(mapStateToProps, mapDispatchToProps)(List);