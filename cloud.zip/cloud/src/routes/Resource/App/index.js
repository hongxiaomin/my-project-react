import React,{Component} from 'react';
import Page from '../../../components/Page';
import Bread from '../../../components/Bread';
import List from './List';
import Create from './Create';
import {breadMap} from './config';


class App extends Component{
    constructor(props){
        super(props);
        this.state={
            isCreate:false
        }
    }
    showCreate=(value)=>{
        this.setState({
            isCreate:value
        })
    }
    render(){
        return (
            <Page>
                <Bread breadMap={breadMap}/>
                {
                    this.state.isCreate?
                    <Create showCreate={this.showCreate}/>
                    :
                    <List showCreate={this.showCreate}/>
                }
            </Page>
        )
    }
}

export default App;