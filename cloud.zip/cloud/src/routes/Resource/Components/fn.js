export const handleComponentClick=_this=>(data)=>()=>{
    _this.setState({
        componentInfo:data,
        componentVisible:true
    })
}

export const handleComponentDetail=_this=>()=>{
    _this.setState({
        componentVisible:false
    })
}