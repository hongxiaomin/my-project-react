import React,{Component} from 'react';
import {connect} from 'react-redux';
import {toJS} from 'immutable';
import Page from '../../../components/Page';
import Bread from '../../../components/Bread';
import ComponentItem from '../../../components/ComponentItem';
import CloudModal from '../../../components/CloudModal';
import MeuInfo from '../../../components/MeuInfo';
import { breadMap} from './config';
import {handleComponentClick,handleComponentDetail} from './fn' 
class Components extends Component{
    constructor(props){
        super(props);
        this.handleComponentClick=handleComponentClick(this);
        this.handleComponentDetail=handleComponentDetail(this);
        this.state={
            componentVisible:false,
            componentInfo:null
        }
    }

    render(){
        return (
            <Page>
                <Bread breadMap={breadMap} />
                <div className="card_section">
                    {
                        this.props.projectComponentList.map(item=>{
                            return <ComponentItem 
                            data={item} 
                            key={item.key}
                            handleComponentClick={this.handleComponentClick(item)}
                            />
                        })
                    }
                </div>
                <CloudModal
                    title="Component Detail"
                    visible={this.state.componentVisible}
                    onOk={this.handleComponentDetail}
                    onCancel={this.handleComponentDetail}
                    width="860px"
                >
                    <MeuInfo data={this.state.componentInfo} dataType="component"/>
                </CloudModal>
            </Page>
        )
    }
}

const mapStateToProps = (state) =>{
    state=state.toJS();
    return {
        projectComponentList: state.market.projectComponentList
    }
};

const mapDispatchToProps = (dispatch)=>({
    
  })

export default connect(mapStateToProps,mapDispatchToProps)(Components);