import React from 'react';
import { SERVER_IP } from '../../../../constants/Config';
export const deleteEpgUrl = `${SERVER_IP}/cloudServer/project/epg`;
export const getProjectEpgUrl = `${SERVER_IP}/cloudServer/project/epg`;
export const columns = [
    {
        title: 'Name',
        dataIndex: 'name',
        width: '15%',
        key: "name"
    },
    {
        title: 'MEU',
        dataIndex: 'meus',
        width: '60%',
        render: (value) => {
            return value.map((item, index) => {
                return (<span key={index} style={{ marginRight: '20px', display: 'inline-block' }}>
                    {`${item.group}/${item.name}/${item.version}`}
                </span>)
            })
        },
        key: "meus"
    },
    {
        title: 'Description',
        dataIndex: 'description',
        key: "description"
    }
]