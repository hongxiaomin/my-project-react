import {message} from 'antd';
import request from '../../../../utils/fetchData';
import {deleteEpgUrl,getProjectEpgUrl} from './config';
export const handleCreateModal=_this=>()=>{
    _this.setState({
        createModalVisible:true,
    })
}

export const getProjectEpgData=_this=>async(project,cb)=>{
    let response =await request(getProjectEpgUrl,{
        data:{projectId:project.id}
    });
    if(response.message.code===0){
        let data=response.message.rows;
        let newData = data.map(item=>{
            let key =item.id;
            return {...item,key};
        })
        cb(newData);
    }else{
        message.error(`Get Project ${project.name} epg error!`)
    }
}

export const changeSelectedEpg=_this=>(selectedRowKeys)=>{
    _this.setState({
        selectedRowKeys
    });
    let selectedEpg = _this.props.projectEpgList.filter(item=>{
        return item.key === selectedRowKeys[0];
    })[0];

    if(selectedEpg){
        _this.props.setSelectedEpg(selectedEpg);
        _this.setState({
            isSelectedEpg:true
        })
    }
}

export const handleCreateEpgOk=_this=>()=>{
    let name = _this.state.name;
    let description = _this.state.description;
    if(name){
        _this.setState({
            createModalVisible:false
        });
        _this.props.setSelectedEpg({name,description});
        _this.props.setIsEdit(false);
        _this.props.showFlowchart(true);
    }else{
        message.error('Input available name!');
        return;
    }
}

export const handleCreateEpgCancel=_this=>()=>{
    _this.setState({
        createModalVisible:false
    });
}

export const handleEdit=_this=>()=>{
   _this.props.setIsEdit(true);
   _this.props.showFlowchart(true);
}

export const changeName=_this=>(e)=>{
    _this.setState({
        name:e.target.value
    })
}

export const changeDescription=_this=>(e)=>{
    _this.setState({
        description:e.target.value
    })
}

export const deleteEpg = _this=>()=>{
    let selectedEpg = _this.props.selectedEpg;
    let deleteData = {
        projectId:_this.props.selectedProject.id,
        epgs:[selectedEpg.id]
    };
    _this.deleteEpgData(deleteData,()=>{
        _this.props.deleteProjectEpg(selectedEpg);
    })
}

export const deleteEpgData = _this=>async(deleteData,cb)=>{
    const response = await request(deleteEpgUrl,{
        data:JSON.stringify(deleteData),
        method:'DELETE',
        contentType: 'raw',
        headers:new Headers()
    });
    if(response.message.code===0){
        let result = response.message.rows[0];
        if(result.result.indexOf('Success')>-1){
            message.success('Delete EPG Success!');
            cb();
        }else{
            message.error(result.result);
        }
    }else{
        message.error(response.message.message);
    }
}
