import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Link, withRouter } from 'react-router-dom';
import { toJS } from 'immutable';
import { Button, Input, Table } from 'antd';
import Page from '../../../../components/Page';
import Bread from '../../../../components/Bread';
import CloudModal from '../../../../components/CloudModal';
import { deleteProjectEpg,setSelectedEpg,setIsEdit,setProjectEpg } from '../../../../actions';
import { breadMap, columns } from './config';
import {
    handleCreateModal,
    changeSelectedEpg,
    handleCreateEpgOk,
    handleCreateEpgCancel,
    changeName,
    changeDescription,
    deleteEpgData,
    deleteEpg,
    handleEdit,
    getProjectEpgData,
} from './fn';
import './style.less';

const Search = Input.Search;
const { TextArea } = Input;

class EpgList extends Component {
    constructor(props) {
        super(props);
        this.handleCreateModal = handleCreateModal(this);
        this.changeSelectedEpg = changeSelectedEpg(this);
        this.handleCreateEpgOk=handleCreateEpgOk(this);
        this.handleCreateEpgCancel=handleCreateEpgCancel(this);
        this.changeName=changeName(this);
        this.changeDescription=changeDescription(this);
        this.deleteEpgData=deleteEpgData(this);
        this.deleteEpg=deleteEpg(this);
        this.handleEdit=handleEdit(this);
        this.getProjectEpgData=getProjectEpgData(this);

        this.state = {
            createModalVisible: false,
            isSelectedEpg: false,
            selectedRowKeys: [],
            name:'',
            description:''
        }
    }

    componentDidMount(){
        let selectedProject = this.props.selectedProject;
        console.log(selectedProject);
        if(selectedProject){
            this.getProjectEpgData(this.props.selectedProject,data=>{
                this.props.setProjectEpg(data);
            })
        }
        
    }
    render() {
        let isSelectedEpg = this.state.isSelectedEpg;
        const rowSelection = {
            selectedRowKeys: this.state.selectedRowKeys,
            onChange: this.changeSelectedEpg,
            type: 'radio'
        }
        return (
            <div className="epg_list_box">
                <div className="epg_list_header">
                    <span className="btn_group">
                        <Button type="primary" onClick={this.handleCreateModal}>Create</Button>
                        <Button type="primary" disabled={!isSelectedEpg} onClick={this.handleEdit}>Edit</Button>
                        <Button type="primary" disabled={!isSelectedEpg} onClick={this.deleteEpg}>Delete</Button>
                    </span>

                    <Search
                        placeholder="input search text"
                        onSearch={value => console.log(value)}
                        enterButton
                        style={{ width: 260, display: 'inline-block' }}
                    />
                </div>
                <Table
                    rowSelection={rowSelection}
                    columns={columns}
                    dataSource={this.props.projectEpgList}
                />
                <CloudModal
                    title="Create EPG"
                    visible={this.state.createModalVisible}
                    onOk={this.handleCreateEpgOk}
                    onCancel={this.handleCreateEpgCancel}
                    width="600px"
                >
                    <div className="create_epg_form">
                        <p>

                            <label>
                                <span>*</span>
                                <em>EPG Name:</em>
                            </label>
                            <Input
                                style={{ width: '280px', display: 'inline-block' }}
                                placeholder="please input EPG Name!"
                                value={this.state.name}
                                onChange={this.changeName}
                            />
                        </p>
                        <p>
                            <label>
                                <em>Description:</em>
                            </label>
                            <TextArea
                                placeholder="please input EPG Description!"
                                autosize={{ minRows: 3, maxRows: 6 }}
                                style={{ width: '280px', display: 'inline-block' }}
                                value={this.state.description}
                                onChange={this.changeDescription}
                            />
                        </p>
                    </div>
                </CloudModal>
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    state = state.toJS();
    return {
        projectEpgList: state.projectEpg.projectEpgList,
        selectedEpg: state.projectEpg.selectedEpg,
        isEdit:state.projectEpg.isEdit,
        selectedProject:state.project.selectedProject
    }
};

const mapDispatchToProps = (dispatch) => ({
    deleteProjectEpg: (data) => {
        dispatch(deleteProjectEpg({
            epg: data
        }))
    },
    setProjectEpg:(data)=>{
        dispatch(setProjectEpg({
            projectEpgList:data
        }))
    },
    setSelectedEpg:(data)=>{
        dispatch(setSelectedEpg({
            epg:data
        }))
    },
    setIsEdit:(data)=>{
        dispatch(setIsEdit({
            isEdit:data
        }))
    }
})

EpgList = withRouter(EpgList);
export default connect(mapStateToProps, mapDispatchToProps)(EpgList)