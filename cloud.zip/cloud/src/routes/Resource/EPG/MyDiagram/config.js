import {SERVER_IP} from '../../../../constants/Config';

export const getMeuUrl=`${SERVER_IP}/cloudServer/license/meu`;
export const postEpgUrl = `${SERVER_IP}/cloudServer/epg`;
export const putEpgUrl = `${SERVER_IP}/cloudServer/epg`;