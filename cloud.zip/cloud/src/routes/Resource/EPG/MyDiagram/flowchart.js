import 'gojs';
import { InputEvent } from 'gojs';

const  gettip=(getNode)=>{
    return getNode.tiptext.replace(/",/g,'"\n').replace(/:/g,' ： ').replace(/{/g,'').replace(/}/,'').replace(/\\"/g,'"').replace(/;/g,'"\n\n').replace(/"""/g,'"').replace(/""/g,'"').replace(/}/g,'');
}

//当鼠标在节点上方时，使节点上的所有端口都可见
const showPorts=(node, show)=>{
    var diagram = node.diagram;
    if (!diagram || diagram.isReadOnly || !diagram.allowLink) return;
    node.ports.each(function(port){
        port.stroke = (show ? "white" : null);
    })
}



export const initFlowchart =(flowchartObj)=>{
    const $ = go.GraphObject.make;//定义模板
    const lightText='#000';
    const myDiagram = $(go.Diagram,"myDiagram",{
        initialContentAlignment: go.Spot.Center,
        allowDrop: true,
        allowCopy:false,
        allowClipboard:false,
        "LinkDrawn": showLinkLabel,
        "LinkRelinked": showLinkLabel,
        "animationManager.isEnabled":false,
        "undoManager.isEnabled": false,
        "toolManager.hoverDelay": 0,
        "toolManager.toolTipDuration":0
    });

    myDiagram.nodeTemplateMap.add("",
        $(go.Node,"Spot",nodeStyle(),
            {locationSpot: go.Spot.Center},
            new go.Binding("location", "loc", go.Point.parse).makeTwoWay(go.Point.stringify),
            $(go.Panel,"Auto",{width: 'auto', height: 'auto'},
                $(go.Shape,"Rectangle",
                    {
                        fill:$(go.Brush,go.Brush.Linear,{0: "white",1: "#ccc"}),
                        stroke: "#bbb",
                        strokeWidth: 2
                    },
                    new go.Binding("figure", "figure"),
                    new go.Binding('location', 'loc', go.Point.Parse),
                    new go.Binding('width', 'width'),
                    new go.Binding('height', 'height')
                ),
                $(go.TextBlock,
                    {
                        font: "bold 14pt helvetica, bold arial, sans-serif",
                        margin: 20
                    },
                    new go.Binding("text").makeTwoWay()
                ),
                {
                    toolTip:$(go.Adornment,"Auto",
                        $(go.Shape,{fill: "#eee",stroke: "#bbb" }),
                        $(go.Panel,"Vertical",
                            $(go.TextBlock,
                                {
                                    margin:10,
                                    font:"200 12pt helvetica, bold arial, sans-serif",
                                    width:260
                                },
                                new go.Binding("text", "",gettip)
                            )
                        )
                    )  
                }
            ),
            makePort("T", go.Spot.Top, false, true),
            makePort("L", go.Spot.Left, true, true),
            makePort("R", go.Spot.Right, true, true),
            makePort("B", go.Spot.Bottom, true, false)
        ));

        myDiagram.nodeTemplateMap.add('Start',
            $(go.Node,"Spot",nodeStyle(),
                $(go.Panel,"Auto",
                    $(go.Shape,"Ellipse",{
                        minSize: new go.Size(40, 40),
                        fill:$(go.Brush,go.Brush.Linear,{0: "white",1: "#ccc"}),
                        stroke: "#bbb"  
                    }),
                    $(go.TextBlock,"Start",
                        {
                            font: "bold 14pt Helvetica, Arial, sans-serif",
                            stroke: lightText,
                            margin: 8
                        },
                        new go.Binding("text")
                    )
                ),
                makePort("L", go.Spot.Left, true, false),
                makePort("R", go.Spot.Right, true, false),
                makePort("B", go.Spot.Bottom, true, false),
                {
                    click:(e,obj)=>{
                        let startNode = obj.data;
                        flowchartObj.showLineInfo(false);
                        flowchartObj.showTimer(false);
                        flowchartObj.setStartNode(startNode);
                        flowchartObj.showStartType(true);
                    },
                    doubleClick:(InputEvent,graphObj)=>{
                        let startNode = graphObj.data;
                        flowchartObj.showLineInfo(false);
                        flowchartObj.showStartType(false);
                        if(startNode.type==="timer"){
                            flowchartObj.setStartNode(startNode);
                            flowchartObj.showTimer(true);
                        }
                    }
                }
            )
        );

        myDiagram.nodeTemplateMap.add('End',
            $(go.Node, "Spot", nodeStyle(),
                $(go.Panel, "Auto",
                    $(go.Shape, "Ellipse",
                        {
                            minSize: new go.Size(40, 40),
                            fill:$(go.Brush, go.Brush.Linear,{0: "white",1: "#ccc"}),
                            stroke: "#bbb"
                        }
                    ),
                    $(go.TextBlock, "End",
                        {
                            font: "bold 14pt Helvetica, Arial, sans-serif",
                            stroke: lightText,
                            margin: 8
                        },
                        new go.Binding("text")
                    )
                ),
                makePort("T", go.Spot.Top, false, true),
                makePort("L", go.Spot.Left, false, true),
                makePort("R", go.Spot.Right, false, true)
            )
        );

        myDiagram.linkTemplate=$(go.Link,
            {
                routing: go.Link.AvoidsNodes,
                curve: go.Link.JumpOver,
                corner: 5,
                toShortLength: 4,
                relinkableFrom: true,
                relinkableTo: true,
                resegmentable: true,
                reshapable: true,
                mouseEnter: (e, link)=>{ link.findObject("HIGHLIGHT").stroke = "rgba(30,144,255,0.2)"; },
                mouseLeave: (e, link)=>{ link.findObject("HIGHLIGHT").stroke = "transparent"; }
            },
            $(go.Shape,
                {
                    isPanelMain: true,
                    strokeWidth: 8,
                    stroke: "transparent",
                    name: "HIGHLIGHT"
                }
            ),
            $(go.Shape,
                {
                    isPanelMain: true,
                    stroke: "gray",
                    strokeWidth: 2
                }
            ),
            $(go.Shape,
                {
                    toArrow: "standard",
                    stroke: null,
                    fill: "gray" 
                }
            ),
            $(go.Panel, "Auto",
                {
                    visible: false,
                    name: "LABEL",
                    segmentIndex: 2,
                    segmentFraction: 0.5
                },
                new go.Binding("visible", "visible").makeTwoWay(),
                $(go.Shape, "RoundedRectangle",{
                    fill: "#f8f8f8",
                    stroke: null
                }),
                $(go.TextBlock, "reference",
                    {
                        textAlign: "center",
                        font: "10pt helvetica, arial, sans-serif",
                        stroke: "#333333",
                        editable: false
                    },
                    new go.Binding("text").makeTwoWay()
                )
            ),
            {
                click:(e,link)=>{
                    flowchartObj.showLineInfo(false);
                    flowchartObj.showStartType(false);
                    flowchartObj.showTimer(false);
                    let lineData=link.data;
                    let targetNodeId=link.data.to;
                    let visible = lineData.visible;
                    if(visible){
                        return;
                    }
                    flowchartObj.setSelectedLine(lineData);
                    flowchartObj.setTargetMeu(targetNodeId);
                    flowchartObj.showLineInfo(true);
                }
            }
        );
        //LinkingTool和RelinkingTool使用的临时链接也是正交的
        myDiagram.toolManager.linkingTool.temporaryLink.routing = go.Link.Orthogonal;
        myDiagram.toolManager.relinkingTool.temporaryLink.routing = go.Link.Orthogonal;

        //当点击画布时，隐藏线的配置信息表
        myDiagram.click=function(){
            flowchartObj.showLineInfo(false);
            flowchartObj.showStartType(false);
            flowchartObj.showTimer(false);
        };

        //当点击画布上的节点时，隐藏线的配置信息表
        myDiagram.addDiagramListener('ObjectSingleClicked',function(ev){
           flowchartObj.showLineInfo(false);
           flowchartObj.showStartType(false);
           flowchartObj.showTimer(false);
        });

        //当拖拽节点的时候隐藏线的配置信息表
        myDiagram.addDiagramListener('SelectionMoved',function(ev){
            flowchartObj.showLineInfo(false);
            flowchartObj.showStartType(false);
            flowchartObj.showTimer(false);
        });

        // 删除节点和线
        myDiagram.addDiagramListener('SelectionDeleted',function(ev){
            let deleteData=ev.subject.Ea.value.data;
            if("key" in deleteData){
                if(deleteData["category"]==="Start"){
                    if(deleteData.type==="timer"){
                        flowchartObj.setIsTimer(false);
                        flowchartObj.setTimerList([]);
                    }
                }else{
                    if(deleteData["category"]!=="End"){
                        let meuId = deleteData['key'];
                        flowchartObj.deleteNode(meuId);
                        let type = deleteData["type"];
                        if(type&&type==="webApi"){
                            flowchartObj.showUrlMapping(true);
                        }
                        
                    }
                }
            }else if("return" in deleteData){
                let returnValue = deleteData["return"];
                flowchartObj.deleteInputParam(returnValue);
            }
            flowchartObj.showLineInfo(false);
            flowchartObj.showStartType(false);
            flowchartObj.showTimer(false);
        });

        //从左边的画布拖拽节点到右边的画布上，如果是meu，弹出meu列表
        myDiagram.addDiagramListener('ExternalObjectsDropped',function(ev){
            const originalData=ev.Ow.Ea.value.data;
            if(originalData.text==='Meu'){
                flowchartObj.showMeuModal(true);
                myDiagram.remove(myDiagram.findNodeForKey(-2));
            }

        });

        //初始化页面左侧的“调色板”
        const myPalette=$(go.Palette,"myPalette",{
            // "animationManager.duration": 800,
            nodeTemplateMap: myDiagram.nodeTemplateMap
        });

        myPalette.model=new go.GraphLinksModel([
            { category: "Start", text: "Start" },
            { text: "Meu",meuId:"",width:80,height:50},
            { text: "", figure: "Diamond",width:40,height:40},
            { category: "End", text: "End"},
            { text: "+", figure: "Diamond",width:40,height:40}
        ]);
        //如果是update epg
        if(flowchartObj.isEdit){
            myDiagram.model = go.Model.fromJson(flowchartObj.graphModel); 
        }

        //点击meu节点的时候显示meu的列表
        myPalette.findNodeForKey(-2).click=function(e,node){
            flowchartObj.showMeuModal(true);
        };

        //节点模板的辅助定义
        function nodeStyle(){
            return [
                new go.Binding("location","loc",go.Point.parse).makeTwoWay(go.Point.stringify),
                {
                    locationSpot: go.Spot.Center,
                    mouseEnter: function (e, obj) { showPorts(obj.part, true); },
                    mouseLeave: function (e, obj) { showPorts(obj.part, false); }
                }
            ]
        }

        //定义一个端口的功能
        function makePort(name,spot,output,input){
            return $(go.Shape,"Circle",
                        {
                            fill: "transparent",
                            stroke: null,
                            desiredSize: new go.Size(8, 8),
                            alignment: spot,
                            alignmentFocus: spot,
                            portId: name,
                            fromSpot: spot,
                            toSpot: spot,
                            fromLinkable: output,
                            toLinkable: input,
                            cursor: "pointer"
                        }
                    );
        }

        //showLinkLabel绘制节点之间的线时设置一些属性
        function showLinkLabel(e){
            flowchartObj.showLineInfo(false);
            let label = e.subject.findObject("LABEL");
            const lineData=e.subject.data;
            const targetNodeId= lineData.to;
            flowchartObj.setSelectedLine(lineData);
            flowchartObj.setTargetMeu(targetNodeId);
            flowchartObj.showStartType(false);
            flowchartObj.showTimer(false);
            if(label !==null ){
                label.visible=false;
                flowchartObj.showReference(false);
                if(flowchartObj.epgIsDI(lineData)){
                    flowchartObj.showReference(true);
                    flowchartObj.setLinkLabel(label);
                }else{
                    flowchartObj.showLineInfo(true);
                }
            }
        }
        
        flowchartObj.handleSetDiagram(myDiagram);
        flowchartObj.handleSetPalette(myPalette);
}