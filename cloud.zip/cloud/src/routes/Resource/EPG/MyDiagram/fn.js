import {getMeuUrl,postEpgUrl,putEpgUrl} from './config';
import request from '../../../../utils/fetchData';
import {getXmlJsonData,getNonDuplicateID,json2xml} from '../../../../utils/todoXml';
import {vkbeautifySub} from '../../../../utils/vkbeautify';
import {message} from 'antd';
import { isObject, isString, isArray } from '../../../../utils/Common';
export const idLink = '/';
export const getMeuId = (data)=>{
    return `${data.group}${idLink}${data.name}${idLink}${data.version}`
};


export const handleSetDiagram =_this=>(diagram)=>{
    _this.setState({
        myDiagram:diagram
    })
}

export const handleSetPalette =_this=>(palette)=>{
    _this.setState({
        myPalette:palette
    })
}

export const onSelectMeuChange=_this=>(selectedRowKeys)=>{
    _this.setState({
        selectedRowKeys
    })
}

export const showMeuModal =_this=>(value)=>{
    _this.setState({
        meuVisible:value
    })
}



export const deleteNode =_this=>(id)=>{
    let meuDatas = [..._this.state.allMeu];
    let currentMeu = meuDatas.filter(item=>{
        return item.id===id;
    })
    let selectedMeus = [..._this.state.selectedMeus];
    selectedMeus = selectedMeus.filter(item=>{
        return item.id!==id;
    });
    let meuList =[..._this.state.meuList];
    meuList=meuList.concat(currentMeu);

    let inputParamList=[..._this.state.inputParamList];
    inputParamList=inputParamList.filter(item=>{
        if(item.from===id||item.to===id){
            return false;
        }else{
            return true;
        }
    })
    _this.setState({
        meuList,
        selectedMeus,
        inputParamList
    })
}

export const handleMeuSure=_this=>()=>{
    let selectedRowKeys=_this.state.selectedRowKeys;
    let selectedMeus = [];
    let meuList = [..._this.state.meuList];
    for(let i=0;i<selectedRowKeys.length;i++){
        const currentMeu = _this.state.allMeu.filter(item=>{
            return item.key === selectedRowKeys[i];
        })[0];

        selectedMeus.push(currentMeu);
        meuList=meuList.filter(item=>{
            return item.id!==currentMeu.id
        })
    }
    let hasWebMeu=false;
    selectedMeus.forEach((item,index)=>{
        const meuTip = JSON.stringify({
            "Group":item.group,
            "vertion":item.version
        });
        const meuNode = {
            "key":item.id,
            "text":item.name,
            "tiptext":meuTip,
            "type":item.type
        };
        if(item.type==="webApi"){
            hasWebMeu=true;
        }
        _this.state.myDiagram.model.addNodeData(meuNode);
    })
    if(hasWebMeu){
       showUrlMapping(_this)(false);
    }
    _this.setState({
        meuList:meuList,
        meuVisible:false,
        selectedRowKeys:[],
        selectedMeus:_this.state.selectedMeus.concat(selectedMeus)
    })
}

export const handleMeuCancel=_this=>()=>{
    _this.setState({
        meuVisible:false
    })
}

export const showLineInfo=_this=>(value)=>{
    _this.setState({
        lineInfoVisible:value
    })
}

export const setTargetMeu =_this=>(id)=>{
    
    let targetMeu = _this.state.allMeu.filter(item=>{
        return item.id===id;
    })
    if(targetMeu.length>0){
        targetMeu={...targetMeu[0]};
    }else{
        targetMeu=null;
    }
    
    _this.setState({
        targetMeu
    })
}

export const setSelectedLine =_this =>(value)=>{
    _this.setState({
        selectedLineInfo:value
    })
}

export const setInputParam=_this=>(value)=>{
    _this.setState({
        inputParamList:value
    })
}

export const deleteInputParam = _this =>(value)=>{
    let inputParamList=[..._this.state.inputParamList];
    inputParamList=inputParamList.filter(item=>{
        return item.value!==value;
    })
    _this.setState({
        inputParamList,
    })
}

export const changeTab=_this=>(activeKey)=>{
    if(activeKey==4){
        getCurrentXml(_this)();
    }
}

export const getCurrentXml =_this=>(callbcak)=>{
    let myDiagram=_this.state.myDiagram;
    let diagramJson=JSON.parse(JSON.stringify(_this.state.diagramJson));
    let saveEpgData=JSON.parse(JSON.stringify(_this.state.saveEpgData));
    const modelJson=myDiagram.model.toJson();
    saveEpgData.graphInfo=modelJson;
    let modelObj=JSON.parse(modelJson);
    let jsonMeu=modelObj.nodeDataArray;
    let styleObj={};
    let allMeu = _this.state.allMeu;
    let meuArr=[];
    jsonMeu.forEach(meu=>{
        let hasMeu = allMeu.filter(orignItem=>{
            return orignItem.id===meu["key"];
        })
        if(hasMeu.length>0){
            let meuInfo=hasMeu[0];
            let currentMeu={};
            currentMeu["@id"]=meuInfo["id"];
            if(meuInfo["type"]){
                currentMeu["@type"]=meuInfo["type"]
                if(meuInfo["type"]==="virtual"||meuInfo["type"]==="dispatch"){
                    let topicObj={};
                    topicObj["@topic"]=meuInfo.id;
                    topicObj["@meuId"]=meuInfo.id;
                    topicObj["@operationId"]='';
                    let topics=diagramJson.epg["topic-meu-mappings"];
                    if(!topics["topic-meu-mapping"]){
                        topics["topic-meu-mapping"]=[];
                    }
                    topics["topic-meu-mapping"].push(topicObj);
                }
            }else{
                let definition=getXmlJsonData(meuInfo["definition"]);
                let operations = definition.meu.operations;
                if(operations){
                    operations=operations.operation;
                    if(isArray(operations)){
                        operations=operations;
                    }else if(isObject(operations)){
                        operations=[operations];
                    }
                    operations.forEach(item=>{
                        let topicObj={};
                        topicObj["@topic"]=meuInfo.id+'/'+item["@id"];
                        topicObj["@meuId"]=meuInfo.id;
                        topicObj["@operationId"]=item["@id"];
                        let topics=diagramJson.epg["topic-meu-mappings"];
                        if(!topics["topic-meu-mapping"]){
                            topics["topic-meu-mapping"]=[];
                        }
                        topics["topic-meu-mapping"].push(topicObj);
                    })
                }
            }
            let groupMeu=diagramJson.epg.meus;
            if(!groupMeu.meu){
                groupMeu.meu=[];
            }
            groupMeu.meu.push(currentMeu);
        }else{
            if(meu["figure"]){
                if(meu["text"]==='+'){
                    styleObj[meu["key"]]="Add";
                }else{
                    styleObj[meu["key"]]=meu["figure"];
                }
            }else if(meu["category"]){
                styleObj[meu["key"]]=meu["category"];
                if(meu["category"]==="Start"){
                    if(meu["type"]==="timer"&&_this.state.isTimer){
                        diagramJson.epg["timers"]={};
                        diagramJson.epg["timers"]["timer"]=[];
                        let timerArr=diagramJson.epg["timers"]["timer"];
                        let timerList =[..._this.state.timerList];
                        timerList.forEach(item=>{
                            if(item.type==="cron"){
                                timerArr.push({"@id":item.id,"@cron":item.value})
                            }else if(item.type==="period"){
                                timerArr.push({"@id":item.id,"@period":item.value,"@timeUnit":item.timeUnit});
                            }
                        })
                    }else{
                        delete diagramJson.epg["timers"];
                    }
                }
            }
        }
    })
    let destDiaArr=[];//以菱形开始
    let sourceDiaArr=[];//以菱形结束
    let normalEventArr=[];//正常节点
    let sourceDestDiaArr=[];//以菱形开始并以菱形结束；
    let sourceAdd=[];//以add开始
    let destAdd=[];//以add结束
    let jsonEvents=modelObj.linkDataArray;
    jsonEvents.forEach(event=>{
        let source=event["from"];
        let dest=event["to"];
        let visible=event["visible"];
        if(!visible){
            if(dest in styleObj&&styleObj[dest]==='Diamond'){
                let sourceMeu=allMeu.filter(item=>{
                    return item.id===source;
                })
                if(sourceMeu.length>0||(source in styleObj&&styleObj[source]!=='Diamond')){
                    sourceDiaArr.push(event);
                }else if(source in styleObj&&styleObj[source]==='Diamond'){
                    sourceDestDiaArr.push(event);
                }
            }else if(source in styleObj&&styleObj[source]==='Diamond'){
                destDiaArr.push(event);
            }else if(dest in styleObj&&styleObj[dest]==='Add'){
                destAdd.push(event);
            }else if(source in styleObj&&styleObj[source]==='Add'){
                sourceAdd.push(event);
            }else{
                normalEventArr.push(event);
            }
        }
    });

    normalEventArr.forEach(function(event){
        let source=event.from;
        let dest=event.to;
        let currentEventObj=initEventParam(event);
        currentEventObj["@id"]=getNonDuplicateID();
        let sourceMeu = allMeu.filter(meu=>{
            return meu.id===source;
        })
        if(sourceMeu.length>0){
            currentEventObj["@source"]=source;
        }else{
            if(source in styleObj&&styleObj[source]==='Start'){
                let startNode = jsonMeu.filter(node=>{
                    return node.key === source;
                })
                if(startNode.length>0){
                    startNode=startNode[0];
                    defineStartNode(startNode,currentEventObj);
                }
            }
        }

        let destMeu = allMeu.filter(meu=>{
            return meu.id===dest;
        })
        if(destMeu.length>0){
            currentEventObj["@dest"]=dest;
        }else{
            if(dest in styleObj&&styleObj[dest]==='End'){
                currentEventObj["@dest"]='';
            }
        }

        let groupEvent=diagramJson.epg.events;
        if(!groupEvent.event){
            groupEvent.event=[];
        }
        groupEvent.event.push(currentEventObj);
    });

    let sourceDiaObj={};
    sourceDiaArr.forEach((event)=>{
        let source=event.from;
        let dest=event.to;
        let currentEventObj=initEventParam(event);

        currentEventObj["@id"]=getNonDuplicateID();
        let sourceMeu = allMeu.filter(meu=>{
            return meu.id===source;
        })
        if(sourceMeu.length>0){
            currentEventObj["@source"]=source;
        }else if(source in styleObj&&styleObj[source]==='Start'){
            let startNode = jsonMeu.filter(node=>{
                return node.key===source;
            })
            if(startNode.length>0){
                startNode=startNode[0];
                defineStartNode(startNode,currentEventObj);
            }
        }

        currentEventObj["dest"]=[];
        sourceDiaObj[dest]=currentEventObj;
    });

    if(sourceDestDiaArr.length>0){
        for(let i=0;i<sourceDestDiaArr.length;i++){
            for(let j=i+1;j<sourceDestDiaArr.length;j++){
                if(sourceDestDiaArr[j].from===sourceDestDiaArr[i].to){
                    sourceDestDiaArr[j].from=sourceDestDiaArr[i].from;
                }
            }
        }
    }

    destDiaArr.forEach((event)=>{
        var source=event.from;
        var dest=event.to;
        let currentEventObj=initEventParam(event);
        let destMeu = allMeu.filter(meu=>{
            return meu.id===dest;
        })
        if(destMeu.length>0){
            currentEventObj["@id"]=dest;
        }else{
            currentEventObj["@id"]='';
        }
        if(sourceDestDiaArr.length>0){
            for(let i=0;i<sourceDestDiaArr.length;i++){
                if(sourceDestDiaArr[i].to===source){
                    source=sourceDestDiaArr[i].from;
                }
            }
        }
        if(source in sourceDiaObj){
            sourceDiaObj[source].dest.push(currentEventObj);
        }
    });

    let groupEvent=diagramJson.epg.events;
    if(!groupEvent.event){
        groupEvent.event=[];
    }

    let sourceDiaKeys = Object.keys(sourceDiaObj);
    sourceDiaKeys.forEach(item=>{
        groupEvent.event.push(sourceDiaObj[item]);
    })
    let addCondition={};
    destAdd.forEach((event)=>{
        let destId=event.to;
        let sourceId=event.from;
       if(!addCondition[destId]){
           addCondition[destId]={};
       }
       if(!addCondition[destId]["from"]){
           addCondition[destId]["from"]=[];
       }
        addCondition[destId]["from"].push(sourceId);
    });

    sourceAdd.forEach((event)=>{
        let currentEventObj=initEventParam(event);
        let destId=event.to;
        let sourceId=event.from;
        if(!addCondition[sourceId]){
            addCondition[sourceId]={};
        }
        addCondition[sourceId]["to"]=destId;
        addCondition[sourceId]["param"]=currentEventObj;
    });
    for(let addNode in addCondition){
        if(!diagramJson.epg.constraints){
            diagramJson.epg.constraints={ "constraint":[]}
        }
        let constraintObj={};
        constraintObj["@type"]="and";
        constraintObj["event"]=[];

        addCondition[addNode]["from"].forEach((fromNode)=>{
            let addEventObj={};
            if(addCondition[addNode]["param"]){
                addEventObj={...addCondition[addNode]["param"]};
            }
            let addEventId=getNonDuplicateID();

            addEventObj["@id"]=addEventId;
            addEventObj["@source"]=fromNode;
            addEventObj["@dest"]=addCondition[addNode]["to"];
            constraintObj["event"].push({"@id":addEventId});
            diagramJson.epg.events.event.push(addEventObj);
        });
        diagramJson.epg.constraints.constraint.push(constraintObj);
    }
    let xmlText=json2xml(diagramJson);
    xmlText=`<?xml version="1.0" encoding="UTF-8"?>\n${xmlText}`;
    let formatXml = vkbeautifySub.xml(xmlText);//格式化xml
    saveEpgData.definition=formatXml;
    _this.setState({
        epgXmlStr:formatXml
    })
    if(callbcak&&(typeof callbcak==='function')){
        callbcak(saveEpgData);
    }
}

export const defineStartNode=(startNode,currentEventObj)=>{
    if(!startNode.type){
        currentEventObj["@source"]="";
    }else if(startNode.type==="external"){
        currentEventObj["@source"]="external";
        currentEventObj["@sync"]=startNode.sync;
    }else if(startNode.type==="timer"){
        currentEventObj["@source"]="timer";
        if(startNode.timerId){
            currentEventObj["@timerId"]=startNode.timerId;
        }
    }
}

export const saveEpg = _this=>()=>{
    getCurrentXml(_this)((epgData)=>{
        _this.setState({
            loading:true
        })
        if(!_this.state.urlMapingVisible){
            let postUrlMappings=JSON.parse(JSON.stringify(_this.state.postUrlMappings));
            let urlMappingData=[..._this.state.urlMappingData];
            if(urlMappingData.length>0){
                let urlMeuMappingArr=postUrlMappings["url-meu-mappings"]["url-meu-mapping"];
                urlMappingData.forEach((item,index)=>{
                    delete item.key;
                    urlMeuMappingArr.push(item);
                })
                let urlMappingXml = json2xml(postUrlMappings);
                urlMappingXml=`<?xml version="1.0" encoding="UTF-8"?>\n${urlMappingXml}`;
                let urlMappingXmlStr=vkbeautifySub.xml(urlMappingXml);
                epgData.urlMappings.definition=urlMappingXmlStr;
            }
        }
        epgData.scripts.definition=_this.state.scripts;
        if(_this.props.isEdit){
            epgData.id=_this.props.selectedEpg.id;
            putEpg(_this)(epgData,(data)=>{
                _this.setState({
                    scripts:'',
                    addUrlMappingData:initAddUrlMapping()
                })
                _this.props.editProjectEpg(data);
                _this.props.setSelectedEpg({});
                _this.props.showFlowchart(false);
            })
        }else{
            epgData.projectId=_this.props.selectedProject.id;
            postEpg(_this)(epgData,(data)=>{
                _this.setState({
                    scripts:'',
                    addUrlMappingData:initAddUrlMapping(),
                })
                _this.props.addProjectEpg(data);
                _this.props.setSelectedEpg({});
                _this.props.showFlowchart(false);
            })
        }
        
    })
}

export const cancelEpg = _this=>()=>{
    _this.props.showFlowchart(false);
}

export const postEpg= _this => async(data,cb)=>{
    const response = await request(postEpgUrl,{
        method: 'POST',
        data: JSON.stringify(data),
        contentType: 'raw',
        headers: new Headers(),
    });
    if(response.message.code===0){
        message.success('Create EPG Success!');
        let currentEpg = {...response.message.rows};
        let key = currentEpg.id;
        currentEpg={...currentEpg,key};
        cb(currentEpg);
    }else{
        message.error(response.message.message);
    }
}

export const putEpg= _this => async(data,cb)=>{
    const response = await request(postEpgUrl,{
        method: 'PUT',
        data: JSON.stringify(data),
        contentType: 'raw',
        headers: new Headers(),
    });
    if(response.message.code===0){
        message.success('Create EPG Success!');
        let currentEpg = {...response.message.rows};
        let key = currentEpg.id;
        currentEpg={...currentEpg,key};
        cb(currentEpg);
    }else{
        message.error(response.message.message);
    }
}


export const initEventParam = (event)=>{
    let currentEventObj={};
    const {mode,operationId,inputParam,condition}=event;
    if(mode){
        currentEventObj["@mode"]=mode;
    }
    if(operationId){
        currentEventObj["@operationId"]=operationId;
    }
    if(inputParam){
        currentEventObj["@inputParam"]=inputParam;
    }
    if(condition){
        currentEventObj["@condition"]=condition;
    }
    if(event["return"]){
        currentEventObj["@return"]=event["return"];
    }
   return currentEventObj;
}

export const showUrlMapping =_this =>(value)=>{
    _this.setState({
        urlMapingVisible:value
    })
}

export const onSelectUrlMappingChange =_this =>(activeKey)=>{
    _this.setState({
        urlMappingSelectedRowKeys:activeKey
    })
}

export const showAddUrlMapping = _this=>()=>{
    _this.setState({
        urlMappingVisible:!_this.state.urlMappingVisible
    })
}

export const changeUrlMaping=_this=>(key,value)=>{
    let addUrlMappingData = {..._this.state.addUrlMappingData};
    addUrlMappingData[key]=value;
    _this.setState({
        addUrlMappingData
    })
}

export const addUrlMappingOk =_this =>()=>{
    let addData=_this.state.addUrlMappingData;
    for(let item in addData){
        if(!addData[item]){
            if(item !== "@operationId"){
                message.error(`Input available ${item}`);
                return;
            }
        }
    }
    
    let urlMappingData = [..._this.state.urlMappingData];
    if("key" in addData){
        urlMappingData=urlMappingData.map(item=>{
            if(item.key===addData.key){
                item=addData;
            }
            return item;
        })
    }else{
        addData.key=`${Date.now()}${urlMappingData.length}`;
        urlMappingData.unshift(addData)
    }
    _this.setState({
        urlMappingData,
        urlMappingVisible:false,
        addUrlMappingData:initAddUrlMapping(),
    })
}

export const addUrlMappingCancel=_this=>()=>{
    _this.setState({
        urlMappingVisible:false,
        addUrlMappingData:initAddUrlMapping(),
    })
}

export const initAddUrlMapping =()=>{
    return {
                ["@url"]:'',
                ["@dest"]:'',
                ["@operationId"]:'',
                ["@method"]:''
            }
}

export const deleteUrlMapping =_this=>()=>{
    let urlMappingSelectedRowKeys = _this.state.urlMappingSelectedRowKeys;
    let urlMappingData = [..._this.state.urlMappingData];
    for(let i =0;i<urlMappingSelectedRowKeys.length;i++){
        urlMappingData=urlMappingData.filter((item,index)=>{
            return item.key!==urlMappingSelectedRowKeys[i];
        })
        debugger;
    }
    _this.setState({
        urlMappingSelectedRowKeys:[],
        urlMappingData,
    })
}

export const editUrlMapping=_this=>(value)=>()=>{
    _this.setState({
        addUrlMappingData:value,
        urlMappingVisible:true,
    })
}

export const changeSCripts=_this=>(editor, data, value) => {
    _this.setState({scripts:value});
}

export const showStartType = _this=>(value)=>{
    _this.setState({
        startTypeVisible:value
    })
}

export const showTimer = _this =>(value)=>{
    _this.setState({
        timerVisible:value
    })
}

export const setStartNode = _this => (node) =>{
    _this.setState({
        startNode:node
    })
}

export const setIsTimer =_this =>(value)=>{
    _this.setState({
        isTimer:value
    })
}

export const initStartTimer = ()=>{
    let key = `${Date.now()}`;
    return  {
            key,
            id:`timer-${key}`,
            type:'cron',
            value:'',
            timeUnit:'microseconds',
            checked:true
        }
    
}
export const setTimerList =_this=>(value)=>{
    _this.setState({
        timerList:value
    })
}

export const editEpgHasReturn=_this=>(linkDataArray,meuList)=>{
    let inputParamList = [];
    linkDataArray.forEach(item => {
        if (item["return"]) {
            let type='';
            let targetMeu = meuList.filter(meu => {
                return meu.id === item.to;
            })
            if (targetMeu.length > 0) {
                targetMeu = targetMeu[0];
                let definition = getXmlJsonData(targetMeu["definition"]);
                let operations = definition.meu.operations;
                if (operations) {
                    operations = operations.operation;
                    if (isArray(operations)) {
                        operations = operations;
                    } else if (isObject(operations)) {
                        operations = [operations];
                    }
                    operations.forEach(opera=>{
                        if(opera["@id"]===item.operationId){
                            type=opera["@returnType"];
                        }
                    })
                }
            }
            inputParamList.push({
                from:item.from,
                to:item.to,
                value:item["return"],
                type
            })
        }
    })
    _this.setState({
        inputParamList
    })
}

export const showReference=_this=>(value)=>{
    _this.setState({
        referenceVisible:value
    })
}

export const epgIsDI=_this=>(link)=>{
    let isReference=false;
    let source = link.from;
    let dest = link.to;
    let allMeu = [..._this.state.allMeu];
    let sourceMeu = allMeu.filter(item=>{
        return item.id===source;
    })
    let destMeu = allMeu.filter(item=>{
        return item.id===dest;
    })
    if(sourceMeu.length>0&&destMeu.length>0){
        sourceMeu=sourceMeu[0];
        destMeu=destMeu[0];
        let sourceMeuDefinition = getXmlJsonData(sourceMeu.definition);
        let destMeuDefinition = getXmlJsonData(destMeu.definition);
        let referenceMeu = sourceMeuDefinition.meu.reference;
        let declareMeu = destMeuDefinition.meu.declare
        if(referenceMeu){
            let referenceData = referenceMeu.interface;
            if(isString(referenceData)){
                referenceData=[referenceData];
            }
            if(declareMeu){
                let declareData=declareMeu.interface;
                for(let i=0;i<referenceData.length;i++){
                    if(referenceData[i]===declareData){
                        isReference=true;
                    }
                }
            }
        }
    }
    return isReference;
}

export const sureRef=_this=>()=>{
    let label = _this.state.linkLabel;
    label.visible=true;
    _this.setState({
        linkLabel:label,
        referenceVisible:false
    })
}

export const cancelRef=_this=>()=>{
    _this.setState({
        linkLabel:null,
        referenceVisible:false,
        lineInfoVisible:true,
    })
}


export const setLinkLabel =_this=>(value)=>{
    _this.setState({
        linkLabel:value
    })
}