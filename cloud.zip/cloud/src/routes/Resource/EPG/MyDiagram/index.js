import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter, Link,Prompt } from 'react-router-dom';
import { toJS } from 'immutable';
import { Tabs, Table, Input, Select, Button, Icon } from 'antd';
import Dragger from 'react-dragger-r';
require('codemirror/lib/codemirror.css');
require('codemirror/theme/material.css');
require('codemirror/theme/neat.css');
require('codemirror/mode/xml/xml.js');
require('codemirror/mode/javascript/javascript.js');
import { Controlled as CodeMirror } from 'react-codemirror2';
import LineInfo from '../../../../components/LineInfo';
import CloudModal from '../../../../components/CloudModal';
import UrlMappingFile from '../../../../components/UrlMappingFile';
import StartType from '../../../../components/StartType';
import StartTimer from '../../../../components/StartTimer';
import { GenNonDuplicateID, getXmlJsonData } from '../../../../utils/todoXml';
import { setSelectedEpg,addProjectEpg,editProjectEpg } from '../../../../actions';
import {
    handleSetDiagram,
    handleSetPalette,
    onSelectMeuChange,
    showMeuModal,
    handleMeuSure,
    handleMeuCancel,
    showLineInfo,
    getMeuId,
    setTargetMeu,
    setSelectedLine,
    setInputParam,
    changeTab,
    saveEpg,
    cancelEpg,
    deleteNode,
    showUrlMapping,
    onSelectUrlMappingChange,
    showAddUrlMapping,
    changeUrlMaping,
    addUrlMappingOk,
    addUrlMappingCancel,
    initAddUrlMapping,
    deleteUrlMapping,
    editUrlMapping,
    changeSCripts,
    deleteInputParam,
    showStartType,
    showTimer,
    setStartNode,
    setIsTimer,
    initStartTimer,
    setTimerList,
    editEpgHasReturn,
    showReference,
    epgIsDI,
    setLinkLabel,
    sureRef,
    cancelRef,

} from './fn';
import {
    initFlowchart
} from './flowchart';
import './style.less';
import { isArray, isObject } from '../../../../utils/Common';

const TabPane = Tabs.TabPane;
const Option = Select.Option;
const { TextArea } = Input;

class MyDiagram extends Component {
    constructor(props) {
        super(props);
        this.handleSetDiagram = handleSetDiagram(this);
        this.handleSetPalette = handleSetPalette(this);
        this.onSelectMeuChange = onSelectMeuChange(this);
        this.showMeuModal = showMeuModal(this);
        this.handleMeuSure = handleMeuSure(this);
        this.handleMeuCancel = handleMeuCancel(this);
        this.showLineInfo = showLineInfo(this);
        this.setTargetMeu = setTargetMeu(this);
        this.setSelectedLine = setSelectedLine(this);
        this.setInputParam = setInputParam(this);
        this.changeTab = changeTab(this);
        this.saveEpg = saveEpg(this);
        this.cancelEpg = cancelEpg(this);
        this.deleteNode = deleteNode(this);
        this.showUrlMapping = showUrlMapping(this);
        this.onSelectUrlMappingChange = onSelectUrlMappingChange(this);
        this.showAddUrlMapping = showAddUrlMapping(this);
        this.changeUrlMaping = changeUrlMaping(this);
        this.addUrlMappingOk = addUrlMappingOk(this);
        this.addUrlMappingCancel = addUrlMappingCancel(this);
        this.deleteUrlMapping = deleteUrlMapping(this);
        this.editUrlMapping = editUrlMapping(this);
        this.changeSCripts = changeSCripts(this);
        this.deleteInputParam = deleteInputParam(this);
        this.showStartType = showStartType(this);
        this.showTimer = showTimer(this);
        this.setStartNode = setStartNode(this);
        this.setIsTimer = setIsTimer(this);
        this.setTimerList = setTimerList(this);
        this.editEpgHasReturn = editEpgHasReturn(this);
        this.showReference = showReference(this);
        this.epgIsDI = epgIsDI(this);
        this.setLinkLabel = setLinkLabel(this);
        this.sureRef = sureRef(this);
        this.cancelRef = cancelRef(this);

        this.state = {
            myDiagram: null,
            myPalette: null,
            meuVisible: false,
            selectedRowKeys: [],
            meuList: JSON.parse(JSON.stringify(this.props.projectMeuList)),
            allMeu: JSON.parse(JSON.stringify(this.props.projectMeuList)),
            lineInfoVisible: false,
            targetMeu: null,
            selectedLineInfo: null,
            inputParamList: [],
            diagramJson: {
                "epg": {
                    "@id": GenNonDuplicateID(),
                    "@name": this.props.selectedEpg.name,
                    "meus": {},
                    "events": {},
                    "topic-meu-mappings": {}
                }
            },
            saveEpgData: {
                name: this.props.selectedEpg.name,
                description: this.props.selectedEpg.description,
                definition: '',
                urlMappings: {
                    definition: ''
                },
                scripts: {
                    definition: ''
                },
                graphInfo: ''
            },
            epgXmlStr: '',
            loading: false,
            urlMapingVisible: true,//urlMapping Tab
            urlMappingData: [],
            selectedMeus: [],
            postUrlMappings: {
                "url-meu-mappings": {
                    "url-meu-mapping": [

                    ]
                }
            },
            urlMappingSelectedRowKeys: [],
            urlMappingVisible: false,//addUrlMapping Modal
            addUrlMappingData: initAddUrlMapping(),
            scripts: '',
            startTypeVisible: false,
            timerVisible: false,
            startNode: null,
            isTimer: false,
            timerList: [initStartTimer()],
            referenceVisible: false,
            linkLabel: null,
        }
    }

    componentDidMount = () => {
        const flowchartObj = {
            handleSetDiagram: this.handleSetDiagram,
            handleSetPalette: this.handleSetPalette,
            showMeuModal: this.showMeuModal,
            showLineInfo: this.showLineInfo,
            setTargetMeu: this.setTargetMeu,
            setSelectedLine: this.setSelectedLine,
            deleteNode: this.deleteNode,
            showUrlMapping: this.showUrlMapping,
            deleteInputParam: this.deleteInputParam,
            showStartType: this.showStartType,
            showTimer: this.showTimer,
            setStartNode: this.setStartNode,
            setIsTimer: this.setIsTimer,
            setTimerList: this.setTimerList,
            isEdit: this.props.isEdit,
            showReference: this.showReference,
            epgIsDI: this.epgIsDI,
            setLinkLabel: this.setLinkLabel,
        };


        if (this.props.isEdit) {
            let selectedEpg = { ...this.props.selectedEpg };
            let epgXmlJson = getXmlJsonData(selectedEpg.definition);

            // xml 数据
            this.setState({
                epgXmlStr: selectedEpg.definition
            })
            //scripts 数据
            if (selectedEpg.scripts.definition) {
                this.setState({
                    scripts: selectedEpg.scripts.definition
                })
            }
            //URLMapping数据
            if (selectedEpg.urlMappings.definition) {
                let urlMappingData = getXmlJsonData(selectedEpg.urlMappings.definition)
                let urlMappingArr = urlMappingData["url-meu-mappings"]["url-meu-mapping"];
                if (isArray(urlMappingArr)) {
                    urlMappingArr = urlMappingArr.map((item, index) => {
                        item.key = `${Date.now()}${index}`;
                        return item;
                    })
                } else if (isObject(urlMappingArr)) {
                    urlMappingArr.key = `${Date.now()}1`
                    urlMappingArr = [urlMappingArr];
                }
                this.setState({
                    urlMappingData: urlMappingArr
                })
            }
            //初始化Start
            let timers = epgXmlJson.epg.timers;
            if (timers) {
                let timerArr = timers.timer;
                if (isArray(timerArr)) {
                    timerArr = timerArr;
                } else if (isObject(timerArr)) {
                    timerArr = [timerArr];
                }
                timerArr = timerArr.map((timer, index) => {
                    let timerObj = {};
                    timerObj["id"] = timer["@id"];
                    timerObj["key"] = timer["@id"].split('-')[1];
                    timerObj["checked"] = false;
                    let events = epgXmlJson.epg.events
                    if (events) {
                        let eventArr = events.event;
                        if (isArray(eventArr)) {
                            eventArr = eventArr;
                        } else if (isObject(eventArr)) {
                            eventArr = [eventArr];
                        }
                        let startEvent = eventArr.filter(event => {
                            return event["@source"] === "timer";
                        })
                        if (startEvent.length > 0) {
                            startEvent = startEvent[0];
                            let timerId = startEvent["@timerId"];
                            if (timerId === timer["@id"]) {
                                timerObj["checked"] = true;
                            }
                        } else {
                            if (index === 0) {
                                timerObj["checked"] = true;
                            }
                        }
                    } else {
                        if (index === 0) {
                            timerObj["checked"] = true;
                        }
                    }

                    if ("@cron" in timer) {
                        timerObj["type"] = "cron";
                        timerObj["value"] = timer["@cron"];
                        timerObj["timeUnit"] = "microseconds";
                    } else if ("@period" in timer) {
                        timerObj["type"] = "period";
                        timerObj["value"] = timer["@period"];
                        timerObj["timeUnit"] = timer["@timeUnit"];
                    }
                    return timerObj;
                })
                this.setState({
                    isTimer: true,
                    timerList: timerArr
                })
            }


            //inputParamList 数据
            let linkDataArray = JSON.parse(selectedEpg.graphInfo).linkDataArray;
            this.editEpgHasReturn(linkDataArray, this.props.projectMeuList);

            //初始化meu table List
            let meuDatas = JSON.parse(JSON.stringify(this.props.projectMeuList));
            let selectedMeus = [];

            let editMeus = epgXmlJson.epg.meus ? epgXmlJson.epg.meus.meu : null;
            if (editMeus && isArray(editMeus)) {
                editMeus = editMeus
            } else if (editMeus && isObject(editMeus)) {
                editMeus = [editMeus];
            }
            if (editMeus && editMeus.length > 0) {
                for (let i = 0; i < editMeus.length; i++) {
                    meuDatas = meuDatas.filter(item => {
                        if (item.id === editMeus[i]["@id"]) {
                            selectedMeus.push(item);
                            let meuType = item.type;
                            if (meuType === "webApi") {
                                this.setState({
                                    urlMapingVisible: false
                                })
                            }
                            return false;
                        } else {
                            return true;
                        }

                    })
                }
            }
            flowchartObj.graphModel = selectedEpg.graphInfo;
            this.setState({
                meuList: meuDatas,
                selectedMeus
            })
        } else {
            flowchartObj.graphModel = '';
        }
        initFlowchart(flowchartObj);
    }

    render() {
        const meuColumns = [
            {
                title: 'MEU Name',
                dataIndex: 'name',
                key: 'name',
            },
            {
                title: 'MEU Group',
                dataIndex: 'group',
                key: 'group',
            },
            {
                title: 'MEU Version',
                dataIndex: 'version',
                key: 'version',
            },
        ];

        const urlMappingColumns = [
            {
                title: 'URL',
                dataIndex: '@url',
                key: 'url',
            },
            {
                title: 'MEU',
                dataIndex: '@dest',
                key: 'dest',
            },
            {
                title: 'Operation ID',
                dataIndex: '@operationId',
                key: 'operationId',
            },
            {
                title: 'Method',
                dataIndex: '@method',
                key: 'method',
            },
            {
                title: 'Edit',
                dataIndex: '',
                key: 'edit',
                render: (value) => {
                    return <Button type="primary" size="small" onClick={this.editUrlMapping(value)}>
                        <Icon type="edit" style={{ fontSize: '20px' }} />
                    </Button>
                }
            }
        ];

        const rowSelection = {
            selectedRowKeys: this.state.selectedRowKeys,
            onChange: this.onSelectMeuChange
        };
        const urlMappingSelection = {
            selectedRowKeys: this.state.urlMappingSelectedRowKeys,
            onChange: this.onSelectUrlMappingChange
        };
        return (
            <div className="flowchart_box">
                <Tabs defaultActiveKey="1" onChange={this.changeTab}>
                    <TabPane tab="EPG" key="1">
                        <div className="epg_flowchart">
                            <div id="myPalette" className="palette"></div>
                            <div id="myDiagram" className="diagram"></div>
                        </div>
                        {
                            this.state.lineInfoVisible ?
                                <Dragger
                                    style={{
                                        zIndex: 1000,
                                        right: 50,
                                        top: 200,
                                        position: 'absolute',
                                        background: 'rgb(245,244,244)',
                                        border: '1px solid #000'
                                    }}>
                                    <LineInfo
                                        targetMeu={this.state.targetMeu}
                                        inputParamList={this.state.inputParamList}
                                        selectedLineInfo={this.state.selectedLineInfo}
                                        setSelectedLine={this.setSelectedLine}
                                        showLineInfo={this.showLineInfo}
                                        setInputParam={this.setInputParam}
                                        myDiagram={this.state.myDiagram}
                                    />
                                </Dragger> : null
                        }
                        {
                            this.state.referenceVisible ?
                                <Dragger
                                    style={{
                                        zIndex: 1000,
                                        left: 200,
                                        top: 200,
                                        position: 'absolute',
                                        background: 'rgb(245,244,244)',
                                        border: '1px solid #000'
                                    }}>
                                    <div className="reference_box">
                                        <p>
                                            Whether or not to set the two is DI
                                    </p>
                                        <div className="reference_btn">
                                            <Button type="primary" onClick={this.sureRef}>Yes</Button>
                                            <Button onClick={this.cancelRef}>No</Button>
                                        </div>
                                    </div>

                                </Dragger> : null
                        }

                        {
                            this.state.startTypeVisible ?
                                <Dragger
                                    style={{
                                        zIndex: 1000,
                                        right: 50,
                                        top: 200,
                                        position: 'absolute',
                                        background: 'rgb(245,244,244)',
                                        border: '1px solid #000'
                                    }}>
                                    <StartType
                                        showStartType={this.showStartType}
                                        startNode={this.state.startNode}
                                        setIsTimer={this.setIsTimer}
                                        setTimerList={this.setTimerList}
                                        initStartTimer={initStartTimer}
                                        timerList={this.state.timerList}
                                    />
                                </Dragger> : null
                        }

                        {
                            this.state.timerVisible ?
                                <Dragger
                                    style={{
                                        zIndex: 1000,
                                        right: 50,
                                        top: 200,
                                        position: 'absolute',
                                        background: 'rgb(245,244,244)',
                                        border: '1px solid #000'
                                    }}>
                                    <StartTimer
                                        timerList={this.state.timerList}
                                        initStartTimer={initStartTimer}
                                        startNode={this.state.startNode}
                                        showTimer={this.showTimer}
                                        setTimerList={this.setTimerList}
                                    />
                                </Dragger> : null
                        }

                    </TabPane>
                    <TabPane tab="URL Mapping" key="2" disabled={this.state.urlMapingVisible} >
                        <div className="url_mapping_box">
                            <div className="url_mapping_btns">
                                <Button type="primary" onClick={this.showAddUrlMapping}>Add</Button>
                                <Button
                                    type="primary"
                                    disabled={this.state.urlMappingSelectedRowKeys.length > 0 ? false : true}
                                    onClick={this.deleteUrlMapping}
                                >
                                    Delete
                                </Button>
                            </div>
                            <Table
                                rowSelection={urlMappingSelection}
                                columns={urlMappingColumns}
                                dataSource={this.state.urlMappingData}
                                pagination={false}
                            />
                        </div>
                    </TabPane>
                    <TabPane tab="Script" key="3">
                        <CodeMirror
                            value={this.state.scripts}
                            options={{
                                mode: 'javascript',
                                theme: 'material',
                                lineNumbers: true
                            }}
                            style={{
                                height: '500px'
                            }}
                            onBeforeChange={this.changeSCripts}
                        />
                    </TabPane>
                    <TabPane tab="XML" key="4">
                        <TextArea value={this.state.epgXmlStr} autosize={{ minRows: 20, maxRows: 50 }} />
                    </TabPane>
                </Tabs>
                <div className="btn_group" style={{ position: 'absolute', top: '16px', right: '50px' }}>
                    <Button type="primary" style={{ marginRight: '10px' }} onClick={this.saveEpg}>OK</Button>
                    <Button onClick={this.cancelEpg}>Cancel</Button>
                </div>
                <CloudModal
                    title="MEU List"
                    visible={this.state.meuVisible}
                    onOk={this.handleMeuSure}
                    onCancel={this.handleMeuCancel}
                    width="960px"
                >
                    <Table
                        rowSelection={rowSelection}
                        columns={meuColumns}
                        dataSource={this.state.meuList}
                        pagination={false}
                    />

                </CloudModal>


                <CloudModal
                    title="Url Mapping File"
                    visible={this.state.urlMappingVisible}
                    onOk={this.addUrlMappingOk}
                    onCancel={this.addUrlMappingCancel}
                    width="560px"
                >
                    <UrlMappingFile
                        selectedMeus={this.state.selectedMeus}
                        changeUrlMaping={this.changeUrlMaping}
                        addUrlMappingData={this.state.addUrlMappingData}
                    />
                </CloudModal>

                <Prompt message="Are you sure you want to leave?" when={true}/>
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    state = state.toJS();
    return {
        projectMeuList: state.market.projectMeuList,
        selectedProject: state.project.selectedProject,
        selectedEpg: state.projectEpg.selectedEpg,
        isEdit:state.projectEpg.isEdit
    }
}
const mapDispatchToProps = (dispatch) => ({
    setSelectedEpg: (data) => {
        dispatch(setSelectedEpg({
            epg: data
        }))
    },
    addProjectEpg:(data)=>{
        dispatch(addProjectEpg({
            epg:data
        }))
    },
    editProjectEpg:(data)=>{
        dispatch(editProjectEpg({
            epg:data
        }))
    }
})
MyDiagram = withRouter(MyDiagram);
export default connect(mapStateToProps,mapDispatchToProps )(MyDiagram);