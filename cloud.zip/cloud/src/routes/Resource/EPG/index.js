import React, { Component } from 'react';
import Page from '../../../components/Page';
import Bread from '../../../components/Bread';
import List from './EpgList';
import MyDiagram from './MyDiagram';
import { breadMap } from './config';

class EPG extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isFlowchart:false,
    }
  }

  showFlowchart=(value)=>{
      this.setState({
        isFlowchart:value
      })
  }

  render() {
    return (
      <Page>
        <Bread breadMap={breadMap} />
        {
          this.state.isFlowchart?
          <MyDiagram 
            showFlowchart={this.showFlowchart}
          />:
          <List 
            showFlowchart={this.showFlowchart}
          />
        } 
      </Page>
    )
  }
}

export default EPG;