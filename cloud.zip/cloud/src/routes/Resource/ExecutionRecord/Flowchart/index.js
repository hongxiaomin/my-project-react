import React, { Component } from 'react';
import './style.less';


class Flowchart extends Component {
  constructor(props) {
    super(props);
  }
  render() {
    return (
      <div className="execution_flowchart">
          Flowchart
      </div>
    )
  }
}

export default Flowchart;