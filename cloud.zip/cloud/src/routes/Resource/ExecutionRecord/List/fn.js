export const onSelectedChange =_this=> (selectedRowKeys)=>{
    console.log('selectedRowKeys changed: ', selectedRowKeys);
} 

export const changeQueryParams=_this=>(newValue)=>{
    _this.setState({
        searchParams:{..._this.state.searchParams,newValue}
    })
}



