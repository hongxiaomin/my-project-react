import React, { Component } from 'react';
import { Table,Row,Col,Button } from 'antd';
import TextField from '../../../../components/TextField';
import {
  onSelectedChange,
  changeQueryParams
} from './fn';
import {
  tableData,
  style
} from './config.js';

import './style.less';

const columns=[
  {
      title: 'Executed ID',
      dataIndex: 'executedId',
      key:'executedId',
  },
  {
    title: 'EPG ID',
    dataIndex: 'epgId',
    key:'epgId',
  },
  {
    title: 'Create Date',
    dataIndex: 'createDate',
    key:'createDate',
  },
  {
    title: 'Status',
    dataIndex: 'status',
    key:'status',
  }
];

class List extends Component {
  constructor(props) {
    super(props);
    this.onSelectedChange=onSelectedChange(this);
    this.changeQueryParams=changeQueryParams(this);
    this.state={
      dataSource:[],
      selectedRowKeys:[],
      searchParams:{},
    }
  }
  componentWillMount(){
    this.setState({
      dataSource:tableData
    })
  }
  
  render() {
    const {dataSource,selectedRowKeys} = this.state;
    const {showFlowchart} = this.props;
     const rowSelection = {
      selectedRowKeys,
      onChange:this.onSelectedChange,
      type:'radio'
    }
    return (
      <div className="execution-list">
      <div className="qurey_params">
        <Row>
            <Col span={6}>
              <TextField text="EPG ID" handlerChange={this.changeQueryParams} field="epgId"/>
            </Col>
            <Col span={6}>
              <TextField text="Status" handlerChange={this.changeQueryParams} field="status"/>
            </Col>
            <Col span={4}>
              <Button type="primary" style={{marginTop:'26px'}} onClick={this.search}>Search</Button>
            </Col>
          </Row>
      </div>
        <Table 
          rowSelection={rowSelection}
          columns={columns} 
          dataSource={dataSource}
        />
      </div>
    )
  }
}

export default List;