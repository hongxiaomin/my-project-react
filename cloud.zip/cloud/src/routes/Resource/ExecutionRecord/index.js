import React, { Component } from 'react';
// import { Loading } from '@delta/common-utils';
import Page from '../../../components/Page';
import Bread from '../../../components/Bread';
import Flowchart from './Flowchart';
import List from './List'
import { breadMap } from './config';
import {
  showFlowchart,
  changeUpdateApp,
  changeIsUpdate
} from './fn'


class ExecutionRecord extends Component {
  constructor(props) {
    super(props);
    this.showFlowchart=showFlowchart(this);
    this.state = {
      loading: false,
      isList:true,
    }
  }

  render() {
    return (
      <Page>
        {/* <Loading visible={this.state.loading} /> */}
        <Bread breadMap={breadMap} />
          {
            this.state.isList?
            <List
              showFlowchart={this.showFlowchart}
            />:
            <Flowchart
              showFlowchart={this.showFlowchart}
            />
          }
      </Page>
    )
  }
}

export default ExecutionRecord;