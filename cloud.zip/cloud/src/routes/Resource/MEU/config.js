import {SERVER_IP} from '../../../constants/Config';
export const deleteProjectMeuUrl = `${SERVER_IP}/cloudServer/project/meu`;
export const getProjectMeuUrl = `${SERVER_IP}/cloudServer/project/meu`;
export const breadMap = [
    {
        path:'',
        name:'Index'
    },
    {
        path:'',
        name:'Resource'
    },
    {
      path:'',
      name:'MEU'
    }
  ];