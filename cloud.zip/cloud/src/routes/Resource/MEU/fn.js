import request from '../../../utils/fetchData';
import {deleteProjectMeuUrl,getProjectMeuUrl} from './config';
import {message} from 'antd';
export const handleClickMeu=_this=>(data)=>()=>{
    _this.setState({
        meuInfo:data,
        meuVisible:true,
    })
}

export const getProjectMeuList=_this=>async(project,cb)=>{
    let response =await request(getProjectMeuUrl,{
        data:{projectId:project.id}
    });
    if(response.message.code===0){
        let data=response.message.rows;
        let newData = data.map(item=>{
            let id = `${item.group}/${item.name}/${item.version}`;
            let key =id;
            return {...item,id,key};
        })
        cb(newData);
    }else{
        message.error(`Get Project ${project.name} meu error!`)
    }
}

export const handleDeleteProjectMeu=_this=>(data)=>(e)=>{
    e.stopPropagation();
    let selectedProject = _this.props.selectedProject;
    let deleteData = {
        projectId:selectedProject.id,
        meus:[
            {
                group:data.group,
                name:data.name,
                version:data.version
            }
        ]
    };
    _this.deleteProjectMeuData(deleteData,()=>{
        _this.props.deleteProjectMeu(data);
    })
}

export const deleteProjectMeuData = _this =>async(deleteData,cb)=>{
    let response = await request(deleteProjectMeuUrl,{
        method: 'DELETE',
        data: JSON.stringify(deleteData),
        contentType: 'raw',
        headers: new Headers(),
    });
    if(response.message.code===0){
        let result = response.message.rows[0];
        if(result.result.indexOf('Success')>-1){
            message.success(`Delete Meu Success!`);
            cb();
        }else{
            message.error(result.result);
        }
    }else{
        message.error(response.message.message);
    }
}

export const handleMeuDetail=_this=>()=>{
    _this.setState({
        meuVisible:false
    })
}

export const handleClickLicenseNum=_this=>(data)=>(e)=>{
    e.stopPropagation();
    let license = data.license;
    if(license){
        license=license.licenseList.map(item=>{
            let key = item.licenseId;
            let name = data.name;
            let group = data.group;
            let version = data.version;
            return {...item,key,group,name,version};
        })
    }else{
        license=[];
    } 

    _this.setState({
        licenseVisible:true,
        meuInfo:data,
        meuLicense:license
    })
}

export const handleCancelLicense=_this=>()=>{
    _this.setState({
        licenseVisible:false,
        meuInfo:null
    })
}