import React, { Component } from 'react';
import { connect } from 'react-redux';
import { toJS } from 'immutable';
import { Modal, Table } from 'antd';
import Page from '../../../components/Page';
import Bread from '../../../components/Bread';
import MeuItem from '../../../components/MeuItem';
import MeuInfo from '../../../components/MeuInfo';
import CloudModal from '../../../components/CloudModal';
import {
    deleteProjectMeu,
    setProjectMeuList,
} from '../../../actions';
import { breadMap } from './config';
import {
    handleClickMeu,
    handleDeleteProjectMeu,
    deleteProjectMeuData,
    handleMeuDetail,
    getProjectMeuList,
    handleClickLicenseNum,
    handleCancelLicense,
} from './fn';

class MEU extends Component {
    constructor(props) {
        super(props);
        this.handleClickMeu = handleClickMeu(this);
        this.handleDeleteProjectMeu = handleDeleteProjectMeu(this);
        this.deleteProjectMeuData = deleteProjectMeuData(this);
        this.handleMeuDetail = handleMeuDetail(this);
        this.getProjectMeuList = getProjectMeuList(this);
        this.handleClickLicenseNum = handleClickLicenseNum(this);
        this.handleCancelLicense = handleCancelLicense(this);

        this.state = {
            meuVisible: false,
            meuInfo: null,
            licenseVisible: false,
            meuLicense: []
        }
    }

    componentDidMount() {
        let selectedProject = this.props.selectedProject;
        if (selectedProject) {
            this.getProjectMeuList(selectedProject, data => {
                this.props.setProjectMeuList(data);
            })
        }

    }

    render() {
        const columns = [
            {
                title: 'License ID',
                dataIndex: 'licenseId',
                key: 'licenseId',
                render:(value,record)=>{
                    let licenseId=`*${value.substr(-6)}`;
                    return <a alt={value}>{licenseId}</a>
                },
                width:'10%'
            },
            {
                title: 'Group',
                dataIndex: 'group',
                key: 'group',
                width:'10%'
            },
            {
                title: 'Name',
                dataIndex: 'name',
                key: 'name',
                width:'10%'
            },
            {
                title: 'Version',
                dataIndex: 'version',
                key: 'version',
                width:'10%'
            },
            {
                title: 'Trial',
                dataIndex: 'trial',
                key: 'trial',
                render:(value,record)=>{
                    return value?'true':'false'
                },
                width:'8%'
            },
            {
                title: 'Status',
                dataIndex: 'status',
                key: 'status',
                width:'10%'
            },
            {
                title: 'AppName',
                dataIndex: 'appName',
                key: 'appName',
                width:'12%'
            },
            {
                title: 'Expire Date',
                dataIndex: 'expireDate',
                key: 'expireDate',
                width:'15%'
            },
            {
                title: 'Purchase Date',
                dataIndex: 'purchaseDate',
                key: 'purchaseDate',
                width:'15%'
            },
        ]
        return (
            <Page>
                <Bread breadMap={breadMap} />
                <div className="card_section">
                    {
                        this.props.projectMeuList.map(item => {
                            return <MeuItem
                                data={item}
                                key={item.key}
                                handleClickMeu={this.handleClickMeu(item)}
                                handleDeleteProjectMeu={this.handleDeleteProjectMeu(item)}
                                handleClickLicenseNum={this.handleClickLicenseNum(item)}
                                meuType="2"
                            />
                        })
                    }
                </div>
                <CloudModal
                    title="MEU Detail"
                    visible={this.state.meuVisible}
                    onOk={this.handleMeuDetail}
                    onCancel={this.handleMeuDetail}
                    width="860px"
                >
                    <MeuInfo data={this.state.meuInfo} dataType="meu" />
                </CloudModal>

                <Modal
                    visible={this.state.licenseVisible}
                    title="MEU License Information"
                    width='960px'
                    footer={null}
                    destroyOnClose={true}
                    onCancel={this.handleCancelLicense}
                >
                    <Table dataSource={this.state.meuLicense} columns={columns} scroll={{x:1200,y:300}}/>
                </Modal>

            </Page>
        )
    }
}

const mapStateToProps = (state) => {
    state = state.toJS();
    return {
        projectMeuList: state.market.projectMeuList,
        selectedProject: state.project.selectedProject
    }
};

const mapDispatchToProps = (dispatch) => ({
    deleteProjectMeu: (data) => {
        dispatch(deleteProjectMeu({
            meu: data
        }))
    },
    setProjectMeuList: (data) => {
        dispatch(setProjectMeuList({
            projectMeuList: data
        }))
    }
})

export default connect(mapStateToProps, mapDispatchToProps)(MEU);