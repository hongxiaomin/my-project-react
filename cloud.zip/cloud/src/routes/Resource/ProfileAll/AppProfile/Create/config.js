import {SERVER_IP} from '../../../../../constants/Config';
export const getMeuConfigUrl = `${SERVER_IP}/cloudServer/marketplace/meu/configuration`;
export const postAppProfileUrl=`${SERVER_IP}/cloudServer/appProfile`;
export const putAppProfileUrl=`${SERVER_IP}/cloudServer/appProfile`;
export const containerType='CONTAINER';
