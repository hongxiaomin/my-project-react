import { message } from 'antd';
import request from '../../../../../utils/fetchData';
import { containerType, getMeuConfigUrl, postAppProfileUrl,putAppProfileUrl } from './config';

export const addTreeData = _this => (store, data) => () => {
    _this.setState({
        meuVisible: true,
        selectedNode: data
    })
}

export const deleteTreeData = _this => (store, data) => () => {
    let meuList = [..._this.state.meuList];
    let treeData = [..._this.state.treeData];
    let mapping = [..._this.state.mapping];
    meuList.push({
        key: data.id,
        label: data.label,
        value: data.id
    });
    treeData = treeData.map(item => {
        item.children = item.children.filter(node => {
            return node.id !== data.id
        });
        return item;
    });
    mapping = mapping.map(item => {
        item.meuIds = item.meuIds.filter(id => {
            return id !== data.id;
        })
        return item;
    });
    _this.setState({
        meuList,
        treeData,
        mapping,
    })
}

export const changeAppProfile = _this => (e) => {
    let value = e.target.value.trim();
    _this.setState({
        appProfileId: value
    })
}

export const changeEnvProfileId = _this => (value) => {
    let envProfileList = [..._this.props.envProfileList];
    let currentEnvProfile = envProfileList.filter(item => {
        return item.id === value;
    })[0];
    let containers = currentEnvProfile.components.filter(item => {
        return item.type === containerType;
    });
    let mapping = [];
    let treeData = containers.map(item => {
        mapping.push({
            "containerId": item.id,
            "meuIds": []
        });
        return {
            id: item.id,
            label: item.id,
            children: []
        }
    });
    _this.setState({
        treeData,
        envProfileId: value,
        mapping
    })
}


export const changeAppId = _this => (value) => {
    let isAppEdit = _this.props.isAppEdit;
    let appList = _this.props.appList;
    let currentApp = appList.filter(item => {
        return item.id === value;
    })[0];
    let selectedAppProfile=_this.props.selectedAppProfile;
    let selectedAppMeus = currentApp.meus;
    let originMeus = JSON.parse(JSON.stringify(selectedAppMeus));

    if(isAppEdit&&value===selectedAppProfile.appProfileId){
        let selectedMeusObj = {};
        for (let i = 0; i < selectedAppMeus.length; i++) {
            let id = selectedAppMeus[i].id;
            selectedMeusObj[id] = selectedAppMeus[i];
        }
        let mapping = selectedAppProfile.containerMeuMappings;
        let meus = selectedAppProfile.meus;
        let treeData = mapping.map(item => {
            let id = item.containerId;
            let label = item.containerId;
            let children = [];
            for (let i = 0; i < item.meuIds.length; i++) {
                let meuId = item.meuIds[i];
                let currentMeu = selectedMeusObj[meuId];
                let meuLabel = `${currentMeu.group}/${currentMeu.name}/${currentMeu.version}`;
                children.push({ id: meuId, label: meuLabel });
            }
            return {
                id: id,
                label: label,
                children: children
            }
        });
        _this.setState({
            treeData,
            appId: value,
            meuList:[],
            meus,
            originMeus,
            mapping
        })
        
    }else{
        let meus = [];
        let meuList = selectedAppMeus.map(item => {
            let id = item.id;
            let name = `${item.group}/${item.name}/${item.version}`;
            meus.push({
                id,
                configs: []
            });
            return {
                key: id,
                label: name,
                value: id
            }
        })

        let treeData=[..._this.state.treeData];
        treeData=treeData.map(item=>{
            item.children=[];
            return item;
        });

        let mapping = [..._this.state.mapping];
        mapping=mapping.map(item=>{
            item.meuIds=[];
            return item;
        })

        _this.setState({
            appId: value,
            meuList,
            meus,
            originMeus,
            treeData,
            mapping
        })
    }
  
}

export const checkAllMeus = _this => (e) => {
    let checkedMeus = [];
    if (e.target.checked) {
        checkedMeus = _this.state.meuList.map(item => {
            return item.value;
        })
    } else {
        checkedMeus = [];
    }
    _this.setState({
        checkedMeus,
        meuCheckAll: e.target.checked
    })
}

export const checkMeus = _this => (checkedList) => {
    _this.setState({
        checkedMeus: checkedList,
        meuCheckAll: checkedList.length === _this.state.meuList.length,
    })
}

export const addMeuSure = _this => () => {
    let checkedMeus = [..._this.state.checkedMeus];
    let treeData = [..._this.state.treeData];
    let selectedNode = _this.state.selectedNode;
    let meuList = [..._this.state.meuList];
    let selectedMeus = [];
    let mapping = [..._this.state.mapping];

    for (let i = 0; i < checkedMeus.length; i++) {
        meuList = meuList.filter(item => {
            if (item.value === checkedMeus[i]) {
                selectedMeus.push({
                    id: item.value,
                    label: item.label
                })
            }
            return item.value !== checkedMeus[i];
        })
    };

    treeData = treeData.map(item => {
        if (item.id === selectedNode.id) {
            item.children = item.children.concat(selectedMeus);
        }
        return item;
    })

    mapping = mapping.map(item => {
        if (item.containerId === selectedNode.id) {
            item.meuIds = item.meuIds.concat(checkedMeus);
        }
        return item;
    })

    _this.setState({
        treeData,
        meuList,
        mapping,
        selectedNode: null,
        meuCheckAll: false,
        checkedMeus: [],
        meuVisible: false
    })
}

export const addMeuCancel = _this => () => {
    _this.setState({
        selectedNode: null,
        meuCheckAll: false,
        checkedMeus: [],
        meuVisible: false
    })

}

export const showMeuInfo = _this => (propertyModalData, propertyModalParam) => () => {
    _this.setState({
        propertyVisible: true,
        propertyModalData,
        propertyModalParam,
    })
}


export const handlePropertySure = _this => () => {
    let propertyModalData = { ..._this.state.propertyModalData };
    let propertyModalParam = { ..._this.state.propertyModalParam };
    let configs = propertyModalData.configs;
    let meuId = propertyModalData.id;
    configs = configs.map(item => {
        if (item.fileName === propertyModalParam.fileName) {
            item.content = propertyModalParam.content;
        }
        return item;
    })

    let originMeus = [..._this.state.originMeus];
    let selectedAppProfile = { ..._this.props.selectedAppProfile };
    originMeus = originMeus.map(item => {
        if (item.id === meuId) {
            item.configs = JSON.parse(JSON.stringify(configs));
        }
        return item;
    })
    let meus = [...selectedAppProfile.meus];
    meus = meus.map(item => {
        if (item.id === meuId) {
            item.configs = JSON.parse(JSON.stringify(configs));
        }
        return item;
    });
    selectedAppProfile = { ...selectedAppProfile, meus };
    _this.props.setSelectedApp(selectedAppProfile);
    _this.setState({
        originMeus,
        propertyVisible: false,
        propertyModalData: null,
        propertyModalParam: null
    })
}

export const handlePropertyCancel = _this => () => {
    _this.setState({
        propertyVisible: false,
        propertyModalData: null,
        propertyModalParam: null
    })
}

export const changeMeuContent = _this => (e) => {
    let propertyModalParam = JSON.parse(JSON.stringify(_this.state.propertyModalParam));
    propertyModalParam.content = e.target.value;
    _this.setState({
        propertyModalParam
    })

}

export const next = _this => () => {
    let current = _this.state.current;
    if (current === 0) {
        let appProfileId = _this.state.appProfileId;
        let envProfileId = _this.state.envProfileId;
        let appId = _this.state.appId;
        if (!appProfileId || !envProfileId || !appId) {
            message.error('Input available value!');
            return;
        }
        let profile = {
            envProfileId,
            appProfileId,
            appId
        };
        let selectedAppProfile;
        if(_this.props.isAppEdit&&_this.props.selectedAppProfile){
            selectedAppProfile=_this.props.selectedAppProfile
        }else{
            selectedAppProfile = {};
        }

        selectedAppProfile = { ...selectedAppProfile, ...profile };
        _this.props.setSelectedApp(selectedAppProfile);
        current = current + 1;
        _this.setState({
            current
        })
    } else if (current === 1) {
        let meuList = [..._this.state.meuList];
        if (meuList.length > 0) {
            message.error('Container Meu Mapping is error!');
            return;
        }
        let meus = [..._this.state.meus];
        let originMeus = [..._this.state.originMeus];
        for (let i = 0; i < originMeus.length; i++) {
            _this.getMeuConfig(originMeus[i], (data) => {
                meus = meus.map(item => {
                    if (item.id === originMeus[i].id) {
                        item.configs = JSON.parse(JSON.stringify(data));
                        originMeus[i].configs = JSON.parse(JSON.stringify(data));
                    }
                    return item;
                })
                let selectedAppProfile = _this.props.selectedAppProfile;
                selectedAppProfile = { ...selectedAppProfile, "meus": meus };
                _this.props.setSelectedApp(selectedAppProfile);
            })
        }

        let selectedAppProfile = _this.props.selectedAppProfile;
        let mapping = [..._this.state.mapping];
        selectedAppProfile = { ...selectedAppProfile, "meus": meus, "containerMeuMappings": mapping };
        _this.props.setSelectedApp(selectedAppProfile);

        current = current + 1;
        _this.setState({
            current
        })
    }

}

export const getMeuConfig = _this => async (meu, cb) => {
    let response = await request(getMeuConfigUrl, {
        data: {
            group: meu.group,
            name: meu.name,
            version: meu.version
        }
    });
    if (response.message.code === 0) {
        let data = response.message.rows;
        cb(data);
    }
}

export const postAppProfile = _this => async (postData, cb) => {
    let response = await request(postAppProfileUrl, {
        data: JSON.stringify(postData),
        method: 'POST',
        contentType: 'raw',
        headers: new Headers()
    });
    if (response.message.code === 0) {
        message.success(`Create App Profile ${postData.appProfileId} Success!`);
        let data = response.message.rows;
        let key = data.id;
        data = { ...data, key };
        cb(data);
    } else {
        message.error(response.message.message)
    }
}

export const putAppProfile = _this => async (putData, cb) => {
    let response = await request(putAppProfileUrl, {
        data: JSON.stringify(putData),
        method: 'PUT',
        contentType: 'raw',
        headers: new Headers()
    });
    if (response.message.code === 0) {
        message.success(`Edit App Profile ${putData.appProfileId} Success!`);
        let data = response.message.rows;
        let key = data.id;
        data = { ...data, key };
        cb(data);
    } else {
        message.error(response.message.message)
    }
}

export const submitProfile = _this => () => {
    let selectedAppProfile = _this.props.selectedAppProfile;
    if(_this.props.isAppEdit){
        _this.putAppProfile(selectedAppProfile,(data)=>{
            _this.props.updateAppProfile(data);
            _this.props.setSelectedApp(null);
            _this.props.showCreate(false);
        })

    }else{
        _this.postAppProfile(selectedAppProfile, (data) => {
            _this.props.addAppProfile(data);
            _this.props.setSelectedApp(null);
            _this.props.showCreate(false);
        })
    }


}

export const cancelProfile = _this => () => {
    _this.props.setSelectedApp(null);
    _this.props.showCreate(false);
}