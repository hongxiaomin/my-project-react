import React, { Component } from 'react';
import { connect } from 'react-redux';
import { toJS } from 'immutable';
import { withRouter,Prompt } from 'react-router-dom';
import { Steps, Button, message, Row, Col, Input, Icon, Checkbox, Collapse, List, Select } from 'antd';
import { Tree } from 'element-react';
import 'element-theme-default';
import CloudModal from '../../../../../components/CloudModal';
import {
    setSelectedApp,
    addAppProfile,
    updateAppProfile,
} from '../../../../../actions';
import {
    addTreeData,
    deleteTreeData,
    changeAppProfile,
    changeEnvProfileId,
    changeAppId,
    checkAllMeus,
    checkMeus,
    addMeuSure,
    addMeuCancel,
    showMeuInfo,
    handlePropertySure,
    handlePropertyCancel,
    changeMeuContent,
    next,
    submitProfile,
    cancelProfile,
    getMeuConfig,
    postAppProfile,
    putAppProfile,
} from './fn';

import './style.less';


const Step = Steps.Step;
const TreeNode = Tree.TreeNode;
const CheckboxGroup = Checkbox.Group;
const Panel = Collapse.Panel;
const Option = Select.Option;
const { TextArea } = Input;

class Create extends Component {
    constructor(props) {
        super(props);
        this.addTreeData = addTreeData(this);
        this.deleteTreeData = deleteTreeData(this);
        this.changeAppProfile = changeAppProfile(this);
        this.changeEnvProfileId = changeEnvProfileId(this);
        this.changeAppId = changeAppId(this);
        this.checkAllMeus = checkAllMeus(this);
        this.checkMeus = checkMeus(this);
        this.showMeuInfo = showMeuInfo(this);
        this.handlePropertySure = handlePropertySure(this);
        this.handlePropertyCancel = handlePropertyCancel(this);
        this.changeMeuContent = changeMeuContent(this);
        this.next = next(this);
        this.submitProfile = submitProfile(this);
        this.cancelProfile = cancelProfile(this);
        this.addMeuSure = addMeuSure(this);
        this.addMeuCancel = addMeuCancel(this);
        this.getMeuConfig = getMeuConfig(this);
        this.postAppProfile = postAppProfile(this);
        this.putAppProfile = putAppProfile(this);

        this.state = {
            current: 0,//当前步数
            appProfileId: '',//app Profile ID
            envProfileId: '',
            appId: '',
            treeData: [],//树形结构数据
            treeOption: {//树形结构配置
                children: 'children',
                label: 'label'
            },
            selectedNode: null,//当前操作的树形结构项
            originMeus: [],
            meus: [],//需要提交的meus
            meuVisible: false,//meu选框显示
            meuCheckAll: false,//meu全选状态
            checkedMeus: [],//当前被选中的meu
            meuList: [],//可显示的meu数据
            mapping: [],//需要提交mapping关系
            propertyVisible: false,//config 弹框显示状态
            propertyModalData: null,//config 弹框父级信息
            propertyModalParam: null,//config 弹框参数信息
        };
    }

    componentWillMount() {
        let isAppEdit = this.props.isAppEdit;
        let selectedAppProfile = this.props.selectedAppProfile;
        if (isAppEdit) {
            let appProfileId = selectedAppProfile.appProfileId;
            let envProfileId = selectedAppProfile.envProfileId;
            let appId = selectedAppProfile.appId;
            let appList = this.props.appList;
            let selectedApp = appList.filter(item => {
                return item.id === appId;
            })[0];
            let selectedAppMeus = selectedApp.meus;
            let originMeus = JSON.parse(JSON.stringify(selectedAppMeus));
            let selectedMeusObj = {};
            for (let i = 0; i < selectedAppMeus.length; i++) {
                let id = selectedAppMeus[i].id;
                selectedMeusObj[id] = selectedAppMeus[i];
            }
            let mapping = selectedAppProfile.containerMeuMappings;
            let meus = selectedAppProfile.meus;
            let treeData = mapping.map(item => {
                let id = item.containerId;
                let label = item.containerId;
                let children = [];
                for (let i = 0; i < item.meuIds.length; i++) {
                    let meuId = item.meuIds[i];
                    let currentMeu = selectedMeusObj[meuId];
                    let meuLabel = `${currentMeu.group}/${currentMeu.name}/${currentMeu.version}`;
                    children.push({ id: meuId, label: meuLabel });
                }
                return {
                    id: id,
                    label: label,
                    children: children
                }
            });
            this.setState({
                appProfileId,
                envProfileId,
                appId,
                originMeus,
                mapping,
                treeData,
                meus,
            })
        } else {
            if (this.props.location.search) {
                let search = this.props.location.search;
                let appId = search.split('?')[1].split('=')[1];
                if (appId) {
                    let appList = this.props.appList;
                    if(appList.length===0){
                        this.props.history.push('/resource/profile/appProfile');
                        this.props.showCreate(false);
                        return;
                    }
                    if(appList.length>0){
                        let currentApp = appList.filter(item => {
                            return item.id === appId;
                        })[0];
                        let meuList = currentApp.meus;
                        let meus = [];
                        let originMeus = [];
                        meuList = meuList.map(item => {
                            let id = item.id;
                            let name = `${item.group}/${item.name}/${item.version}`;
                            originMeus.push(item);
                            meus.push({
                                id,
                                configs: []
                            });
                            return {
                                key: id,
                                label: name,
                                value: id
                            }
                        })
                        this.setState({
                            appId,
                            meuList,
                            meus,
                            originMeus
                        })
                    }
                    
                }
            }
        }
    }

    treeRenderContent = (nodeModel, data, store) => {
        let btnGroup = null;
        if (data.children) {
            btnGroup = <span style={{ float: 'right', marginRight: '20px', marginTop: '2px' }}>
                <Button onClick={this.addTreeData(store, data)}>Append</Button>
            </span>
        } else {
            btnGroup = <span style={{ float: 'right', marginRight: '20px', marginTop: '2px' }}>
                <Button onClick={this.deleteTreeData(store, data)}>Delete</Button>
            </span>
        }
        return (
            <span>
                <span>
                    <span>{data.label}</span>
                </span>
                {btnGroup}
            </span>
        )
    }

    render() {
        const { group, name, version } = this.state.propertyModalData ? this.state.propertyModalData : {};
        const steps = [{
            title: 'Create',
            content: <div className="create_box">
                <div className="create_item">
                    <label>App Profile ID:</label>
                    <Input style={{ width: 360 }} onChange={this.changeAppProfile} value={this.state.appProfileId} />
                </div>
                <div className="create_item">
                    <label> Environment Proile ID:</label>
                    <Select
                        showSearch
                        style={{ width: 360 }}
                        placeholder="Select a Environment Profile ID"
                        optionFilterProp="children"
                        onChange={this.changeEnvProfileId}
                        filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
                        defaultValue={this.state.envProfileId}
                    >
                        {
                            this.props.envProfileList.map((item, index) => {
                                return <Option value={item.id} key={item.id}>{item.envProfileId}</Option>
                            })
                        }
                    </Select>
                </div>
                <div className="create_item">
                    <label>App:</label>
                    <Select
                        showSearch
                        style={{ width: 360 }}
                        placeholder="Select a App"
                        optionFilterProp="children"
                        onChange={this.changeAppId}
                        filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
                        defaultValue={this.state.appId}
                    >
                        {
                            this.props.appList.map((item, index) => {
                                if (item.status === 2) {
                                    return <Option value={item.id} key={item.id}>{item.name}</Option>
                                }
                            })
                        }
                    </Select>
                </div>
            </div>,
        }, {
            title: 'Mapping',
            content: <div className="mapping_box">
                <div className="mapping_content_box">
                    <div className="tree_box">
                        {
                            this.state.treeData.length > 0 ?
                                <div>
                                    <Tree
                                        data={this.state.treeData}
                                        options={this.state.treeOption}
                                        nodeKey="id"
                                        defaultExpandAll={true}
                                        expandOnClickNode={false}
                                        renderContent={(...args) => this.treeRenderContent(...args)}
                                    />
                                </div> : null
                        }
                    </div>
                </div>
                <CloudModal
                    title="MEU"
                    visible={this.state.meuVisible}
                    onOk={this.addMeuSure}
                    onCancel={this.addMeuCancel}
                    width="500px"
                >
                    <div className="component_box">
                        <div className="check_all">
                            <Checkbox checked={this.state.meuCheckAll} onChange={this.checkAllMeus}>Check All</Checkbox>
                        </div>
                        <CheckboxGroup options={this.state.meuList} value={this.state.checkedMeus} onChange={this.checkMeus} />
                    </div>
                </CloudModal>
            </div>,
        }, {
            title: 'Config',
            content: <div>
                <Collapse defaultActiveKey={"1"}>
                    {
                        this.state.originMeus.map((item, index) => {

                            return (
                                <Panel header={`${item.group}/${item.name}/${item.version}`} key={index + 1}>
                                    <List
                                        split
                                        dataSource={item.configs}
                                        renderItem={listItem => (<List.Item onClick={this.showMeuInfo(item, listItem)}>{listItem.fileName}</List.Item>)}
                                    />
                                </Panel>
                            )

                        })
                    }
                </Collapse>
                {
                    this.state.propertyVisible ? <CloudModal
                        title={`${group}/${name}/${version}  ${this.state.propertyModalParam.fileName}`}
                        visible={this.state.propertyVisible}
                        onOk={this.handlePropertySure}
                        onCancel={this.handlePropertyCancel}
                        width="960px"
                    >
                        <TextArea onChange={this.changeMeuContent} defaultValue={this.state.propertyModalParam.content} autosize={{ minRows: 6, maxRows: 20 }} />

                    </CloudModal> : null
                }

            </div>,
        }];
        const { current } = this.state;
        return (
            <div>
                <Steps current={current}>
                    {steps.map(item => <Step key={item.title} title={item.title} />)}
                </Steps>
                <div className="steps-content">{steps[this.state.current].content}</div>
                <div className="steps-action">
                    {
                        this.state.current < steps.length - 1
                        &&
                        <div>
                            <Button type="primary" onClick={this.next}>Next</Button>
                            <Button onClick={this.cancelProfile} style={{ marginLeft: '30px' }}>Cancel</Button>
                        </div>
                    }
                    {
                        this.state.current === steps.length - 1
                        &&
                        <div>
                            <Button type="primary" onClick={this.submitProfile}>Done</Button>
                            <Button onClick={this.cancelProfile} style={{ marginLeft: '30px' }}>Cancel</Button>
                        </div>

                    }
                </div>
                <Prompt message="Are you sure you want to leave?" when={true}/>
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    state = state.toJS();
    return {
        selectedAppProfile: state.profile.selectedAppProfile,
        selectedProject: state.project.selectedProject,
        isAppEdit: state.profile.isAppEdit,
        envProfileList: state.profile.envProfileList,
        appList: state.projectApp.appList,
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        setSelectedApp: (data) => {
            dispatch(setSelectedApp({
                profile: data
            }))
        },
        addAppProfile: (data) => {
            dispatch(addAppProfile({
                profile: data
            }))
        },
        updateAppProfile: (data) => {
            dispatch(updateAppProfile({
                profile: data
            }))
        }
    }
}

Create = withRouter(Create);

export default connect(mapStateToProps, mapDispatchToProps)(Create);