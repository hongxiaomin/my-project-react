import {SERVER_IP} from '../../../../../constants/Config';

export const deleteAppProfileUrl = `${SERVER_IP}/cloudServer/appProfile`;
export const getAppProfileUrl = `${SERVER_IP}/cloudServer/appProfile`;