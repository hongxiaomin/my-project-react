import {message} from 'antd';
import request from '../../../../../utils/fetchData';
import {deleteAppProfileUrl,getAppProfileUrl} from './config';

export const changeSelectedAppProfile=_this=>(selectedRowKeys)=>{
    let isSelected = selectedRowKeys.length>0?true:false;
    _this.setState({
        selectedRowKeys,
        isSelected
    })
}

export const handleCreateAppProfile=_this=>()=>{
    _this.props.setIsAppProfileEdit(false);
    _this.props.setSelectedApp(null);
    _this.props.showCreate(true);
}

export const handleEdit=_this=>()=>{
    let selectedRowKeys = _this.state.selectedRowKeys;
    let appProfileList = _this.props.appProfileList;
    let editData = appProfileList.filter(item=>{
        return item.key === selectedRowKeys[0];
    })[0];
    _this.setState({
        selectedRowKeys:[],
        isSelected:false
    })
    _this.props.setIsAppProfileEdit(true);
    _this.props.setSelectedApp(editData);
    _this.props.showCreate(true);
}


export const handleDelete=_this=>()=>{
    let selectedRowKeys = _this.state.selectedRowKeys;
    let appProfileList = _this.props.appProfileList;
    let deleteData = appProfileList.filter(item=>{
        return item.key === selectedRowKeys[0];
    })[0];
    _this.deleteAppProfileData(deleteData,()=>{
        _this.props.deleteAppProfile(deleteData);
        _this.setState({
            selectedRowKeys:[],
            isSelected:false
        })
    })
}

export const deleteAppProfileData = _this=>async(deleteData,cb)=>{
    let response = await request(deleteAppProfileUrl,{
        param:{id:deleteData.id},
        method:'DELETE',
        headers:new Headers()
    });
    if(response.message.code===0){
        message.success(`Delete ${deleteData.appProfileId} Success!`);
        cb();
    }else{
        message.error(response.message.message);
    }
}

export const handleTryRun=_this=>(record)=>()=>{
    _this.props.setSelectedApp(record);
}

export const getProjectAppProfile=_this=>async(project,cb)=>{
    let response =await request(getAppProfileUrl,{
        data:{projectId:project.id}
    });
    if(response.message.code===0){
        let data=response.message.rows;
        let newData = data.map(item=>{
            let key =item.id;
            return {...item,key};
        })
        cb(newData);
    }else{
        message.error(`Get Project ${project.name} app profile error!`)
    }
}