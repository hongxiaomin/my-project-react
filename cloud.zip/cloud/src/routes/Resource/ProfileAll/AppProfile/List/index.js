import React, { Component } from 'react';
import { connect } from 'react-redux';
import {Link} from 'react-router-dom';
import {toJS} from 'immutable';
import { Button, Input, Table } from 'antd';
import {
    setSelectedApp,
    setIsAppProfileEdit,
    deleteAppProfile,
    setAppProfileList,
} from '../../../../../actions';
import {
    changeSelectedAppProfile,
    handleCreateAppProfile,
    handleEdit,
    handleDelete,
    deleteAppProfileData,
    handleTryRun,
    getProjectAppProfile,
} from './fn'

const Search = Input.Search;

class AppList extends Component {
    constructor(props) {
        super(props);
        this.changeSelectedAppProfile = changeSelectedAppProfile(this);
        this.handleCreateAppProfile=handleCreateAppProfile(this);
        this.handleEdit=handleEdit(this);
        this.handleDelete=handleDelete(this);
        this.deleteAppProfileData=deleteAppProfileData(this);
        this.handleTryRun=handleTryRun(this);
        this.getProjectAppProfile=getProjectAppProfile(this);

        this.state = {
            isSelected:false,
            selectedRowKeys: [],
        }
    }

    componentDidMount(){
        let selectedProject=this.props.selectedProject;
        if(selectedProject){
            this.getProjectAppProfile(selectedProject,(data)=>{
                this.props.setAppProfileList(data);
            })
        }
        
    }

    columns=[
        {
            title: 'ID',
            dataIndex: 'appProfileId',
            key: "appProfileId"
        },
        {
            title: 'Environment Profile ID',
            dataIndex: 'envProfileIdKey',
            key: "envProfileIdKey"
        },
        {
            title: 'App ID',
            dataIndex: 'appId',
            key: "appId"
        },
        {
            title: 'Create Time',
            dataIndex: 'createTime',
            key: "createTime"
        },
        {
            title: 'Update Time',
            dataIndex: 'updateTime',
            key: "updateTime"
        },
        {
            title: '',
            dataIndex: '',
            render:(text,record)=>{
                return (
                    <Link to="/resource/profile/test" onClick={this.handleTryRun(record)}>
                        Try Run
                    </Link>
                )
            }
        }
    ]

    render() {
        let isSelected = this.state.isSelected;
        const rowSelection = {
            selectedRowKeys: this.state.selectedRowKeys,
            onChange: this.changeSelectedAppProfile,
            type: 'radio'
        };
        return (
            <div className="epg_list_box">
                <div className="epg_list_header">
                    <span className="btn_group">
                        <Button type="primary" onClick={this.handleCreateAppProfile}>Create</Button>
                        <Button type="primary" disabled={!isSelected} onClick={this.handleEdit}>Edit</Button>
                        <Button type="primary" disabled={!isSelected} onClick={this.handleDelete}>Delete</Button>
                    </span>

                    <Search
                        placeholder="input search text"
                        onSearch={value => console.log(value)}
                        enterButton
                        style={{ width: 260, display: 'inline-block' }}
                    />
                </div>
                <Table
                    rowSelection={rowSelection}
                    columns={this.columns}
                    dataSource={this.props.appProfileList}
                />
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    state = state.toJS();
    return {
        appProfileList:state.profile.appProfileList,
        selectedProject: state.project.selectedProject,
    }
};

const mapDispatchToProps = (dispatch) => ({
    setSelectedApp:(data)=>{
        dispatch(setSelectedApp({
            profile:data
        }))
    },
    setIsAppProfileEdit:(data)=>{
        dispatch(setIsAppProfileEdit({
            isEdit:data
        }))
    },
    deleteAppProfile:(data)=>{
        dispatch(deleteAppProfile({
            profile:data
        }))
    },
    setAppProfileList:(data)=>{
        dispatch(setAppProfileList({
            appProfileList:data
        }))
    },
})

export default connect(mapStateToProps,mapDispatchToProps)(AppList)