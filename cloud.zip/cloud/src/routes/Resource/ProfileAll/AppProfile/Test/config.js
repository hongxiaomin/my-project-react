import { SERVER_IP } from '../../../../../constants/Config';

export const postDeploymentUrl = `${SERVER_IP}/cloudServer/integrated/deployment`;
export const getProgressUrl = `${SERVER_IP}/cloudServer/integrated/deployment/progress`;
export const getEnvironmentUrl = `${SERVER_IP}/cloudServer/environment`;
export const postExecutionUrl = `${SERVER_IP}/cloudServer/test/execution`;
export const getResultUrl = `${SERVER_IP}/cloudServer/test/execution`;
export const deleteEnvironmentUrl = `${SERVER_IP}/cloudServer/environment`;

export const columns = [{
    title: 'Name',
    dataIndex: 'name',
    key: 'name',
}, {
    title: 'IP',
    dataIndex: 'ip',
    key: 'ip',
}, {
    title: 'Hostname',
    dataIndex: 'hostName',
    key: 'hostName',
}, {
    title: 'Image',
    dataIndex: 'image',
    key: 'image',
}, {
    title: 'Status',
    dataIndex: 'status',
    key: 'status',
}];

export const environmentData = {
    "code": 0,
    "environmentId": "1",
    "createTime": "2018-06-01 15:30:00",
    "status": "environment creating",
    "message": "...",
    "network": {
        "networkId": "net01",
        "networkName": "net1",
        "status": "create",
        "message": "..."
    },
    "nodes": [{
        "id": "01",
        "name": "node1",
        "ip": "",
        "hostName": "node1a57b",
        "image": "subagent",
        "status": "START",
        "message": "..."
    },
    {
        "id": "02",
        "name": "rabbitmq",
        "ip": "",
        "hostName": "rabbitmq",
        "image": "rabbitmq",
        "status": "START",
        "message": "..."
    }]
};
