import {message} from 'antd';
import {postDeploymentUrl,getProgressUrl,getEnvironmentUrl,postExecutionUrl,getResultUrl,deleteEnvironmentUrl,} from './config';
import request from '../../../../../utils/fetchData';
export const handleInstall = _this=>()=>{
    let appProfileId = _this.props.selectedAppProfile.id;
    let postData = {appProfileId};
    _this.setState({
        isCreateEnv:true
    });
    _this.createEnvironmemt(postData);
}

export const createEnvironmemt = _this =>async(postData)=>{
    let response = await request(postDeploymentUrl,{
        data: JSON.stringify(postData),
        method: 'POST',
        contentType: 'raw',
        headers: new Headers()
    });

    if(response.message.code===0){
        let environmentId = response.message.environmentId;
        _this.setState({
            isProgress:true,
        })
        _this.getDeploymentProgress(environmentId);
    }else{
        message.error(response.message.message);
        _this.setState({
            isCreateEnv:false
        })
    }
}

export const getDeploymentProgress = _this=>async(environmentId)=>{
    let response = await request(getProgressUrl,{
        data:{environmentId:environmentId}
    });
    if(response.message.code===0){
        let data = response.message.rows;
        let progress = data.progress;
        let progressMessage = data.message;
        if(progress===100){
            _this.setState({
                percent:progress,
                progressMessage:progressMessage,
            })
            _this.getEnvironment({id:environmentId})
            return;
        }else if(progress===-1){
            _this.setState({
                percent:progress,
                progressMessage:progressMessage,
                progressStatus:'exception',
                isCreateEnv:false,
            })
            return;
        }else{
            _this.setState({
                percent:progress,
                progressMessage:progressMessage,
            })
            setTimeout(()=>{
                _this.getDeploymentProgress(environmentId);
            },2000)
            
        }
    }
}

export const getEnvironment = _this=>async(param)=>{
    let response = await request(getEnvironmentUrl,{
        data:param
    });
    if(response.message.code===0){
        let environmentId = response.message.environmentId;
        if(environmentId){
            _this.setState({
                isCreateSuccess:true,
                isCreateEnv:false,
                isProgress:false,
                environmentData:response.message
            })
        }else{
            _this.setState({
                isCreateEnv:false,
                isProgress:false,
                isCreateSuccess:false,
                environmentData:null
            })
        }
    }else{
        // message.error(response.message.message)
        _this.setState({
            isCreateEnv:false,
            isProgress:false,
            isCreateSuccess:false,
            environmentData:null
        })
    }
}

export const handleDeleteEnv = _this =>()=>{
    let environmentId = _this.state.environmentData?_this.state.environmentData.environmentId:'';
    _this.setState({
        isDelete:true
    });
    _this.deleteEnvData(environmentId);
}

export const deleteEnvData = _this=>async(environmentId)=>{
    let response = await request(deleteEnvironmentUrl,{
        param:{
            id:environmentId,
        },
        method:"DELETE",
        headers: new Headers()
    });
    if(response.message.code===0){
        message.success('Delete this environment success!');
        _this.setState({
            isCreateSuccess:false,
            environmentData:null,
            isDelete:false
        })
    }
}

export const handleTryRun = _this=>()=>{
    let appId = _this.props.selectedAppProfile.appId;
    let appList = [..._this.props.appList];
    let currentApp = appList.filter(item=>{
        return item.id === appId;
    })[0];
    let epgs = currentApp.epgs;
    let epgList = epgs.map(item=>{
        let key = item.id;
        return {...item,key}
    })
    _this.setState({
        testVisible:!_this.state.testVisible,
        epgList:epgList
    })
}

export const handleChangeEpg = _this=>(value)=>{
    _this.setState({
        epgId:value
    })
}

export const changeParam=_this=>(item)=>(key,value)=>{
    let paramList =[..._this.state.paramList];
    let currentParam = paramList.filter(param=>{
        return param.key===item.key;
    })[0];
    currentParam[key]=value.trim();
    _this.setState({
        paramList
    })
}

export const deleteParam=_this=>(param)=>()=>{
    let paramList=[..._this.state.paramList];
    if(paramList.length===1){
        paramList=[{type:'', value:'',key:`param${Date.now()}${Math.ceil(Math.random()*10)}`}];
    }else{
        paramList=paramList.filter(item =>{
            return item.key!==param.key;
        })
    }
    _this.setState({
        paramList
    })
}

export const addParam=_this=>()=>{
    let paramList=[..._this.state.paramList];
    paramList.push({
        type:'',
        value:'',
        key:`param${Date.now()}${Math.ceil(Math.random()*10)}`
    })
    _this.setState({
        paramList
    })
}

export const handleTest=_this=>()=>{
    _this.setState({
        isTest:true
    })
    let epgId = _this.state.epgId;
    let environmentId = _this.state.environmentData.environmentId;
    let appId = _this.props.selectedAppProfile.appId;
    let paramList = _this.state.paramList;
    let params = [];
    for(let i=0;i<paramList.length;i++){
        if(paramList[i].type){
            params.push({
                type:paramList[i].type,
                value:paramList[i].value
            });
        }
    }
    let postData = {
        appId,
        environmentId,
        epgId,
        params
    };
    _this.postExecution(postData);
}

export const postExecution = _this=>async(postData)=>{
    let response = await request(postExecutionUrl,{
        data: JSON.stringify(postData),
        method: 'POST',
        contentType: 'raw',
        headers: new Headers()
    });
    if(response.message.code == 0){
        let testId = response.message.testId;
        _this.getResult(testId);
    }else{
        _this.setState({
            isTest:false,
        })
    }
}

export const getResult = _this => async(testId)=>{
    let response = await request(getResultUrl,{
        data:{testId:testId}
    });
    if(response.message.code === 0){
        let resultMessage = response.message.message;
        _this.setState({
            isTest:false,
            result:resultMessage
        })
    }else{
        _this.setState({
            isTest:false,
            result:response.message.message
        })
    }
}

