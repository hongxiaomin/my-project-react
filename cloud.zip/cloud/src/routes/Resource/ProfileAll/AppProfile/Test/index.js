import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { toJS } from 'immutable';
import { Card, Row, Col, Button, Progress, Icon, Input, Table, Select } from 'antd';
import Param from '../../../../../components/Param';
import {
    setSelectedApp
} from '../../../../../actions';
import {
    handleInstall,
    createEnvironmemt,
    getDeploymentProgress,
    getEnvironment,
    handleDeleteEnv,
    handleTryRun,
    handleChangeEpg,
    changeParam,
    deleteParam,
    addParam,
    handleTest,
    getResult,
    postExecution,
    deleteEnvData,
} from './fn';
import { columns, environmentData } from './config';
import './style.less';

const Option = Select.Option;
const { TextArea } = Input;

class Test extends Component {
    constructor(props) {
        super(props);
        this.handleInstall = handleInstall(this);
        this.createEnvironmemt = createEnvironmemt(this);
        this.getDeploymentProgress = getDeploymentProgress(this);
        this.getEnvironment = getEnvironment(this);
        this.handleDeleteEnv = handleDeleteEnv(this);
        this.handleTryRun = handleTryRun(this);
        this.handleChangeEpg = handleChangeEpg(this);
        this.changeParam = changeParam(this);
        this.deleteParam = deleteParam(this);
        this.addParam = addParam(this);
        this.handleTest = handleTest(this);
        this.getResult=getResult(this);
        this.postExecution=postExecution(this);
        this.deleteEnvData=deleteEnvData(this);

        this.state = {
            isProgress: false,
            isCreateEnv: false,
            isCreateSuccess: false,
            progressStatus: 'active',
            percent: 0,
            progressMessage: '',
            environmentData: null,
            // environmentData: environmentData,
            testVisible: false,
            epgList: [],
            epgId: '',
            paramList: [{
                type: '',
                value: '',
                key: `param${Date.now()}${Math.ceil(Math.random()*10)}`
            }],
            result: '',
            isTest:false,
            isDelete:false,
        }
    }
    componentWillMount() {
        let selectedAppProfile = this.props.selectedAppProfile;
        if (!selectedAppProfile) {
            this.props.history.push('/resource/profile/appProfile');
        }
    }

    componentDidMount() {
        let selectedAppProfile = this.props.selectedAppProfile;
        if (selectedAppProfile) {
            let appProfileId = selectedAppProfile.appProfileId;
            this.getEnvironment({appProfileId:appProfileId})
        }
    }

    componentWillUnmount() {
        this.createEnvironmemt = null;
        this.createEnvironmemt = null;
        this.getEnvironment = null;
        this.getDeploymentProgress=null;
        this.deleteEnvData=null;
        this.postExecution=null;
    }
    render() {
        console.log('epgList',this.state.epgList);
        console.log('paramList',this.state.paramList);
        const { selectedAppProfile } = this.props;
        const { environmentData } = this.state;
        let nodes = [];
        if (environmentData) {
            if (environmentData.nodes) {
                nodes = environmentData.nodes.map(item => {
                    let key = item.id;
                    let data = { ...item, key };
                    return data;
                })
            }
        }

        return (
            <div className="try_run_box">
                <Card title="App Profile" type="inner">
                    <Row type="flex" className="app_profile_item">
                        <Col span={12}>
                            <label>App Profile ID:</label>
                            <span>{selectedAppProfile ? selectedAppProfile.appProfileId : null}</span>
                        </Col>
                        <Col span={12}>
                            <label>App ID:</label>
                            <span>{selectedAppProfile ? selectedAppProfile.appId : null}</span>
                        </Col>
                    </Row>
                    <Row type="flex" className="app_profile_item">
                        <Col span={12}>
                            <label>Environment Profile ID:</label>
                            <span>{selectedAppProfile ? selectedAppProfile.envProfileIdKey : null}</span>
                        </Col>
                        <Col span={12}>
                            <label>Create Time:</label>
                            <span>{selectedAppProfile ? selectedAppProfile.createTime : null}</span>
                        </Col>
                    </Row>
                </Card>
                {
                    this.state.isCreateSuccess ?
                        <div className="env_box">
                            <Card title="Environment Information" type="inner">
                                <Row type="flex" className="app_profile_item">
                                    <Col span={8}>
                                        <label>Status:</label>
                                        <span>{environmentData.status}</span>
                                    </Col>
                                    <Col span={8}>
                                        <label>Create Time:</label>
                                        <span>{environmentData.createTime}</span>
                                    </Col>
                                    <Col span={8} style={{ textAlign: 'right' }}>
                                        <Button type="danger" onClick={this.handleDeleteEnv} disabled={this.state.isDelete}>Delete this Environment</Button>
                                    </Col>
                                </Row>
                                <Table
                                    columns={columns}
                                    dataSource={nodes}
                                />
                            </Card>
                            <Button type="primary" onClick={this.handleTryRun} style={{ marginTop: '20px', width: '100px' }}>Try Run</Button>
                            {
                                this.state.testVisible ?
                                    <div className="test_box">
                                        <div className="input_section">
                                            <label>EPG ID:</label>
                                            <Select
                                                style={{ width: 600 }}
                                                placeholder="Select a epg"
                                                optionFilterProp="children"
                                                onChange={this.handleChangeEpg}
                                                filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
                                            >
                                                {
                                                    this.state.epgList.map(item => {
                                                        return <Option value={item.id}>{item.name}</Option>
                                                    })
                                                }
                                            </Select>
                                            <Button type="primary" style={{ width: '100px',marginLeft:'48px' }} onClick={this.handleTest} disabled={this.state.isTest}>Test</Button>
                                        </div>
                                        <Card title="Param" type="inner" >
                                            <div className="param_section">
                                                <div className="param_left">
                                                    {
                                                        this.state.paramList.map(item => {
                                                            return <Param key={item.key} changeParam={this.changeParam(item)} deleteParam={this.deleteParam(item)} />
                                                        })
                                                    }
                                                </div>
                                                <div className="param_right">
                                                    <Button type="primary" onClick={this.addParam} style={{ width: '100px' }}>
                                                        <a alt="add a param" style={{width:'100%',display:'inline-block'}}>+</a>
                                                    </Button>
                                                </div>
                                            </div>
                                        </Card>
                                       
                                        <div className="result_box">
                                            <label>Result:</label>
                                            <TextArea value={this.state.result} style={{ width: '610px', height: '260px' }} />
                                        </div>
                                    </div> :
                                    null
                            }
                        </div> :
                        <div className="try_run_btn">
                            <Button type="primary" onClick={this.handleInstall} disabled={this.state.isCreateEnv}>Try Install On TestServer</Button>
                            {
                                this.state.isProgress ?
                                    <div className="try_run_progress">
                                        <Progress strokeWidth={26} status={this.state.progressStatus} percent={this.state.percent} />
                                        <TextArea value={this.state.progressMessage} style={{ width: '95%', height: '260px', overflow: 'auto', marginTop: '30px' }} />
                                    </div> : null
                            }
                        </div>
                }

            </div>
        )
    }
}

const mapStateToProps = (state) => {
    state = state.toJS();
    return {
        selectedAppProfile: state.profile.selectedAppProfile,
        appList:state.projectApp.appList
    }
};

const mapDispatchToProps = (dispatch) => {
    return {
        setSelectedApp: (data) => {
            dispatch(setSelectedApp({
                profile: data
            }))
        },
    }
};

Test = withRouter(Test);

export default connect(mapStateToProps, mapDispatchToProps)(Test);