export const breadMap = [
    {
        path:'',
        name:'Index'
    },
    {
        path:'',
        name:'Resource'
    },
    {
      path:'',
      name:'Profile'
    },
    {
        path:'',
        name:'App Profile'
      }
  ];