import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import Page from '../../../../components/Page';
import Bread from '../../../../components/Bread';
import List from './List';
import Create from './Create';
import { breadMap } from './config';

class AppProfile extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isCreate: false,
    }
  }

  showCreate = (value) => {
    this.setState({
      isCreate: value
    })
  }

  componentDidMount() {
    if (this.props.location.search) {
      this.setState({
        isCreate:true
      })
    }
  }

  render() {
    return (
      <Page>
        <Bread breadMap={breadMap} />
        {
          this.state.isCreate ?
            <Create
              showCreate={this.showCreate}
            /> :
            <List
              showCreate={this.showCreate}
            />
        }
      </Page>
    )
  }
}

AppProfile = withRouter(AppProfile);
export default AppProfile;