import {SERVER_IP} from '../../../../../constants/Config';


export const containerType='CONTAINER';
export const runtimeType = 'RUNTIME';
export const localLicenseType='LOCAL_LICENSE_SERVER';
export const nodeType = 'NODE';
export const staticComponents = [
    {
        type:runtimeType,
        name:'RUNTIME'
    },{
        type:localLicenseType,
        name:'LOCAL_LICENSE_SERVER'
    }
];

export const getComponentConfigUrl = `${SERVER_IP}/cloudServer/component/configuration`;

export const addEnvProfileUrl = `${SERVER_IP}/cloudServer/envProfile`;