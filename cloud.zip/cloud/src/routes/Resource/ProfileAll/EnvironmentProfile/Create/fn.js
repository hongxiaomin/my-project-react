import { message } from 'antd';
import {
    nodeType, runtimeType, localLicenseType, containerType, getComponentConfigUrl,
    addEnvProfileUrl,
} from './config';
import request from '../../../../../utils/fetchData';

export const next = _this => () => {
    let current = _this.state.current;
    if (current === 0) {
        let envProfileId = _this.state.envProfileId;
        if (!envProfileId) {
            message.error('Input available Environment Profile ID!');
            return;
        } else {
            let envProfileList = _this.props.envProfileList;
            let hasSameId = envProfileList.filter(item => {
                return item.envProfileId === envProfileId
            });
            if(hasSameId.length>0){
                if(!_this.props.isEnvironmentEdit){
                    message.error(`${envProfileId} is existed!`);
                    return;
                }
            }
            let selectedEnvProfile;
            if(!_this.props.isEnvironmentEdit){
                selectedEnvProfile={
                    projectId: _this.props.selectedProject.id,
                    envProfileId,
                }
            }else{
                selectedEnvProfile = _this.props.selectedEnvProfile;
                selectedEnvProfile={...selectedEnvProfile,envProfileId};

            }
            _this.props.setSelectedEnv(selectedEnvProfile);
            current = current + 1;
            _this.setState({
                current
            })
        }
    } else if (current === 1) {
        let nodes = _this.state.nodes;
        if (nodes.length === 0) {
            message.error('Please Add Node!');
            return;
        }

        let components = [..._this.state.components];
        let notHasNec = true;
        let componentList = [..._this.state.componentList];
        componentList.forEach(item => {
            let type = item.value.split('&')[0];
            if (type === runtimeType || type === localLicenseType) {
                notHasNec = false;
            }
        })
        if (!notHasNec || components.length < 3) {
            message.error('Node Components Mapping is error!');
            return;
        }
        if (components.length >= 3 && notHasNec) {
            current = current + 1;
            let selectedEnvProfile = _this.props.selectedEnvProfile;
            let components = JSON.parse(JSON.stringify(_this.state.components));
            let mappingObj = {
                nodes: nodes,
                components: components,
                nodeComponentMappings: _this.state.mapping
            };
            for (let i = 0; i < components.length; i++) {
                if(components[i].configs&&components[i].configs.length>0){
                }else{
                    _this.getComponentConfig(components[i].type, (data) => {
                        components[i].configs = data;
                        mappingObj = { ...mappingObj, components };
                        selectedEnvProfile = { ...selectedEnvProfile, ...mappingObj };
                        _this.props.setSelectedEnv(selectedEnvProfile);
                        _this.setState({
                            components
                        })
                    })
                }
            }
            _this.setState({
                current,
            })
        }
    }
}

export const getComponentConfig = _this => async (type, cb) => {
    let response = await request(getComponentConfigUrl, {
        data: { type: type }
    });
    if (response.message.code === 0) {
        let data = response.message.rows.map(item => {
            return { ...item };
        });
        cb(data);
    } else {
        message.error(response.message.message);
    }
}


export const changeEnvProfileId = _this => (e) => {
    let value = e.target.value.trim();
    _this.setState({
        envProfileId: value
    })
}

export const showAddNode = _this => () => {
    _this.setState({
        addNodeVisible: true
    })
}

export const changeNode = _this => (value) => {
    let nodeItem = _this.state.nodeItem;
    if (value["id"]) {
        let id = value["id"].trim();
        if(id){
            nodeItem["id"] = id;
        }
    } else if (value["hostname"]) {
        let hostname = value["hostname"].trim();
        if(hostname){
            nodeItem["hostname"] = hostname;
        }
    }
    _this.setState({
        nodeItem
    })
}

export const addNodeSure = _this => () => {
    let nodeItem = _this.state.nodeItem;
    let { id, hostname } = nodeItem;
    if (!id || !hostname) {
        message.error('Input available value!');
        return;
    }

    let nodes = _this.state.nodes;

    let nodeIsExisted = false;
    nodes.forEach(item => {
        if (item.id === id) {
            message.error(`${item.id} is existed!`);
            nodeIsExisted = true;
        }
        if (item.hostname === hostname) {
            message.error(`${item.hostname} is existed!`);
            nodeIsExisted = true;
        }
    });

    if (nodeIsExisted) {
        return;
    }

    nodes = nodes.concat([nodeItem]);

    let treeData = [..._this.state.treeData];
    treeData = treeData.concat([{
        id: `${nodeType}&${id}`,
        label: id,
        children: []
    }])

    _this.setState({
        nodes,
        nodeItem: {},
        addNodeVisible: false,
        treeData
    })
}

export const addNodeCancel = _this => () => {
    _this.setState({
        nodeItem: {},
        addNodeVisible: false,
    })
}

export const checkAllComponents = _this => (e) => {
    let checkedComponents = [];
    if (e.target.checked) {
        checkedComponents = _this.state.componentList.map(item => {
            return item.value;
        })
    } else {
        checkedComponents = [];
    }
    _this.setState({
        checkedComponents,
        componentCheckAll: e.target.checked
    })
}

export const checkComponents = _this => (checkedList) => {
    _this.setState({
        checkedComponents: checkedList,
        componentCheckAll: checkedList.length === _this.state.componentList.length
    })
}

export const showAddContainer = _this => () => {
    _this.setState({
        addContainerVisible: true
    })
}

export const changeContainer = _this => value => {
    let name = value["name"].trim();
    _this.setState({
        containerName: name
    })
}

export const addContainerSure = _this => () => {
    let componentList = [..._this.state.componentList];
    let containerName = _this.state.containerName;
    let currentContainerId = `${containerType}&${containerName}`;
    let sameContainer = componentList.filter(item => {
        return item.key === currentContainerId;
    })
    if(!containerName){
        message.error('Input available container name!');
        return;
    }
    if (sameContainer.length > 0) {
        message.error(`${containerName} is existed!`);
        return;
    }
    componentList = componentList.concat([{
        key: currentContainerId,
        label: containerName,
        value: currentContainerId
    }]);
    let checkedComponents = [..._this.state.checkedComponents];
    if (_this.state.componentCheckAll) {
        checkedComponents = checkedComponents.concat([currentContainerId]);
    }
    _this.setState({
        componentList,
        addContainerVisible: false,
        checkedComponents
    })
}

export const addContainerCancel = _this => () => {
    _this.setState({
        containerName: '',
        addContainerVisible: false
    })
}

export const addComponentSure = _this => () => {
    let checkedComponents = [..._this.state.checkedComponents];
    if (checkedComponents.length === 0) {
        message.error('No Selected!');
        return;
    }
    let selectedNode = _this.state.selectedNode;
    let mapping = [..._this.state.mapping];
    let currentMap = mapping.filter(item => {
        return item.nodeId === selectedNode.id.split("&")[1];
    });
    if (currentMap.length > 0) {
        currentMap = currentMap[0];
    } else {
        currentMap = {
            "nodeId": selectedNode.id.split("&")[1],
            "componentIds": []
        };
        mapping.push(currentMap);
    }

    let components = [..._this.state.components];
    let children = checkedComponents.map(item => {
        let id = item;
        let name = item.split('&')[1];
        let type = item.split('&')[0];
        components.push({
            "id": name,
            "type": type,
            "configs": []
        });
        currentMap["componentIds"].push(name);
        return {
            label: name,
            id
        }
    });
    let treeData = [..._this.state.treeData].map(item => {
        if (item.id === selectedNode.id) {
            item.children = item.children.concat(children);
        }
        return item;
    });

    let componentList = [..._this.state.componentList];
    for (let i = 0; i < checkedComponents.length; i++) {
        componentList = componentList.filter(item => {
            return item.value !== checkedComponents[i];
        })
    };

    _this.setState({
        checkedComponents: [],
        selectedNode: null,
        componentCheckAll: false,
        mapping,
        components,
        treeData,
        componentList,
        componentVisible: false
    })
}

export const addComponentCancel = _this => () => {
    _this.setState({
        checkedComponents: [],
        selectedNode: null,
        componentCheckAll: false,
        componentVisible: false
    })
}

export const addTreeData = _this => (store, data) => () => {
    const type = data.id.split('&')[0];
    if (type === nodeType) {
        _this.setState({
            componentVisible: true,
            selectedNode: data
        })
    }
}

export const deleteTreeData = _this => (store, data) => () => {
    let type = data.id.split('&')[0];
    let name = data.id.split('&')[1];
    let nodes = [..._this.state.nodes];
    let componentList = [..._this.state.componentList];
    let components = [..._this.state.components];
    let mapping = [..._this.state.mapping];
    let treeData = [..._this.state.treeData];

    if (type === nodeType) {
        nodes = nodes.filter(item => {
            return item.id !== name;
        })
        if(data.children.length>0){
            let nodeComponentList = data.children.map(item=>{
                components = components.filter(com => {
                    return com.id !== item.label;
                });
                return {
                    key:item.id,
                    label:item.label,
                    value:item.id
                }
            });
            componentList=componentList.concat(nodeComponentList);
        }
        treeData = treeData.filter(item => {
            return item.id !== data.id;
        })
        mapping = mapping.filter(item => {
            return item.nodeId !== name;
        })
    } else {
        componentList = componentList.concat([{
            key: data.id,
            label: name,
            value: data.id
        }]);
        components = components.filter(item => {
            return item.id !== name;
        });
        treeData = treeData.map(item => {
            let { children } = item;
            children = children.filter(com => {
                return com.id !== data.id;
            })
            item["children"] = children;
            return item;
        });
        mapping = mapping.map(item => {
            let componentIds = [...item.componentIds];
            item.componentIds = componentIds.filter(com => {
                return com !== name;
            })
            return item;
        })
    }
    _this.setState({
        nodes,
        componentList,
        components,
        mapping,
        treeData
    })

}

export const showPropertiesModal = _this => (propertyModalData, propertyParamData) => () => {
    _this.setState({
        propertyVisible: true,
        propertyModalData,
        propertyModalParam: propertyParamData
    })
}


export const changeProperty = _this => (key) => (e) => {
    let value = e.target.value;
    let propertyModalParam = JSON.parse(JSON.stringify(_this.state.propertyModalParam));
    let currentProperty = propertyModalParam.properties.filter(item => {
        return item.key === key;
    })[0];
    currentProperty["value"] = value;
    _this.setState({
        propertyModalParam
    })

}

export const handlePropertySure = _this => () => {
    let components = [..._this.state.components];
    let propertyModalData = { ..._this.state.propertyModalData };
    let propertyModalParam = { ..._this.state.propertyModalParam };
    components = components.map(item => {
        if (item.id === propertyModalData.id) {
            item.configs.map(con => {
                if (con.category === propertyModalParam.category) {
                    con.properties = propertyModalParam.properties;
                }
                return con;
            })
        }
        return item;
    });
    _this.setState({
        components,
        propertyModalData: null,
        propertyModalParam: null,
        propertyVisible: false
    })
}

export const handlePropertyCancel = _this => () => {
    _this.setState({
        propertyModalData: null,
        propertyModalParam: null,
        propertyVisible: false
    })
}

export const submitProfile = _this => () => {
    let components = [..._this.state.components];
    let selectedEnvProfile = { ..._this.props.selectedEnvProfile };
    selectedEnvProfile = { ...selectedEnvProfile, components };
    if(_this.props.isEnvironmentEdit){
        let {components,envProfileId,id,nodeComponentMappings,nodes} = selectedEnvProfile
        let putData={id,envProfileId,nodes,components,nodeComponentMappings};
        _this.putProfile(putData,data=>{
            _this.props.updateEnvProfile(data);
            _this.props.setSelectedEnv(null);
            _this.props.showCreate(false);
        })
       

    }else{
        _this.postProfile(selectedEnvProfile, (data) => {
            _this.props.addEnvProfile(data);
            _this.props.setSelectedEnv(null);
            _this.props.showCreate(false);
        })
    }
   

}

export const postProfile = _this => async (postData, cb) => {
    let response = await request(addEnvProfileUrl, {
        data: JSON.stringify(postData),
        method: 'POST',
        contentType: 'raw',
        headers: new Headers()
    });
    if (response.message.code === 0) {
        let data = response.message.rows;
        let key = data.id;
        data = { ...data, key };
        cb(data);
    } else {
        message.error(response.message.message);
    }
}

export const putProfile = _this=>async(putData,cb)=>{
    let response = await request(addEnvProfileUrl,{
        data: JSON.stringify(putData),
        method: 'PUT',
        contentType: 'raw',
        headers: new Headers()
    })
    if (response.message.code === 0) {
        let data = response.message.rows;
        let key = data.id;
        data = { ...data, key };
        cb(data);
    } else {
        message.error(response.message.message);
    }
}

export const cancelProfile = _this => () => {
    _this.props.setSelectedEnv(null);
    _this.props.showCreate(false);
}
