import React, { Component } from 'react';
import { connect } from 'react-redux';
import { toJS } from 'immutable';
import {Prompt} from 'react-router-dom';
import { Steps, Button, message, Row, Col, Input, Icon, Checkbox, Collapse, List } from 'antd';
import { Tree } from 'element-react';
import 'element-theme-default';
import TextField from '../../../../../components/TextField';
import CloudModal from '../../../../../components/CloudModal';
import {
    setSelectedEnv,
    addEnvProfile,
    updateEnvProfile
} from '../../../../../actions';
import {
    showAddNode,
    changeNode,
    next,
    changeEnvProfileId,
    addNodeSure,
    addNodeCancel,
    addTreeData,
    deleteTreeData,
    checkAllComponents,
    checkComponents,
    showAddContainer,
    changeContainer,
    addContainerSure,
    addContainerCancel,
    addComponentSure,
    addComponentCancel,
    getComponentConfig,
    showPropertiesModal,
    changeProperty,
    handlePropertySure,
    handlePropertyCancel,
    submitProfile,
    cancelProfile,
    postProfile,
    putProfile,
} from './fn';

import { staticComponents, containerType ,localLicenseType, runtimeType,nodeType} from './config';

import './style.less';


const Step = Steps.Step;
const TreeNode = Tree.TreeNode;
const CheckboxGroup = Checkbox.Group;
const Panel = Collapse.Panel;

class Create extends Component {
    constructor(props) {
        super(props);
        this.showAddNode = showAddNode(this);
        this.changeNode = changeNode(this);
        this.next = next(this);
        this.changeEnvProfileId = changeEnvProfileId(this);
        this.addNodeSure = addNodeSure(this);
        this.addNodeCancel = addNodeCancel(this);
        this.addTreeData = addTreeData(this);
        this.deleteTreeData = deleteTreeData(this);
        this.checkAllComponents = checkAllComponents(this);
        this.checkComponents = checkComponents(this);
        this.showAddContainer = showAddContainer(this);
        this.changeContainer = changeContainer(this);
        this.addContainerSure = addContainerSure(this);
        this.addContainerCancel = addContainerCancel(this);
        this.addComponentSure = addComponentSure(this);
        this.addComponentCancel = addComponentCancel(this);
        this.getComponentConfig=getComponentConfig(this);
        this.showPropertiesModal=showPropertiesModal(this);
        this.changeProperty=changeProperty(this);
        this.handlePropertySure=handlePropertySure(this);
        this.handlePropertyCancel=handlePropertyCancel(this);
        this.submitProfile=submitProfile(this);
        this.cancelProfile=cancelProfile(this);
        this.postProfile=postProfile(this);
        this.putProfile=putProfile(this);


        this.state = {
            current: 0,//当前步数
            envProfileId: '',//environement Profile ID
            addNodeVisible: false,//增加节点弹框
            nodeItem: {},//新增节点项
            nodes: [],//需要提交的节点
            treeData: [],//树形结构数据
            treeOption: {//树形结构配置
                children: 'children',
                label: 'label'
            },
            selectedNode: null,//当前操作的树形结构项
            components: [],//需要提交的components
            componentVisible: false,//component选框显示
            componentCheckAll: false,//component全选状态
            checkedComponents: [],//当前被选中的components
            componentList: [],//可显示的component数据
            addContainerVisible: false,//显示新增container弹框
            containerName: '',//新增container的IDName
            mapping: [],//需要提交mapping关系
            propertyVisible:false,//config 弹框显示状态
            propertyModalData:null,//config 弹框父级信息
            propertyModalParam:null,//config 弹框参数信息
        };
    }

    componentDidMount() {
        let isEnvironmentEdit = this.props.isEnvironmentEdit;
        if (!isEnvironmentEdit) {
            let componentList = staticComponents.map(item => {
                const id = `${item.type}&${item.name}`;
                return { key: id, label: item.name, value: id }
            });
            this.setState({
                componentList
            })
        }else{
            let envProfile = this.props.selectedEnvProfile;
            let treeData = envProfile.nodeComponentMappings.map(item=>{
                let children = item.componentIds.map(com=>{
                    let childItem;
                    for(let i =0;i<envProfile.components.length;i++){
                        let currentComponent=envProfile.components[i];
                        if(currentComponent.id===com){
                            childItem={
                                id: `${currentComponent.type}&${currentComponent.id}`,
                                label: currentComponent.id,
                            }
                        }
                    }
                    return childItem;
                })
                return {
                    id: `${nodeType}&${item.nodeId}`,
                    label: item.nodeId,
                    children: children
                }
            });
            if(envProfile){
                this.setState({
                    envProfileId:envProfile.envProfileId,
                    nodes:envProfile.nodes,
                    treeData:treeData,
                    components:envProfile.components,
                    mapping:envProfile.nodeComponentMappings
                })
            }
        }
    }

    treeRenderContent = (nodeModel, data, store) => {
        let btnGroup = null;
        if (data.children) {
            btnGroup = <span style={{ float: 'right', marginRight: '20px', marginTop: '2px' }}>
                <Button onClick={this.addTreeData(store, data)}>Append</Button>
                <Button onClick={this.deleteTreeData(store, data)}>Delete</Button>
            </span>
        } else {
            btnGroup = <span style={{ float: 'right', marginRight: '20px', marginTop: '2px' }}>
                <Button onClick={this.deleteTreeData(store, data)}>Delete</Button>
            </span>
        }
        return (
            <span>
                <span>
                    <span>{data.label}</span>
                </span>
                {btnGroup}
            </span>
        )
    }

    render() {
        const steps = [{
            title: 'Create',
            content: <div className="create_box">
                <label>Environment Profile ID:</label>
                <Input style={{ width: 360 }} onChange={this.changeEnvProfileId} value={this.state.envProfileId} />
            </div>,
        }, {
            title: 'Mapping',
            content: <div className="mapping_box">
                <Row>
                    <Col span={4}>
                        <Button type="primary" onClick={this.showAddNode}>
                            Node
                            <Icon type="plus" style={{ color: '#ffffff' }} />
                        </Button>
                    </Col>
                    <Col span={8}>
                        {
                            this.state.addNodeVisible ? (
                                <div className="node_properties">
                                    <TextField text="ID" field="id" handlerChange={this.changeNode} />
                                    <TextField text="Hostname" field="hostname" handlerChange={this.changeNode} />
                                    <div className="btn-group">
                                        <Button type="primary" onClick={this.addNodeSure}>OK</Button>
                                        <Button onClick={this.addNodeCancel}>Cancel</Button>
                                    </div>
                                </div>
                            ) : null
                        }
                    </Col>
                </Row>
                <div className="mapping_content_box">
                    <div className="tree_box">
                        {
                            this.state.treeData.length > 0 ?
                                <div>
                                    <Tree
                                        data={this.state.treeData}
                                        options={this.state.treeOption}
                                        nodeKey="id"
                                        defaultExpandAll={true}
                                        expandOnClickNode={false}
                                        renderContent={(...args) => this.treeRenderContent(...args)}
                                    />
                                </div> : null
                        }
                    </div>
                </div>
                <CloudModal
                    title="Component"
                    visible={this.state.componentVisible}
                    onOk={this.addComponentSure}
                    onCancel={this.addComponentCancel}
                    width="500px"
                >
                    <div className="component_box">
                        <div className="check_all">
                            <Checkbox checked={this.state.componentCheckAll} onChange={this.checkAllComponents}>Check All</Checkbox>
                        </div>
                        <CheckboxGroup options={this.state.componentList} value={this.state.checkedComponents} onChange={this.checkComponents} />
                        <div className="addContainer">
                            <Button type="primary" onClick={this.showAddContainer}>
                                Container
                                <Icon type="plus" style={{ color: '#ffffff' }} />
                            </Button>
                        </div>
                    </div>
                    {
                        this.state.addContainerVisible ?
                            <div className="container_box">
                                <TextField text="Name" handlerChange={this.changeContainer} field="name" />
                                <div className="btn-group">
                                    <Button type="primary" onClick={this.addContainerSure}>OK</Button>
                                    <Button onClick={this.addContainerCancel}>Cancel</Button>
                                </div>
                            </div> : null
                    }
                </CloudModal>
            </div>,
        }, {
            title: 'Config',
            content: <div>
                <Collapse defaultActiveKey={[runtimeType]}>
                    {
                        this.state.components.map((item) => {
                            if (item.type === runtimeType) {
                                return (
                                    <Panel header={item.id} key={item.type}>
                                        <List
                                            split
                                            dataSource={item.configs}
                                            renderItem={listItem => (<List.Item onClick={this.showPropertiesModal(item,listItem)}>{listItem.category}</List.Item>)}
                                        />
                                    </Panel>
                                )
                            }
                        })
                    }
                    {
                        this.state.components.map((item) => {
                            if (item.type === localLicenseType) {
                                return (
                                    <Panel header={item.id} key={item.type}>
                                        <List
                                            split
                                            dataSource={item.configs}
                                            renderItem={listItem => (<List.Item onClick={this.showPropertiesModal(item,listItem)}>{listItem.category}</List.Item>)}
                                        />
                                    </Panel>
                                )
                            }
                        })
                    }

                    <Panel header="Container" key="Container">
                        <Collapse defaultActiveKey="1">
                            {
                                this.state.components.map((item, index) => {
                                    if (item.type === containerType) {
                                        return <Panel header={item.id} key={item.id}>
                                            <List
                                                split
                                                dataSource={item.configs}
                                                renderItem={listItem => (<List.Item onClick={this.showPropertiesModal(item,listItem)}>{listItem.category}</List.Item>)}
                                            />
                                        </Panel>
                                    }
                                })
                            }
                        </Collapse>
                    </Panel>
                </Collapse>
                {
                    this.state.propertyVisible? <CloudModal
                    title={this.state.propertyModalData.id}
                    visible = {this.state.propertyVisible}
                    onOk={this.handlePropertySure}
                    onCancel = {this.handlePropertyCancel}
                    width="960px"
                >
                    <div className="property_box">
                        {
                            this.state.propertyModalParam?this.state.propertyModalParam.properties.map((item,index)=>{
                                return <div className="property_item" key={index}>
                                            <label>{item.key}:</label>
                                            <Input defaultValue={item.value} style={{width:'300px'}} onChange={this.changeProperty(item.key)}/>
                                        </div>
                            }):null
                        }
                    </div>

                </CloudModal>:null
                }
               
            </div>,
        }];
        const { current } = this.state;
        return (
            <div>
                <Steps current={current}>
                    {steps.map(item => <Step key={item.title} title={item.title} />)}
                </Steps>
                <div className="steps-content">{steps[this.state.current].content}</div>
                <div className="steps-action">
                    {
                        this.state.current < steps.length - 1
                        &&
                        <div>
                            <Button type="primary" onClick={this.next}>Next</Button>
                            <Button onClick={this.cancelProfile} style={{marginLeft:'30px'}}>Cancel</Button>
                        </div>
                        
                    }
                    {
                        this.state.current === steps.length - 1
                        &&
                        <div>
                            <Button type="primary" onClick={this.submitProfile}>Done</Button>
                            <Button onClick={this.cancelProfile} style={{marginLeft:'30px'}}>Cancel</Button>
                        </div>

                    }
                </div>
                <Prompt message="Are you sure you want to leave?" when={true}/>
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    state = state.toJS();
    return {
        selectedEnvProfile: state.profile.selectedEnvProfile,
        selectedProject: state.project.selectedProject,
        isEnvironmentEdit: state.profile.isEnvironmentEdit,
        envProfileList:state.profile.envProfileList,
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        setSelectedEnv: (data) => {
            dispatch(setSelectedEnv({
                profile: data
            }))
        },
        addEnvProfile:(data)=>{
            dispatch(addEnvProfile({
                profile:data
            }))
        },
        updateEnvProfile:(data)=>{
            dispatch(updateEnvProfile({
                profile:data
            }))
        }
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(Create);