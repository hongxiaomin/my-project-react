import {SERVER_IP} from '../../../../../constants/Config';

export const deleteEnvProfileUrl = `${SERVER_IP}/cloudServer/envProfile`;
export const getEnvProfileUrl = `${SERVER_IP}/cloudServer/envProfile`;