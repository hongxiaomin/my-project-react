import request from '../../../../../utils/fetchData';
import {deleteEnvProfileUrl,getEnvProfileUrl} from './config';
import {message} from 'antd';

export const getProjectEnvProfile=_this=>async(project,cb)=>{
    let response =await request(getEnvProfileUrl,{
        data:{projectId:project.id}
    });
    if(response.message.code===0){
        let data=response.message.rows;
        let newData = data.map(item=>{
            let key =item.id;
            return {...item,key};
        })
        cb(newData);
    }else{
        message.error(`Get Project ${project.name} environment profile error!`)
    }
}

export const changeSelectedAppProfile=_this=>(selectedRowKeys)=>{
    let isSelected=false;
    if(selectedRowKeys.length>0){
        isSelected=true;
    }
    _this.setState({
        selectedRowKeys,
        isSelected
    })
}

export const handleCreateEnvironmentProfile=_this=>()=>{
    _this.props.setIsEnvEdit(false);
    _this.props.setSelectedEnv(null);
    _this.props.showCreate(true);
}

export const handleEdit=_this=>()=>{
    let currentEnv = _this.props.envProfileList.filter(item=>{
        return item.key === _this.state.selectedRowKeys[0];
    })[0];
    _this.props.setIsEnvEdit(true);
    _this.props.setSelectedEnv(currentEnv);
    _this.props.showCreate(true);
}


export const handleDelete=_this=>()=>{
    let envProfileList = [..._this.props.envProfileList];
    let deleteData = envProfileList.filter(item=>{
        return item.key ===_this.state.selectedRowKeys[0]
    })[0];
    _this.deleteProfile(deleteData,()=>{
        _this.props.deleteEnvProfile(deleteData);
        _this.setState({
            selectedRowKeys:[],
            isSelected:false,
        })
    })
}

export const deleteProfile = _this=>async(deleteData,cb)=>{
    let response = await request(deleteEnvProfileUrl,{
        param:{id:deleteData.id},
        method:'DELETE',
        headers:new Headers()
    });
    if(response.message.code === 0){
        message.success(`Delete ${deleteData.envProfileId} success!`);
        cb();
    }else{
        message.error(response.message.message);
    }
}