import React, { Component } from 'react';
import { connect } from 'react-redux';
import {toJS} from 'immutable';
import { Button, Input, Table } from 'antd';
import {
    setSelectedEnv,
    setIsEnvEdit,
    deleteEnvProfile,
    setEnvProfileList
} from '../../../../../actions';
import {
    changeSelectedAppProfile,
    handleCreateEnvironmentProfile,
    handleEdit,
    handleDelete,
    deleteProfile,
    getProjectEnvProfile
} from './fn'

const Search = Input.Search;

class List extends Component {
    constructor(props) {
        super(props);
        this.changeSelectedAppProfile = changeSelectedAppProfile(this);
        this.handleCreateEnvironmentProfile=handleCreateEnvironmentProfile(this);
        this.handleEdit=handleEdit(this);
        this.handleDelete=handleDelete(this);
        this.deleteProfile=deleteProfile(this);
        this.getProjectEnvProfile=getProjectEnvProfile(this);

        this.state = {
            isSelected:false,
            selectedRowKeys: [],
        }
    }

    componentDidMount(){
        let selectedProject = this.props.selectedProject;
        if(selectedProject){
            this.getProjectEnvProfile(selectedProject,(data)=>{
                this.props.setEnvProfileList(data);
            })
        }
    }

    columns=[
        {
            title: 'ID',
            dataIndex: 'envProfileId',
            key: "envProfileId"
        },
        {
            title: 'Version',
            dataIndex: 'version',
            key: "version"
        },
        {
            title: 'Create Time',
            dataIndex: 'createTime',
            key: "createTime"
        },
        {
            title: 'Update Time',
            dataIndex: 'updateTime',
            key: "updateTime"
        }
    ]


    render() {
        let isSelected = this.state.isSelected;
        const rowSelection = {
            selectedRowKeys: this.state.selectedRowKeys,
            onChange: this.changeSelectedAppProfile,
            type: 'radio'
        };
        return (
            <div className="epg_list_box">
                <div className="epg_list_header">
                    <span className="btn_group">
                        <Button type="primary" onClick={this.handleCreateEnvironmentProfile}>Create</Button>
                        <Button type="primary" disabled={!isSelected} onClick={this.handleEdit}>Edit</Button>
                        <Button type="primary" disabled={!isSelected} onClick={this.handleDelete}>Delete</Button>
                    </span>

                    <Search
                        placeholder="input search text"
                        onSearch={value => console.log(value)}
                        enterButton
                        style={{ width: 260, display: 'inline-block' }}
                    />
                </div>
                <Table
                    rowSelection={rowSelection}
                    columns={this.columns}
                    dataSource={this.props.envProfileList}
                />
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    state = state.toJS();
    return {
        envProfileList:state.profile.envProfileList,
        selectedProject: state.project.selectedProject,
    }
};

const mapDispatchToProps = (dispatch) => ({
    setSelectedEnv:(data)=>{
        dispatch(setSelectedEnv({
            profile:data
        }))
    },
    setIsEnvEdit:(data)=>{
        dispatch(setIsEnvEdit({
            isEdit:data
        }))
    },
    deleteEnvProfile:(data)=>{
        dispatch(deleteEnvProfile({
            profile:data
        }))
    },
    setEnvProfileList:(data)=>{
        dispatch(setEnvProfileList({
            envProfileList:data
        }))
    },
})

export default connect(mapStateToProps,mapDispatchToProps)(List)