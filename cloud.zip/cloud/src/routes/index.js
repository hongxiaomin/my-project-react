import React from 'react';
import propTypes from 'prop-types';
import {Switch,Route} from 'react-router-dom';
import Wrapper from '../layouts';
import Market from './Market';
import MeuDetail from './Market/MeuDetail';
import ComponentDetail from './Market/ComponentDetail';
import MEU from './Resource/MEU';
import Components from './Resource/Components';
import Epg from './Resource/EPG';
import MyDiagram from './Resource/EPG/MyDiagram';
import App from './Resource/App';
import EnvironmentProfile from './Resource/ProfileAll/EnvironmentProfile';
import AppProfile from './Resource/ProfileAll/AppProfile';
import Test from './Resource/ProfileAll/AppProfile/Test';
import ExecutionRecord from './Resource/ExecutionRecord';
import CreateProject from './Project/CreateProject';
import SettingProject from './Project/SettingProject';
import './style.less';

const MyRouter = () => (
    <Switch>
      <Route exact path="/" component={Market}/>
      <Route exact path="/market/meu" component={MeuDetail}/>
      <Route exact path="/market/component" component={ComponentDetail}/>
      <Route exact path="/resource/meu" component={MEU}/>
      {/* <Route exact path="/resource/components" component={Components}/> */}
      <Route exact path="/resource/epg" component={Epg}/>
      <Route exact path="/resource/app" component={App}/>
      <Route exact path="/resource/executionrecord" component={ExecutionRecord}/>
      <Route exact path="/project/create" component={CreateProject}/>
      <Route exact path="/project/set" component={SettingProject}/>
      <Route  path="/resource/profile/environmentProfile" component={EnvironmentProfile}/>
      <Route  path="/resource/profile/appProfile" component={AppProfile}/>
      <Route  path="/resource/profile/test" component={Test}/>
    </Switch>
);

export default MyRouter;
