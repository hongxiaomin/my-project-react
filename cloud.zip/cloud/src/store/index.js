import {createStore,applyMiddleware} from 'redux';
import reducers from '../reducers';

const store = createStore(reducers);
console.dir(store)
export default store;