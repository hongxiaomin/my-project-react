// import React, { Component } from 'react';
// import PropTypes from 'prop-types';

const ActionsForm = () => (
  null
);
ActionsForm.displayName = 'ActionsForm';

ActionsForm.propTypes = {
};

ActionsForm.defaultProps = {
};

export default ActionsForm;
