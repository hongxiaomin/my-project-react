import ColorPickerTextField from './ColorPickerTextField';

export default ColorPickerTextField;
