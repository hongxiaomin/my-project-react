// import React, { Component } from 'react';
// import PropTypes from 'prop-types';

const DataBindingsForm = () => (
  null
);

DataBindingsForm.displayName = 'DataBindingsForm';

DataBindingsForm.propTypes = {
};

DataBindingsForm.defaultProps = {
};

export default DataBindingsForm;
