import DataBindingsForm from './DataBindingsForm';

export default DataBindingsForm;
