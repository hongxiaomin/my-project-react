export default {
  dialogContentStyle: {
    width: '50vw',
  },
  title: {
    color: '#0087dc',
    fontSize: 20,
    marginLeft: 20,
  },
  textField: {
    width: 550,
    color: 'black',
    fontSize: 20,
    marginLeft: 20,
  },
  hintText: {
    marginTop: 20,
    marginLeft: 20,
    color: '#9E9E9E',
  },
};
