import DnDGenerator from './DnDGenerator';

export default DnDGenerator;
