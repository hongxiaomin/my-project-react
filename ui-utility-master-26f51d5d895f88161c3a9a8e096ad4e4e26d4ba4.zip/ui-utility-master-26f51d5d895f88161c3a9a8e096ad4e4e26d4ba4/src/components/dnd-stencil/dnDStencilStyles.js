export default {
  allowedDropPosition: {
    backgroundColor: 'rgb(80, 168, 168)',
    opacity: '.75',
  },
  notAllowedDropPosition: {
    backgroundColor: 'red',
    opacity: '.75',
  },
};
