import DnDStencil from './DnDStencil';

export default DnDStencil;
