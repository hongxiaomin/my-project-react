import IconBox from './IconBox';

export default IconBox;
