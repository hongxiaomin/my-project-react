import IconSelectorModal from './IconSelectorModal';

export default IconSelectorModal;
