import MainView from './MainView';

export default MainView;
