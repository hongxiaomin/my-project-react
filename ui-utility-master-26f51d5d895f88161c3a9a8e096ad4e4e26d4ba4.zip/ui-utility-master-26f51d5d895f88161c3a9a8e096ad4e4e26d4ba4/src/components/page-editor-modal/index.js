import PageEditorModal from './PageEditorModal';

export default PageEditorModal;
