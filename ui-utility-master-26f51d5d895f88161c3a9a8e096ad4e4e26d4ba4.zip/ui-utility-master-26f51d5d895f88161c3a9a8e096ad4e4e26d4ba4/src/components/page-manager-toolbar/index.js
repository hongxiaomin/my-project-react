import PageManagerToolbar from './PageManagerToolbar';

export default PageManagerToolbar;
