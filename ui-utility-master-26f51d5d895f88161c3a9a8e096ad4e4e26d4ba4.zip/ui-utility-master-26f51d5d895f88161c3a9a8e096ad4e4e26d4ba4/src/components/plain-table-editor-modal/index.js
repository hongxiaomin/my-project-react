import PlainTableEditorModal from './PlainTableEditorModal';

export default PlainTableEditorModal;
