import PropertyForm from './PropertyForm';

export default PropertyForm;
