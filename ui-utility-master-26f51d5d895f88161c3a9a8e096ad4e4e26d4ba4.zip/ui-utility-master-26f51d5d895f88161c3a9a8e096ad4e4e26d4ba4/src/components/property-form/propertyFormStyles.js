export default {
  buttonPosition: {
    display: 'flex',
    justifyContent: 'center',
    width: '100%',
  },
  button: {
    marginTop: 10,
  },
  label: {
    fontWeight: 'bold',
  },
};
