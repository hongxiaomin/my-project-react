import ReChartBasicEditorModal from './ReChartBasicEditorModal';

export default ReChartBasicEditorModal;
