import ReChartComposedEditorModal from './ReChartComposedEditorModal';

export default ReChartComposedEditorModal;
