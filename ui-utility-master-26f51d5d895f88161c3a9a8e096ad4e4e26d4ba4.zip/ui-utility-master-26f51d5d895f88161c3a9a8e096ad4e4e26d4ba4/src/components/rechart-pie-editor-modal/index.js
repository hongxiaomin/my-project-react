import ReChartPieEditorModal from './ReChartPieEditorModal';

export default ReChartPieEditorModal;
