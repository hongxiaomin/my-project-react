import ReChartRadarEditorModal from './ReChartRadarEditorModal';

export default ReChartRadarEditorModal;
