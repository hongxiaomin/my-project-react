import ReChartScatterEditorModal from './ReChartScatterEditorModal';

export default ReChartScatterEditorModal;
