import RTChartEditorModal from './RTChartEditorModal';

export default RTChartEditorModal;
