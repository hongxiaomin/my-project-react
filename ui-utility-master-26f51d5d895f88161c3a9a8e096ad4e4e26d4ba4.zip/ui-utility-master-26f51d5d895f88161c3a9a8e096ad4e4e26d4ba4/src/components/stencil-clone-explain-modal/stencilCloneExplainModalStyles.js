export default {
  floatButton: {
    marginTop: -5,
    marginBottom: 10,
    left: 220,
    position: 'relative',
  },
  title: {
    color: '#0087dc',
    marginLeft: 20,
    marginRight: 20,
    marginTop: 20,
    fontSize: 20,
  },
  listTitle: {
    color: '#0087dc',
    fontSize: 18,
  },
  text: {
    marginTop: 5,
    width: 220,
  },
};
