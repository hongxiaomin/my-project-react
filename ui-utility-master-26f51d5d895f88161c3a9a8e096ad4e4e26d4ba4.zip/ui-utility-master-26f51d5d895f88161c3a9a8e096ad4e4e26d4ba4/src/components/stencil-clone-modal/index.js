import StencilCloneModal from './StencilCloneModal';

export default StencilCloneModal;
