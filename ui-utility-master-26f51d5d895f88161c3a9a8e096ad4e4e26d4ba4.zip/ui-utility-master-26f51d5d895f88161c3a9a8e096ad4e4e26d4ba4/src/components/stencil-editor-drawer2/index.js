import StencilEditorDrawer2 from './StencilEditorDrawer2';

export default StencilEditorDrawer2;
