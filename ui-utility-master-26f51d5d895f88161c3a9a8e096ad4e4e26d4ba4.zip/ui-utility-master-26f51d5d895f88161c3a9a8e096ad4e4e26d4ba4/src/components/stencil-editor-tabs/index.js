import StencilEditorTabs from './StencilEditorTabs';

export default StencilEditorTabs;
