import StencilEditorTabs2 from './StencilEditorTabs2';

export default StencilEditorTabs2;
