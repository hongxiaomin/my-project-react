import TabFormAction from './TabFormAction';

export default TabFormAction;
