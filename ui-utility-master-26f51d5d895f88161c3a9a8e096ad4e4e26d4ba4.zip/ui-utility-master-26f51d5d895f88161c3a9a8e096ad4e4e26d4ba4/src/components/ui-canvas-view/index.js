import UICanvasView from './UICanvasView';

export default UICanvasView;
