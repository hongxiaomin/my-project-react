import UIUtilityView from './UIUtilityView';

export default UIUtilityView;
