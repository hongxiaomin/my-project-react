export default {
  title: 'Grid Layout',
  stencils: {
    name: 'Grid Layout', img: 'img/Grid Layout.png', width: 627,
  },
  // stencils: {
  //   items: [
      /*
      one row, could decide how many column
      decide content position (9 position)
      decide go column or row way
       */
  //     { name: 'Grid Layout', img: 'img/Grid Layout.png', width: 627 },
  //   ],
  // },
};
