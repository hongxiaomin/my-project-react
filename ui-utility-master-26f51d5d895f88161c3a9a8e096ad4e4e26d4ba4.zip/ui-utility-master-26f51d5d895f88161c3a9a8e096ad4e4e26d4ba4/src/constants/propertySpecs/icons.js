import {
  STRING,
  REQUIREDICON,
} from '../propertyTypes';

export default {
  color: STRING,
  hoverColor: STRING,
  icon: REQUIREDICON, // custom attribute
  // style: OBJECT,
};
