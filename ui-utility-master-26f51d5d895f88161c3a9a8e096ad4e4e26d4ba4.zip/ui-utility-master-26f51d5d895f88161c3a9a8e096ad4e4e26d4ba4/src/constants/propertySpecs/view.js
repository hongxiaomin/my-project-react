import {
  // STRING,
  BOOLEAN,
  // NUMBER,
} from '../propertyTypes';

export default {
  column: BOOLEAN,
  // width: NUMBER,
  // height: STRING,
};
