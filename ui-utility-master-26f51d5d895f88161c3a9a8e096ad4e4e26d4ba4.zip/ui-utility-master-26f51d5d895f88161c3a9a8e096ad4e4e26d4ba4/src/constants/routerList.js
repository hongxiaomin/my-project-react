export default {
  title: 'Router',
  stencils: {
    items: [
      { name: 'Link' },
      { name: 'IndexLink' },
    ],
  },
};
