import { connect } from 'react-redux';
import ActionForm from '../components/actions-form';

const mapStateToProps = () => ({
});

const mapDispatchToProps = () => ({
});

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(ActionForm);
