import { connect } from 'react-redux';
import DataBindingsForm from '../components/data-bindings-form';

const mapStateToProps = () => ({
});

const mapDispatchToProps = () => ({
});

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(DataBindingsForm);
