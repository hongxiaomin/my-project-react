#!/bin/sh
java -jar ./bin/jlhttp-2.2.jar . 8000
