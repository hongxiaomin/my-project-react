<!--
IF YOU DON'T FILL OUT THE FOLLOWING INFORMATION WE MIGHT CLOSE YOUR ISSUE WITHOUT INVESTIGATING
-->

**I'm submitting a ...**  (check one with "x")
```
[ ] bug report => search github for a similar issue or PR before submitting
[ ] feature request
[ ] support request => Please do not submit support request here, instead see https://github.com/ceolter/ag-grid/blob/master/CONTRIBUTING.md#question
```

**Current behavior**
<!-- Describe how the bug manifests. -->

**Expected behavior**
<!-- Describe what the behavior would be without the bug. -->

**Minimal reproduction of the problem with instructions**
<!--
If the current behavior is a bug or you can illustrate your feature request better with an example,
please provide the *STEPS TO REPRODUCE* and if possible a *MINIMAL DEMO* of the problem via
https://plnkr.co or similar (you can use this template as a starting point: http://plnkr.co/edit/tpl:AvJOMERrnz94ekVua0u5).
-->

**What is the motivation / use case for changing the behavior?**
<!-- Describe the motivation or the concrete use case -->

**Please tell us about your environment:**
<!-- Operating system, IDE, package manager, HTTP server, ... -->

* **ag-Grid version:** X.X.X
<!-- Check whether this is still an issue in the most recent ag-Grid version -->


* **Browser:**
<!-- Run `navigator.userAgent` in console of all of the browsers where this could be reproduced -->

* **Language:** [all | TypeScript X.X | ES6/7 | ES5]

