/* */ 
module.exports = { "default": require("core-js/library/fn/date/format-utc"), __esModule: true };