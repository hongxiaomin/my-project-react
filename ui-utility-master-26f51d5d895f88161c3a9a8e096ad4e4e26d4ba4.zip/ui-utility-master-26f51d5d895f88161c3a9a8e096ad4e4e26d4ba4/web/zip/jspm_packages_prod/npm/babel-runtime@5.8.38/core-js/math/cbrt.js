/* */ 
module.exports = { "default": require("core-js/library/fn/math/cbrt"), __esModule: true };