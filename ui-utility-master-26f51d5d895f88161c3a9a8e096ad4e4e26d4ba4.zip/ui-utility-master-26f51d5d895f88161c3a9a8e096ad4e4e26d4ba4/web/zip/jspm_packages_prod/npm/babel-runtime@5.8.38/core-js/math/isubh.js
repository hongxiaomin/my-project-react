/* */ 
module.exports = { "default": require("core-js/library/fn/math/isubh"), __esModule: true };