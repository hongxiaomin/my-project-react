/* */ 
module.exports = { "default": require("core-js/library/fn/math/sinh"), __esModule: true };