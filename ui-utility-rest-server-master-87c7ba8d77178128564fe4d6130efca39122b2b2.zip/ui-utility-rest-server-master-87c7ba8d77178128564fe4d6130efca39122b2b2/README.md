UI Utility REST Server
======================

Endpoints:

- **/pages** : line chart, bar chart, area chart
- **/groups** : pie chart
- **/coordinates** : scatter chart
- **/subjects** : radar chart
- **/occupations** : radial chart

